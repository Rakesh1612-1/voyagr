import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { handleApi } from './server/api.js';

/** Mounts the Voyagr API on the Vite dev & preview servers (/api/*),
 *  so the same origin serves the app and its backend during development. */
function voyagrApi() {
  return {
    name: 'voyagr-api',
    configureServer(server) {
      server.middlewares.use(function (req, res, next) {
        if (handleApi(req, res)) return;
        next();
      });
    },
    configurePreviewServer(server) {
      server.middlewares.use(function (req, res, next) {
        if (handleApi(req, res)) return;
        next();
      });
    },
  };
}

// Voyagr build config. The dev server binds to 0.0.0.0 so the live preview
// proxy can reach it, and allows any Host header (preview sandbox domains).
export default defineConfig({
  plugins: [react(), voyagrApi()],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
    cors: true,
  },
  preview: {
    host: '0.0.0.0',
    port: 4173,
    strictPort: true,
    allowedHosts: true,
    cors: true,
  },
  build: {
    target: 'es2018',
    sourcemap: false,
    chunkSizeWarningLimit: 1200,
  },
});

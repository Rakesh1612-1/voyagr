/* Extra end-to-end checks: train seats, café pre-order, car add-ons, mobile filters. */
import { chromium } from 'playwright';

const base = 'http://localhost:5173';
let passed = 0;
let failed = 0;
const errors = [];

async function step(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('✓', name);
  } catch (e) {
    failed += 1;
    console.log('✗', name, '—', String(e.message).split('\n')[0]);
    process.exitCode = 1;
  }
}

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1320, height: 950 } });
page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', (e) => errors.push('pageerror: ' + String(e)));

await step('train: choose class + 2 seats + book', async () => {
  await page.goto(base + '/book/train/nb-2001?date=2026-11-05&class=3A&pax=2', { waitUntil: 'networkidle' });
  await page.waitForSelector('.seatmap');
  const free = page.locator('.seat:not(.booked)');
  await free.nth(0).click();
  await free.nth(1).click();
  const selected = await page.locator('.seat.selected').count();
  if (selected !== 2) throw new Error('selected=' + selected);
  await page.fill('input[placeholder="Aarav"]', 'Test');
  await page.fill('input[placeholder="Sharma"]', 'Rail');
  await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
  await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
  await page.fill('input[placeholder="Full name"]', 'Test Two');
  await page.locator('button:has-text("Continue to payment")').click();
  await page.waitForSelector('text=How would you like to pay?');
  await page.fill('input[placeholder="Test Rail"]', 'Test Rail');
  await page.getByTestId('pay-btn').click();
  await page.waitForSelector('.success-hero', { timeout: 10000 });
  const body = await page.textContent('body');
  if (!/Seats/.test(body)) throw new Error('seats missing on ticket');
});

await step('cafe: pre-order + UPI payment', async () => {
  await page.goto(base + '/search/cafe?city=london&date=2026-11-06&party=2');
  await page.waitForSelector('.result-card');
  await page.locator('.result-card').first().getByText('Reserve table').click();
  await page.waitForSelector('.booking-layout');
  // add two menu items
  await page.locator('.qty button[aria-label="More"]').nth(0).click();
  await page.locator('.qty button[aria-label="More"]').nth(1).click();
  await page.fill('input[placeholder="Aarav"]', 'Test');
  await page.fill('input[placeholder="Sharma"]', 'Cafe');
  await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
  await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
  await page.locator('button:has-text("Continue to payment")').click();
  await page.waitForSelector('text=How would you like to pay?');
  await page.locator('.pay-method', { hasText: 'UPI' }).click();
  await page.fill('input[placeholder="yourname@bank"]', 'test@okhdfc');
  await page.getByTestId('pay-btn').click();
  await page.waitForSelector('.success-hero', { timeout: 10000 });
  const body = await page.textContent('body');
  if (!/Pre-ordered/.test(body)) throw new Error('pre-order missing on ticket');
});

await step('car: add-ons + wallet payment', async () => {
  await page.goto(base + '/search/car?city=rome&pickup=2026-11-05&dropoff=2026-11-09');
  await page.waitForSelector('.result-card');
  await page.locator('.result-card').first().getByText('Reserve').click();
  await page.waitForSelector('.booking-layout');
  await page.locator('.check input').nth(0).check(); // GPS
  await page.locator('.check input').nth(2).check(); // driver
  await page.fill('input[placeholder="Aarav"]', 'Test');
  await page.fill('input[placeholder="Sharma"]', 'Driver');
  await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
  await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
  await page.locator('button:has-text("Continue to payment")').click();
  await page.waitForSelector('text=How would you like to pay?');
  await page.locator('.pay-method', { hasText: 'Voyagr Wallet' }).click();
  await page.getByTestId('pay-btn').click();
  await page.waitForSelector('.success-hero', { timeout: 10000 });
});

await step('ride: book with driver note (RIDE2 promo)', async () => {
  await page.goto(base + '/search/ride?city=delhi&pickup=0&dropoff=3&when=now');
  await page.waitForSelector('.result-card');
  await page.locator('.result-card').first().getByText('Book ride').click();
  await page.waitForSelector('.booking-layout');
  await page.fill('textarea', 'Meet me at gate 2');
  await page.fill('input[placeholder="Aarav"]', 'Test');
  await page.fill('input[placeholder="Sharma"]', 'Rider');
  await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
  await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
  await page.locator('button:has-text("Continue to payment")').click();
  await page.waitForSelector('text=How would you like to pay?');
  await page.fill('input[placeholder="VOYAGR10"]', 'RIDE2');
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(300);
  await page.fill('input[placeholder="Test Rider"]', 'Test Rider');
  await page.getByTestId('pay-btn').click();
  await page.waitForSelector('.success-hero', { timeout: 10000 });
  const body = await page.textContent('body');
  if (!/Driver note/.test(body)) throw new Error('driver note missing');
});

await step('experience + flight fare switch', async () => {
  await page.goto(base + '/book/flight/delhi-goa-2026-11-05-f0?from=delhi&to=goa&date=2026-11-05&cabin=economy&pax=1', { waitUntil: 'networkidle' });
  await page.waitForSelector('.room-row', { timeout: 8000 });
  await page.locator('button:has-text("Select")').nth(1).click(); // switch to premium
  await page.waitForTimeout(600);
  const body = await page.textContent('body');
  if (!/Premium/.test(body)) throw new Error('fare switch failed');
});

await step('mobile filter sheet opens & closes', async () => {
  const m = await browser.newPage({ viewport: { width: 390, height: 844 } });
  m.on('pageerror', (e) => errors.push('mobile pageerror: ' + String(e)));
  await m.goto(base + '/search/hotel?city=goa&checkin=2026-11-05&checkout=2026-11-08&guests=2&rooms=1');
  await m.waitForSelector('.result-card');
  await m.locator('button:has-text("Filters")').first().click();
  await m.waitForTimeout(400);
  const open = await m.locator('.filters.open').count();
  if (!open) throw new Error('sheet did not open');
  await m.locator('.filters.open button:has-text("Show")').click();
  await m.waitForTimeout(400);
  await m.close();
});

await step('install banner shows on iOS UA', async () => {
  const iPhone = await browser.newContext({
    viewport: { width: 390, height: 844 },
    userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
    isMobile: true,
    hasTouch: true,
  });
  const p = await iPhone.newPage();
  await p.goto(base + '/', { waitUntil: 'networkidle' });
  await p.waitForTimeout(800);
  const banner = await p.locator('.install-banner').count();
  if (!banner) throw new Error('no install banner on iOS');
  await iPhone.close();
});

console.log('\n--- console/page errors:', errors.length ? errors.slice(0, 8) : 'none');
console.log('--- results:', passed, 'passed,', failed, 'failed');
await browser.close();

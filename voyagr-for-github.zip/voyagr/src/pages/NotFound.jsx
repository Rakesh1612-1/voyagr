import React from 'react';
import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="container section">
      <div className="empty" style={{ maxWidth: 560, margin: '0 auto' }}>
        <div style={{ fontSize: '3.4rem', fontFamily: 'var(--font-display)', fontWeight: 700, color: 'var(--coral)' }}>
          404
        </div>
        <h3>This route wandered off the map</h3>
        <p>The page you’re looking for doesn’t exist — but your next trip definitely can.</p>
        <div className="row gap-12" style={{ justifyContent: 'center' }}>
          <Link className="btn btn-primary" to="/">
            Back home
          </Link>
          <Link className="btn btn-outline" to="/trips">
            My Trips
          </Link>
        </div>
      </div>
    </div>
  );
}

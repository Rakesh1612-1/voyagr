/* ------------------------------------------------------------------
   Booking page — handles all eight services in two steps:
   1) traveller details & service options  2) payment
   Then stores a booking and forwards to the confirmation ticket.
------------------------------------------------------------------- */

import React, { useMemo, useState } from 'react';
import { Link, useNavigate, useParams, useSearchParams } from 'react-router-dom';
import { useApp } from '../store/store';
import {
  formatMoney,
  formatDateHuman,
  formatTime12,
  formatDuration,
  diffDays,
  todayISO,
  addDays,
  isEmail,
  isPhone,
  luhnCheck,
  isExpiry,
  isCVV,
  isUPI,
  cardBrand,
  bookingRef,
  uid,
} from '../lib/format';
import { CITY_BY_ID, cityShort, cityLabel } from '../data/cities';
import { getHotel } from '../data/hotels';
import { getFlight } from '../data/flights';
import { getTrain, generateSeatMap } from '../data/trains';
import { getBus, generateBusSeats } from '../data/buses';
import { getCafe } from '../data/cafes';
import { getCar } from '../data/cars';
import { getRideQuote, cityAreas } from '../data/rides';
import { getExperience } from '../data/experiences';
import { applyPromo, priceBreakdown } from '../data/promos';
import {
  CheckIcon,
  CloseIcon,
  CardIcon,
  ShieldIcon,
  TicketIcon,
  BagIcon,
  StarIcon,
  ClockIcon,
  InfoIcon,
  PlusIcon,
  MinusIcon,
} from '../components/Icons';

/* ------------------------- item resolution ------------------------- */

function resolve(service, itemId, q) {
  if (service === 'hotel') {
    const hotel = getHotel(itemId);
    if (!hotel) return null;
    const roomId = q.room || 'deluxe';
    const room = hotel.rooms.filter(function (r) {
      return r.id === roomId;
    })[0] || hotel.rooms[0];
    const checkin = q.checkin || addDays(todayISO(), 7);
    const checkout = q.checkout || addDays(todayISO(), 10);
    const nights = Math.max(1, diffDays(checkin, checkout));
    return {
      service: 'hotel',
      item: hotel,
      title: hotel.name,
      subtitle: hotel.area + ', ' + cityShort(hotel.city),
      image: hotel.image,
      unitPriceUSD: Math.round(hotel.priceUSD * room.priceFactor * 100) / 100,
      unitLabel: 'night',
      quantity: nights,
      guests: Number(q.guests || 2),
      dateLabel: formatDateHuman(checkin, 'month') + ' – ' + formatDateHuman(checkout, 'month'),
      details: [
        { k: 'Check-in', v: formatDateHuman(checkin, 'long') + ' · from ' + hotel.checkIn },
        { k: 'Check-out', v: formatDateHuman(checkout, 'long') + ' · until ' + hotel.checkOut },
        { k: 'Room', v: room.name + ' · ' + room.bed },
        { k: 'Guests', v: String(q.guests || 2) },
        { k: 'Cancellation', v: room.refundable ? 'Free cancellation until 48h before check-in' : 'Non-refundable rate' },
      ],
      options: { room: room, checkin: checkin, checkout: checkout, nights: nights },
    };
  }

  if (service === 'flight') {
    const flight = getFlight(q.from, q.to, q.date, itemId);
    if (!flight) return null;
    const cabin = q.cabin || 'economy';
    const fare = flight.fares[cabin] || flight.fares.economy;
    return {
      service: 'flight',
      item: flight,
      title: flight.airline.name + ' · ' + flight.flightNo,
      subtitle: cityLabel(flight.from) + ' → ' + cityLabel(flight.to),
      image: '/img/flight.jpg',
      unitPriceUSD: fare.priceUSD,
      unitLabel: 'traveller',
      quantity: Number(q.pax || 1),
      guests: Number(q.pax || 1),
      dateLabel: formatDateHuman(flight.date, 'long'),
      details: [
        { k: 'Departure', v: formatTime12(flight.dep) + ' · ' + cityShort(flight.from) + ' (' + CITY_BY_ID[flight.from].code + ')' },
        { k: 'Arrival', v: formatTime12(flight.arr) + (flight.arrDayOffset ? ' (+1 day)' : '') + ' · ' + cityShort(flight.to) + ' (' + CITY_BY_ID[flight.to].code + ')' },
        { k: 'Duration', v: formatDuration(flight.durationMin) + (flight.stops ? ' · ' + flight.stops + ' stop(s)' : ' · Non-stop') },
        { k: 'Fare', v: fare.label + ' · ' + fare.checkedBags + ' checked + ' + fare.cabinBags + ' cabin' },
        { k: 'Aircraft', v: flight.aircraft },
      ],
      options: { cabin: cabin, fare: flight.fares },
    };
  }

  if (service === 'train') {
    const train = getTrain(itemId);
    if (!train) return null;
    const classCode = q.class || train.classes[1].code;
    const cls = train.classes.filter(function (c) {
      return c.code === classCode;
    })[0] || train.classes[0];
    return {
      service: 'train',
      item: train,
      title: train.name + ' · ' + train.number,
      subtitle: cityLabel(train.from) + ' → ' + cityLabel(train.to),
      image: '/img/train.jpg',
      unitPriceUSD: cls.priceUSD,
      unitLabel: 'seat',
      quantity: Number(q.pax || 1),
      guests: Number(q.pax || 1),
      dateLabel: formatDateHuman(q.date || todayISO(), 'long'),
      details: [
        { k: 'Departure', v: formatTime12(train.dep) + ' · ' + cityShort(train.from) },
        { k: 'Arrival', v: formatTime12(train.arr) + (train.arrDayOffset ? ' (+1 day)' : '') + ' · ' + cityShort(train.to) },
        { k: 'Class', v: cls.name + ' · ' + cls.comfort },
        { k: 'Duration', v: formatDuration(train.durationMin) },
        { k: 'On board', v: train.onBoard },
      ],
      options: { trainClass: cls, seatMap: generateSeatMap(train.id, cls.code, q.date || todayISO()) },
    };
  }

  if (service === 'bus') {
    const bus = getBus(q.from, q.to, q.date, itemId);
    if (!bus) return null;
    return {
      service: 'bus',
      item: bus,
      title: bus.operator + ' · ' + bus.busType.name,
      subtitle: cityLabel(bus.from) + ' → ' + cityLabel(bus.to),
      image: '/img/road.jpg',
      unitPriceUSD: bus.priceUSD,
      unitLabel: 'seat',
      quantity: Number(q.pax || 1),
      guests: Number(q.pax || 1),
      dateLabel: formatDateHuman(q.date || todayISO(), 'long'),
      details: [
        { k: 'Departure', v: formatTime12(bus.dep) + ' · ' + bus.boardingPoints[0] },
        { k: 'Arrival', v: formatTime12(bus.arr) + (bus.arrDayOffset ? ' (+1 day)' : '') + ' · ' + bus.droppingPoints[0] },
        { k: 'Coach', v: bus.busType.comfort },
        { k: 'Amenities', v: bus.busType.amenities.join(', ') },
      ],
      options: { seatLayout: generateBusSeats(bus.id, bus.busType.layout, q.date || todayISO()), layout: bus.busType.layout },
    };
  }

  if (service === 'cafe') {
    const cafe = getCafe(itemId);
    if (!cafe) return null;
    return {
      service: 'cafe',
      item: cafe,
      title: cafe.name,
      subtitle: cafe.area + ', ' + cityShort(cafe.city),
      image: cafe.image,
      unitPriceUSD: cafe.priceUSD,
      unitLabel: 'guest',
      quantity: Number(q.party || 2),
      guests: Number(q.party || 2),
      dateLabel: formatDateHuman(q.date || todayISO(), 'long') + ' · ' + formatTime12(q.slot || '19:00'),
      details: [
        { k: 'Reservation', v: formatDateHuman(q.date || todayISO(), 'long') + ' at ' + formatTime12(q.slot || '19:00') },
        { k: 'Party size', v: (q.party || 2) + ' guests' },
        { k: 'Table', v: 'Standard table held 15 minutes past slot' },
        { k: 'Average spend', v: formatMoney(cafe.priceUSD, 'USD') + ' per person (payable at venue)' },
      ],
      options: { date: q.date || todayISO(), slot: q.slot || '19:00', menu: {}, preOrder: 0 },
    };
  }

  if (service === 'car') {
    const days = Math.max(1, diffDays(q.pickup || todayISO(), q.dropoff || addDays(todayISO(), 3)));
    const car = getCar(itemId, q.city, days);
    if (!car) return null;
    return {
      service: 'car',
      item: car,
      title: car.name,
      subtitle: car.supplier + ' · ' + cityLabel(q.city),
      image: car.image,
      unitPriceUSD: car.pricePerDayUSD,
      unitLabel: 'day',
      quantity: days,
      guests: Number(q.pax || 1),
      dateLabel: formatDateHuman(q.pickup || todayISO(), 'month') + ' – ' + formatDateHuman(q.dropoff || addDays(todayISO(), 3), 'month'),
      details: [
        { k: 'Pick-up', v: formatDateHuman(q.pickup || todayISO(), 'long') + ' · 10:00' },
        { k: 'Drop-off', v: formatDateHuman(q.dropoff || addDays(todayISO(), 3), 'long') + ' · 10:00' },
        { k: 'Category', v: car.category + ' · ' + car.transmission + ' · ' + car.seats + ' seats' },
        { k: 'Mileage', v: car.mileageKm + ' · ' + car.fuelPolicy },
        { k: 'Cancellation', v: car.freeCancellation ? 'Free cancellation up to 48h before pick-up' : 'Non-refundable' },
      ],
      options: { days: days, addons: { gps: false, childSeat: false, driver: false } },
    };
  }

  if (service === 'ride') {
    const pickup = Number(q.pickup || 0);
    const dropoff = Number(q.dropoff != null ? q.dropoff : 2);
    const quote = getRideQuote(q.city, pickup, dropoff, q.vehicle, q.when || 'now');
    if (!quote) return null;
    return {
      service: 'ride',
      item: quote,
      title: quote.vehicle.name + ' · ' + cityShort(q.city),
      subtitle: quote.from.name + ' → ' + quote.to.name,
      image: '/img/road.jpg',
      unitPriceUSD: quote.priceUSD,
      unitLabel: 'ride',
      quantity: 1,
      guests: quote.vehicle.seats,
      dateLabel: (q.when || 'now') === 'now' ? 'Ride now · pickup in ~' + quote.etaMin + ' min' : 'Scheduled ride',
      details: [
        { k: 'Pick-up', v: quote.from.name },
        { k: 'Drop-off', v: quote.to.name },
        { k: 'Distance', v: quote.distanceKm + ' km · ' + formatDuration(quote.durationMin) },
        { k: 'Driver', v: quote.driverName + ' · ' + quote.driverRating + '★ · ' + quote.vehicleNo },
        { k: 'Fare', v: 'Fixed upfront · tolls included' },
      ],
      options: { when: q.when || 'now', note: '' },
    };
  }

  if (service === 'experience') {
    const exp = getExperience(itemId);
    if (!exp) return null;
    return {
      service: 'experience',
      item: exp,
      title: exp.title,
      subtitle: cityLabel(exp.city) + ' · ' + exp.hours + ' hours',
      image: exp.image,
      unitPriceUSD: exp.priceUSD,
      unitLabel: 'person',
      quantity: Number(q.guests || 2),
      guests: Number(q.guests || 2),
      dateLabel: formatDateHuman(q.date || todayISO(), 'long') + ' · ' + formatTime12(q.slot || exp.slots[0]),
      details: [
        { k: 'Date & time', v: formatDateHuman(q.date || todayISO(), 'long') + ' · ' + formatTime12(q.slot || exp.slots[0]) },
        { k: 'Duration', v: exp.hours + ' hours · max group ' + exp.maxGroup },
        { k: 'Includes', v: exp.includes.map(function (i) { return i.label; }).join(', ') },
        { k: 'Cancellation', v: 'Free cancellation up to 24h before start' },
      ],
      options: { date: q.date || todayISO(), slot: q.slot || exp.slots[0] },
    };
  }

  return null;
}

/* ------------------------- seat map component ------------------------- */

function SeatMap(props) {
  return (
    <div>
      <div className="legend mb-16">
        <span>
          <span className="dot" style={{ background: '#fff', border: '1.5px solid var(--line-2)' }} /> Available
        </span>
        <span>
          <span className="dot" style={{ background: 'var(--cream-2)' }} /> Booked
        </span>
        <span>
          <span className="dot" style={{ background: 'var(--coral)' }} /> Selected
        </span>
      </div>
      <div className="seatmap">
        {(props.coaches || []).map(function (coach) {
          return (
            <div className="coach" key={coach.id}>
              <h4>Coach {coach.id}</h4>
              <div className="coach-grid" style={props.berth ? { gridTemplateColumns: 'repeat(4, 40px)' } : null}>
                {coach.seats.map(function (seat) {
                  const selected = props.selected.indexOf(seat.id) >= 0;
                  return (
                    <button
                      key={seat.id}
                      type="button"
                      title={seat.type}
                      disabled={seat.booked}
                      className={
                        'seat' +
                        (seat.booked ? ' booked' : '') +
                        (selected ? ' selected' : '') +
                        (props.berth ? ' berth' : '')
                      }
                      onClick={function () {
                        props.onToggle(seat.id);
                      }}
                    >
                      {seat.number}
                    </button>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* --------------------------- main book page --------------------------- */

export default function BookPage() {
  const { service, itemId } = useParams();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const { currency, user, addBooking, toast, setCurrency } = useApp();

  const q = useMemo(
    function () {
      const obj = {};
      params.forEach(function (v, k) {
        obj[k] = v;
      });
      return obj;
    },
    [params]
  );

  const resolved = useMemo(
    function () {
      return resolve(service, itemId, q);
    },
    [service, itemId, q.from, q.to, q.date, q.city, q.room, q.cabin, q.class, q.pickup, q.dropoff, q.vehicle, q.checkin, q.checkout, q.party, q.guests, q.slot, q.when, q.pax]
  );

  const [step, setStep] = useState(1);
  const [contact, setContact] = useState({
    firstName: user ? user.name.split(' ')[0] : '',
    lastName: user ? user.name.split(' ').slice(1).join(' ') : '',
    email: user ? user.email : '',
    phone: user ? user.phone || '' : '',
  });
  const [travelerNames, setTravelerNames] = useState([]);
  const [seats, setSeats] = useState([]);
  const [menuQty, setMenuQty] = useState({});
  const [addons, setAddons] = useState({ gps: false, childSeat: false, driver: false });
  const [rideNote, setRideNote] = useState('');
  const [promoInput, setPromoInput] = useState('');
  const [promo, setPromo] = useState(null);
  const [payMethod, setPayMethod] = useState('card');
  const [card, setCard] = useState({ number: '4242 4242 4242 4242', name: '', exp: '12/28', cvv: '123' });
  const [upi, setUpi] = useState('');
  const [processing, setProcessing] = useState(false);
  const [errors, setErrors] = useState({});

  if (!resolved) {
    return (
      <div className="container section">
        <div className="empty">
          <h3>We couldn’t find that booking option</h3>
          <p>The link may be out of date. Start a fresh search and pick your favourite.</p>
          <Link className="btn btn-primary" to="/">
            Back to search
          </Link>
        </div>
      </div>
    );
  }

  /* ----------------------------- pricing ----------------------------- */
  const preOrderTotal = useMemo(
    function () {
      if (service !== 'cafe') return 0;
      let total = 0;
      Object.keys(menuQty).forEach(function (id) {
        const qty = menuQty[id];
        if (!qty) return;
        resolved.item.menu.forEach(function (m) {
          if (m.id === id) total += m.priceUSD * qty;
        });
      });
      return Math.round(total * 100) / 100;
    },
    [menuQty, resolved, service]
  );

  const addonTotal =
    service === 'car'
      ? (addons.gps ? 3 : 0) * resolved.options.days +
        (addons.childSeat ? 4 : 0) * resolved.options.days +
        (addons.driver ? 18 : 0) * resolved.options.days
      : 0;

  const baseUnit = resolved.unitPriceUSD;
  const subtotalBase = baseUnit * resolved.quantity + preOrderTotal + addonTotal;
  const promoResult = promo
    ? applyPromo(promo.code, service, subtotalBase)
    : { discountUSD: 0 };
  const pricing = priceBreakdown(service, subtotalBase, 1, promoResult.discountUSD);
  pricing.quantity = resolved.quantity;
  pricing.unitUSD = baseUnit;

  /* ----------------------------- validation ----------------------------- */
  function validateStep1() {
    const errs = {};
    if (!contact.firstName.trim()) errs.firstName = 'Required';
    if (!contact.lastName.trim()) errs.lastName = 'Required';
    if (!isEmail(contact.email)) errs.email = 'Enter a valid email';
    if (!isPhone(contact.phone)) errs.phone = 'Enter a valid phone';
    if ((service === 'flight' || service === 'train' || service === 'bus') && resolved.quantity > 1) {
      travelerNames.forEach(function (n, i) {
        if (!String(n || '').trim()) errs['traveler' + i] = 'Required';
      });
    }
    if ((service === 'train' || service === 'bus') && seats.length !== resolved.quantity) {
      errs.seats = 'Please select exactly ' + resolved.quantity + ' seat(s)';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function validatePayment() {
    const errs = {};
    if (payMethod === 'card') {
      if (!luhnCheck(card.number)) errs.number = 'Enter a valid card number (try 4242 4242 4242 4242)';
      if (!card.name.trim()) errs.cardName = 'Name on card required';
      if (!isExpiry(card.exp)) errs.exp = 'MM/YY not valid';
      if (!isCVV(card.cvv)) errs.cvv = '3–4 digits';
    }
    if (payMethod === 'upi' && !isUPI(upi)) errs.upi = 'Format: name@bank';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  }

  function payNow() {
    if (!validatePayment()) {
      toast('Please fix the highlighted fields', 'error');
      return;
    }
    setProcessing(true);
    window.setTimeout(function () {
      const details = resolved.details.slice();
      if (service === 'train' || service === 'bus') {
        details.push({ k: 'Seats', v: seats.join(', ') });
      }
      if (service === 'cafe') {
        const items = Object.keys(menuQty).filter(function (k) {
          return menuQty[k] > 0;
        });
        if (items.length) {
          details.push({
            k: 'Pre-ordered',
            v: items
              .map(function (id) {
                const m = resolved.item.menu.filter(function (x) { return x.id === id; })[0];
                return menuQty[id] + '× ' + (m ? m.name : id);
              })
              .join(', '),
          });
        }
      }
      if (service === 'car') {
        const add = [];
        if (addons.gps) add.push('GPS');
        if (addons.childSeat) add.push('Child seat');
        if (addons.driver) add.push('Professional driver');
        if (add.length) details.push({ k: 'Add-ons', v: add.join(', ') });
      }
      if (service === 'ride' && rideNote.trim()) {
        details.push({ k: 'Driver note', v: rideNote.trim() });
      }

      const record = addBooking({
        id: bookingRef('VYG'),
        service: service,
        title: resolved.title,
        subtitle: resolved.subtitle,
        image: resolved.image,
        dateLabel: resolved.dateLabel,
        quantity: resolved.quantity,
        unitLabel: resolved.unitLabel,
        guests: resolved.guests,
        details: details,
        contact: contact,
        travelers: travelerNames.filter(function (n) {
          return String(n || '').trim();
        }),
        pricing: pricing,
        currency: currency,
        payment: {
          method: payMethod,
          last4: payMethod === 'card' ? String(card.number).replace(/\D/g, '').slice(-4) : '',
          brand: payMethod === 'card' ? cardBrand(card.number) : payMethod === 'upi' ? 'UPI' : 'Voyagr Wallet',
        },
        promo: promo ? promo.code : null,
      });

      setProcessing(false);
      toast('Booking confirmed — e-ticket ready!', 'success');
      navigate('/confirmation/' + record.id);
    }, 1300);
  }

  /* ------------------------------- render ------------------------------- */
  const meta = {
    hotel: { label: 'Stay', icon: '🏨' },
    flight: { label: 'Flight', icon: '✈️' },
    train: { label: 'Train', icon: '🚆' },
    bus: { label: 'Bus', icon: '🚌' },
    cafe: { label: 'Café table', icon: '☕' },
    car: { label: 'Car rental', icon: '🚗' },
    ride: { label: 'Ride', icon: '🚕' },
    experience: { label: 'Experience', icon: '🎭' },
  }[service];

  return (
    <div className="container" style={{ paddingTop: 26, paddingBottom: 60 }}>
      <div className="stepper">
        <div className={'step-pill' + (step === 1 ? ' active' : ' done')}>
          <span className="n">{step > 1 ? '✓' : '1'}</span> Traveller details
        </div>
        <div className={'step-pill' + (step === 2 ? ' active' : '')}>
          <span className="n">2</span> Payment
        </div>
      </div>

      <div className="booking-layout">
        {/* ---------------------------- left ---------------------------- */}
        <div className="stack-16">
          {step === 1 ? (
            <React.Fragment>
              <div className="card card-pad">
                <div className="row gap-8 mb-16">
                  <span className="badge badge-coral">{meta.icon} {meta.label}</span>
                  <span className="badge">{resolved.dateLabel}</span>
                </div>
                <h2 style={{ fontSize: '1.55rem', marginBottom: 4 }}>{resolved.title}</h2>
                <p className="muted">{resolved.subtitle}</p>
                <div className="divider" />
                {resolved.details.map(function (d) {
                  return (
                    <div className="kv" key={d.k}>
                      <span className="k">{d.k}</span>
                      <span className="v">{d.v}</span>
                    </div>
                  );
                })}
              </div>

              {/* service options */}
              {service === 'flight' ? (
                <div className="card card-pad">
                  <h3>Choose your fare</h3>
                  <div className="stack-12 mt-16">
                    {['economy', 'premium', 'business'].map(function (code) {
                      const fare = resolved.item.fares[code];
                      return (
                        <label key={code} className={'room-row' + (q.cabin === code || (!q.cabin && code === 'economy') ? ' selected' : '')} style={{ cursor: 'pointer' }}>
                          <div>
                            <div className="bold">{fare.label}</div>
                            <div className="tiny muted">
                              {fare.checkedBags} checked · {fare.cabinBags} cabin · {fare.meals} ·{' '}
                              {fare.refundable ? 'Refundable' : 'Non-refundable'}
                            </div>
                          </div>
                          <div className="row gap-16">
                            <strong style={{ fontSize: '1.25rem' }}>{formatMoney(fare.priceUSD, currency)}</strong>
                            <button
                              type="button"
                              className={'btn btn-sm ' + (q.cabin === code || (!q.cabin && code === 'economy') ? 'btn-dark' : 'btn-outline')}
                              onClick={function () {
                                const p = new URLSearchParams(window.location.search);
                                p.set('cabin', code);
                                navigate('/book/flight/' + itemId + '?' + p.toString());
                              }}
                            >
                              {(q.cabin === code || (!q.cabin && code === 'economy')) ? 'Selected' : 'Select'}
                            </button>
                          </div>
                        </label>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {service === 'train' ? (
                <div className="card card-pad">
                  <h3>Pick your class & seats</h3>
                  <div className="row gap-8 wrap mb-16">
                    {resolved.item.classes.map(function (c) {
                      return (
                        <button
                          key={c.code}
                          type="button"
                          className={'btn btn-sm ' + (resolved.options.trainClass.code === c.code ? 'btn-dark' : 'btn-outline')}
                          onClick={function () {
                            const p = new URLSearchParams(window.location.search);
                            p.set('class', c.code);
                            setSeats([]);
                            navigate('/book/train/' + itemId + '?' + p.toString());
                          }}
                        >
                          {c.code} · {formatMoney(c.priceUSD, currency)}
                        </button>
                      );
                    })}
                  </div>
                  <p className="small muted">
                    {resolved.options.trainClass.name} · {resolved.options.trainClass.comfort} — select {resolved.quantity} seat(s).
                  </p>
                  <SeatMap
                    coaches={resolved.options.seatMap}
                    berth={resolved.options.trainClass.layout === 'berth'}
                    selected={seats}
                    onToggle={function (id) {
                      setSeats(function (prev) {
                        const idx = prev.indexOf(id);
                        if (idx >= 0) {
                          const next = prev.slice();
                          next.splice(idx, 1);
                          return next;
                        }
                        if (prev.length >= resolved.quantity) return prev;
                        return prev.concat([id]);
                      });
                      setErrors(function (e) {
                        const n = Object.assign({}, e);
                        delete n.seats;
                        return n;
                      });
                    }}
                  />
                  <div className="row-between">
                    <span className={'small ' + (errors.seats ? 'text-danger bold' : 'muted')}>
                      {errors.seats || 'Selected: ' + (seats.length ? seats.join(', ') : 'none yet')}
                    </span>
                    <span className="badge badge-coral">{seats.length}/{resolved.quantity}</span>
                  </div>
                </div>
              ) : null}

              {service === 'bus' ? (
                <div className="card card-pad">
                  <h3>Pick your seats</h3>
                  <p className="small muted">{resolved.item.busType.comfort} — select {resolved.quantity} seat(s).</p>
                  <SeatMap
                    coaches={[{ id: 'C1', seats: resolved.options.seatLayout }]}
                    berth={resolved.options.layout === 'sleeper'}
                    selected={seats}
                    onToggle={function (id) {
                      setSeats(function (prev) {
                        const idx = prev.indexOf(id);
                        if (idx >= 0) {
                          const next = prev.slice();
                          next.splice(idx, 1);
                          return next;
                        }
                        if (prev.length >= resolved.quantity) return prev;
                        return prev.concat([id]);
                      });
                      setErrors(function (e) {
                        const n = Object.assign({}, e);
                        delete n.seats;
                        return n;
                      });
                    }}
                  />
                  <div className="row-between">
                    <span className={'small ' + (errors.seats ? 'text-danger bold' : 'muted')}>
                      {errors.seats || 'Selected: ' + (seats.length ? seats.join(', ') : 'none yet')}
                    </span>
                    <span className="badge badge-coral">{seats.length}/{resolved.quantity}</span>
                  </div>
                </div>
              ) : null}

              {service === 'cafe' ? (
                <div className="card card-pad">
                  <h3>Pre-order from the menu (optional)</h3>
                  <p className="small muted">Skip the queue — your table’s order is ready when you arrive.</p>
                  <div className="mt-16">
                    {resolved.item.menu.slice(0, 10).map(function (m) {
                      return (
                        <div className="menu-item" key={m.id}>
                          <div>
                            <div className="bold">{m.name}</div>
                            <div className="tiny muted">{m.cat}{m.tag ? ' · ' + m.tag : ''}</div>
                          </div>
                          <div className="row gap-16">
                            <strong>{formatMoney(m.priceUSD, currency)}</strong>
                            <div className="qty">
                              <button
                                type="button"
                                aria-label="Less"
                                onClick={function () {
                                  setMenuQty(function (prev) {
                                    const n = Object.assign({}, prev);
                                    n[m.id] = Math.max(0, (n[m.id] || 0) - 1);
                                    return n;
                                  });
                                }}
                              >
                                <MinusIcon size={14} />
                              </button>
                              <span className="n">{menuQty[m.id] || 0}</span>
                              <button
                                type="button"
                                aria-label="More"
                                onClick={function () {
                                  setMenuQty(function (prev) {
                                    const n = Object.assign({}, prev);
                                    n[m.id] = (n[m.id] || 0) + 1;
                                    return n;
                                  });
                                }}
                              >
                                <PlusIcon size={14} />
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  {preOrderTotal > 0 ? (
                    <div className="row-between mt-16">
                      <span className="muted small">Pre-order total (added to your booking)</span>
                      <strong>{formatMoney(preOrderTotal, currency)}</strong>
                    </div>
                  ) : null}
                </div>
              ) : null}

              {service === 'car' ? (
                <div className="card card-pad">
                  <h3>Add extras</h3>
                  <div className="stack-12 mt-16">
                    {[
                      { id: 'gps', label: 'GPS navigation unit', price: 3 },
                      { id: 'childSeat', label: 'Child safety seat', price: 4 },
                      { id: 'driver', label: 'Professional driver (per day)', price: 18 },
                    ].map(function (a) {
                      return (
                        <label className="check" key={a.id}>
                          <input
                            type="checkbox"
                            checked={addons[a.id]}
                            onChange={function (e) {
                              setAddons(function (prev) {
                                const n = Object.assign({}, prev);
                                n[a.id] = e.target.checked;
                                return n;
                              });
                            }}
                          />
                          <span style={{ flex: 1 }}>{a.label}</span>
                          <strong>{formatMoney(a.price * resolved.options.days, currency)}</strong>
                        </label>
                      );
                    })}
                  </div>
                </div>
              ) : null}

              {service === 'ride' ? (
                <div className="card card-pad">
                  <h3>Ride options</h3>
                  <div className="form-grid mt-16">
                    <div className="field">
                      <label>Pick-up timing</label>
                      <select
                        className="select"
                        value={resolved.options.when}
                        onChange={function (e) {
                          const p = new URLSearchParams(window.location.search);
                          p.set('when', e.target.value);
                          navigate('/book/ride/' + itemId + '?' + p.toString());
                        }}
                      >
                        <option value="now">Ride now (~{resolved.item.etaMin} min away)</option>
                        <option value="later">Schedule for later</option>
                      </select>
                    </div>
                    <div className="field">
                      <label>Payment preference</label>
                      <select className="select" value={payMethod} onChange={function (e) { setPayMethod(e.target.value); }}>
                        <option value="card">Card</option>
                        <option value="upi">UPI</option>
                        <option value="wallet">Voyagr Wallet</option>
                      </select>
                    </div>
                    <div className="field span-2">
                      <label>Note for your driver (optional)</label>
                      <textarea
                        className="textarea"
                        placeholder="e.g. Meet me at the north gate, two bags"
                        value={rideNote}
                        onChange={function (e) {
                          setRideNote(e.target.value);
                        }}
                      />
                    </div>
                  </div>
                </div>
              ) : null}

              {/* traveller details */}
              <div className="card card-pad">
                <h3>Who’s travelling?</h3>
                <div className="form-grid mt-16">
                  <div className="field">
                    <label>First name</label>
                    <input
                      className={'input' + (errors.firstName ? ' error' : '')}
                      value={contact.firstName}
                      onChange={function (e) { setContact(function (c) { return Object.assign({}, c, { firstName: e.target.value }); }); }}
                      placeholder="Aarav"
                    />
                    {errors.firstName ? <span className="field-error">{errors.firstName}</span> : null}
                  </div>
                  <div className="field">
                    <label>Last name</label>
                    <input
                      className={'input' + (errors.lastName ? ' error' : '')}
                      value={contact.lastName}
                      onChange={function (e) { setContact(function (c) { return Object.assign({}, c, { lastName: e.target.value }); }); }}
                      placeholder="Sharma"
                    />
                    {errors.lastName ? <span className="field-error">{errors.lastName}</span> : null}
                  </div>
                  <div className="field">
                    <label>Email (tickets are sent here)</label>
                    <input
                      className={'input' + (errors.email ? ' error' : '')}
                      value={contact.email}
                      onChange={function (e) { setContact(function (c) { return Object.assign({}, c, { email: e.target.value }); }); }}
                      placeholder="you@email.com"
                      type="email"
                    />
                    {errors.email ? <span className="field-error">{errors.email}</span> : null}
                  </div>
                  <div className="field">
                    <label>Phone</label>
                    <input
                      className={'input' + (errors.phone ? ' error' : '')}
                      value={contact.phone}
                      onChange={function (e) { setContact(function (c) { return Object.assign({}, c, { phone: e.target.value }); }); }}
                      placeholder="+91 98765 43210"
                      type="tel"
                    />
                    {errors.phone ? <span className="field-error">{errors.phone}</span> : null}
                  </div>

                  {(service === 'flight' || service === 'train' || service === 'bus') && resolved.quantity > 1 ? (
                    <React.Fragment>
                      <div className="span-2">
                        <div className="field-label">Traveller names (as on ID)</div>
                      </div>
                      {Array.from({ length: resolved.quantity - 1 }).map(function (_, i) {
                        return (
                          <div className="field" key={i}>
                            <label>Traveller {i + 2}</label>
                            <input
                              className={'input' + (errors['traveler' + i] ? ' error' : '')}
                              value={travelerNames[i] || ''}
                              onChange={function (e) {
                                const v = e.target.value;
                                setTravelerNames(function (prev) {
                                  const n = prev.slice();
                                  n[i] = v;
                                  return n;
                                });
                              }}
                              placeholder="Full name"
                            />
                          </div>
                        );
                      })}
                    </React.Fragment>
                  ) : null}
                </div>
              </div>

              <div className="row-between">
                <Link className="btn btn-ghost" to={'/search/' + service}>
                  ← Back to results
                </Link>
                <button
                  className="btn btn-primary btn-lg"
                  onClick={function () {
                    if (validateStep1()) {
                      setStep(2);
                      window.scrollTo(0, 0);
                    } else {
                      toast('Please fix the highlighted fields', 'error');
                    }
                  }}
                >
                  Continue to payment
                </button>
              </div>
            </React.Fragment>
          ) : (
            /* --------------------------- step 2: payment --------------------------- */
            <React.Fragment>
              <div className="card card-pad">
                <div className="row-between mb-16">
                  <h3 style={{ margin: 0 }}>How would you like to pay?</h3>
                  <span className="badge badge-success">
                    <ShieldIcon size={14} /> 256-bit secure (demo)
                  </span>
                </div>

                <div className="pay-methods mb-24">
                  <button className={'pay-method' + (payMethod === 'card' ? ' active' : '')} onClick={function () { setPayMethod('card'); }}>
                    <CardIcon size={20} /> Credit / debit card
                  </button>
                  <button className={'pay-method' + (payMethod === 'upi' ? ' active' : '')} onClick={function () { setPayMethod('upi'); }}>
                    <strong style={{ fontSize: '1.05rem' }}>UPI</strong>
                    <span className="tiny muted">India instant pay</span>
                  </button>
                  <button className={'pay-method' + (payMethod === 'wallet' ? ' active' : '')} onClick={function () { setPayMethod('wallet'); }}>
                    <strong style={{ fontSize: '1.05rem' }}>Voyagr Wallet</strong>
                    <span className="tiny muted">Balance $500 (demo)</span>
                  </button>
                </div>

                {payMethod === 'card' ? (
                  <div className="form-grid">
                    <div className="field span-2">
                      <label>Card number</label>
                      <input
                        className={'input' + (errors.number ? ' error' : '')}
                        value={card.number}
                        onChange={function (e) {
                          const v = e.target.value;
                          setCard(function (c) { return Object.assign({}, c, { number: v }); });
                        }}
                        placeholder="4242 4242 4242 4242"
                        inputMode="numeric"
                      />
                      {errors.number ? <span className="field-error">{errors.number}</span> : <span className="field-hint">Test gateway — use 4242 4242 4242 4242 or any Luhn-valid number.</span>}
                    </div>
                    <div className="field">
                      <label>Name on card</label>
                      <input
                        className={'input' + (errors.cardName ? ' error' : '')}
                        value={card.name}
                        onChange={function (e) { setCard(function (c) { return Object.assign({}, c, { name: e.target.value }); }); }}
                        placeholder={contact.firstName + ' ' + contact.lastName}
                      />
                      {errors.cardName ? <span className="field-error">{errors.cardName}</span> : null}
                    </div>
                    <div className="row gap-12">
                      <div className="field" style={{ flex: 1 }}>
                        <label>Expiry</label>
                        <input
                          className={'input' + (errors.exp ? ' error' : '')}
                          value={card.exp}
                          onChange={function (e) { setCard(function (c) { return Object.assign({}, c, { exp: e.target.value }); }); }}
                          placeholder="MM/YY"
                        />
                        {errors.exp ? <span className="field-error">{errors.exp}</span> : null}
                      </div>
                      <div className="field" style={{ flex: 1 }}>
                        <label>CVV</label>
                        <input
                          className={'input' + (errors.cvv ? ' error' : '')}
                          value={card.cvv}
                          onChange={function (e) { setCard(function (c) { return Object.assign({}, c, { cvv: e.target.value }); }); }}
                          placeholder="123"
                          inputMode="numeric"
                        />
                        {errors.cvv ? <span className="field-error">{errors.cvv}</span> : null}
                      </div>
                    </div>
                  </div>
                ) : null}

                {payMethod === 'upi' ? (
                  <div className="field">
                    <label>UPI ID</label>
                    <input
                      className={'input' + (errors.upi ? ' error' : '')}
                      value={upi}
                      onChange={function (e) { setUpi(e.target.value); }}
                      placeholder="yourname@bank"
                    />
                    {errors.upi ? <span className="field-error">{errors.upi}</span> : <span className="field-hint">You’ll approve the collect request in your UPI app (simulated).</span>}
                  </div>
                ) : null}

                {payMethod === 'wallet' ? (
                  <div className="card card-pad" style={{ background: 'var(--cream)', boxShadow: 'none' }}>
                    <div className="row-between">
                      <div>
                        <div className="bold">Voyagr Wallet</div>
                        <div className="small muted">Demo balance: $500 · instant settlement</div>
                      </div>
                      <CheckIcon size={22} style={{ color: 'var(--success)' }} />
                    </div>
                  </div>
                ) : null}
              </div>

              <div className="card card-pad">
                <h3>Billing address</h3>
                <div className="form-grid mt-16">
                  <div className="field">
                    <label>Country</label>
                    <select className="select" defaultValue="IN">
                      <option value="IN">India</option>
                      <option value="US">United States</option>
                      <option value="GB">United Kingdom</option>
                      <option value="AE">UAE</option>
                      <option value="SG">Singapore</option>
                      <option value="AU">Australia</option>
                    </select>
                  </div>
                  <div className="field">
                    <label>ZIP / postal code</label>
                    <input className="input" placeholder="560001" />
                  </div>
                </div>
              </div>

              <div className="row-between">
                <button className="btn btn-ghost" onClick={function () { setStep(1); window.scrollTo(0, 0); }}>
                  ← Back to details
                </button>
                <button
                  className="btn btn-primary btn-lg"
                  data-testid="pay-btn"
                  disabled={processing}
                  onClick={payNow}
                >
                  {processing ? 'Processing payment…' : 'Pay ' + formatMoney(pricing.totalUSD, currency)}
                </button>
              </div>

              <p className="tiny muted center">
                <InfoIcon size={13} /> This is a demo payment gateway — no real money moves. Feel free to use test cards.
              </p>
            </React.Fragment>
          )}
        </div>

        {/* ---------------------------- summary ---------------------------- */}
        <div className="summary-card">
          <div className="summary-art" style={{ backgroundImage: 'url(' + resolved.image + ')' }} />
          <div className="summary-body">
            <div className="badge badge-coral mb-8">{meta.icon} {meta.label}</div>
            <h3 style={{ fontSize: '1.18rem', marginBottom: 2 }}>{resolved.title}</h3>
            <div className="small muted mb-8">{resolved.subtitle}</div>
            <div className="small muted mb-16">{resolved.dateLabel}</div>

            <div className="price-row">
              <span>
                {formatMoney(baseUnit, currency)} × {resolved.quantity} {resolved.unitLabel}
                {resolved.quantity > 1 ? 's' : ''}
              </span>
              <span>{formatMoney(baseUnit * resolved.quantity, currency)}</span>
            </div>
            {preOrderTotal > 0 ? (
              <div className="price-row">
                <span>Pre-order</span>
                <span>{formatMoney(preOrderTotal, currency)}</span>
              </div>
            ) : null}
            {addonTotal > 0 ? (
              <div className="price-row">
                <span>Extras</span>
                <span>{formatMoney(addonTotal, currency)}</span>
              </div>
            ) : null}
            {promo && promoResult.discountUSD > 0 ? (
              <div className="price-row">
                <span className="disc">Promo · {promo.code}</span>
                <span className="disc">−{formatMoney(promoResult.discountUSD, currency)}</span>
              </div>
            ) : null}
            <div className="price-row">
              <span>{pricing.taxLabel}</span>
              <span>{formatMoney(pricing.taxesUSD, currency)}</span>
            </div>
            <div className="price-row">
              <span>Booking fee</span>
              <span>{formatMoney(pricing.feesUSD, currency)}</span>
            </div>
            <div className="price-row total">
              <span>Total</span>
              <span>{formatMoney(pricing.totalUSD, currency)}</span>
            </div>

            <div className="mt-16">
              <div className="field-label mb-8">Promo code</div>
              <div className="promo-row">
                <input
                  className="input"
                  placeholder="VOYAGR10"
                  value={promoInput}
                  onChange={function (e) {
                    setPromoInput(e.target.value);
                  }}
                />
                <button
                  className="btn btn-dark btn-sm"
                  onClick={function () {
                    const res = applyPromo(promoInput, service, subtotalBase);
                    if (res.ok) {
                      setPromo({ code: promoInput.toUpperCase() });
                      toast(res.message, 'success');
                    } else {
                      setPromo(null);
                      toast(res.message, 'error');
                    }
                  }}
                >
                  Apply
                </button>
              </div>
              <div className="tiny muted mt-8">
                Try VOYAGR10, FLY5, STAY15, RIDE2, RAIL10, FEAST20, ROADTRIP or WANDER25.
              </div>
            </div>

            <div className="divider" />
            <div className="row gap-8 tiny muted">
              <ShieldIcon size={15} /> Secure demo checkout · Free cancellation where applicable
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

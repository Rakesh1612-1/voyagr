/* ------------------------------------------------------------------
   Confirmation page — e-ticket with booking details.
------------------------------------------------------------------- */

import React from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useApp } from '../store/store';
import { formatMoney, formatDateHuman } from '../lib/format';
import { CheckIcon, TicketIcon, ArrowIcon, ShieldIcon, BagIcon } from '../components/Icons';

const SERVICE_LABEL = {
  hotel: 'Stay',
  flight: 'Flight',
  train: 'Train',
  bus: 'Bus',
  cafe: 'Café table',
  car: 'Car rental',
  ride: 'Ride',
  experience: 'Experience',
};

export default function Confirmation() {
  const { bookingId } = useParams();
  const navigate = useNavigate();
  const { bookings, currency, toast, user } = useApp();

  const booking = bookings.filter(function (b) {
    return b.id === bookingId;
  })[0];

  if (!booking) {
    return (
      <div className="container section">
        <div className="empty">
          <h3>Booking not found</h3>
          <p>It may have been made in another browser session. Check My Trips for your bookings.</p>
          <Link className="btn btn-primary" to="/trips">
            Go to My Trips
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container" style={{ paddingTop: 30, paddingBottom: 60, maxWidth: 860 }}>
      <div className="success-hero">
        <div className="success-icon">
          <CheckIcon size={40} />
        </div>
        <span className="eyebrow">Confirmed · {booking.id}</span>
        <h1 style={{ fontSize: 'clamp(1.9rem, 4vw, 2.6rem)', marginBottom: 8 }}>
          You’re all set{booking.contact && booking.contact.firstName ? ', ' + booking.contact.firstName : ''}!
        </h1>
        <p className="muted" style={{ maxWidth: 520, margin: '0 auto' }}>
          Your {SERVICE_LABEL[booking.service] ? SERVICE_LABEL[booking.service].toLowerCase() : 'booking'} is
          booked. A copy of this ticket has been sent to{' '}
          <strong>{booking.contact ? booking.contact.email : 'your email'}</strong>.
        </p>
        <div className="row gap-12 wrap mt-24" style={{ justifyContent: 'center' }}>
          <Link className="btn btn-primary" to="/trips">
            <TicketIcon size={18} /> View in My Trips
          </Link>
          <Link className="btn btn-outline" to="/">
            Book something else <ArrowIcon size={16} />
          </Link>
          <button
            className="btn btn-ghost"
            onClick={function () {
              window.print();
            }}
          >
            Print ticket
          </button>
        </div>
      </div>

      {/* ticket */}
      <div className="ticket mt-24">
        <div className="ticket-top">
          <div className="row-between wrap gap-12">
            <div>
              <div className="badge badge-amber mb-8">{SERVICE_LABEL[booking.service]} e-ticket</div>
              <h2 style={{ marginBottom: 4 }}>{booking.title}</h2>
              <div style={{ opacity: 0.85 }}>{booking.subtitle}</div>
            </div>
            <div style={{ textAlign: 'right' }}>
              <div className="tiny" style={{ opacity: 0.7, letterSpacing: '0.12em', textTransform: 'uppercase' }}>
                Booking reference
              </div>
              <div style={{ fontSize: '1.6rem', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                {booking.id}
              </div>
              <div className="tiny" style={{ opacity: 0.7 }}>
                Booked on {formatDateHuman(new Date(booking.createdAt).toISOString().slice(0, 10), 'month')}
              </div>
            </div>
          </div>
        </div>

        <div className="ticket-cut" />

        <div className="ticket-body">
          <div className="row-between wrap gap-24" style={{ alignItems: 'flex-start' }}>
            <div style={{ flex: 1, minWidth: 240 }}>
              {booking.details.map(function (d) {
                return (
                  <div className="kv" key={d.k}>
                    <span className="k">{d.k}</span>
                    <span className="v">{d.v}</span>
                  </div>
                );
              })}
              <div className="kv">
                <span className="k">Booked by</span>
                <span className="v">
                  {(booking.contact ? booking.contact.firstName + ' ' + booking.contact.lastName : 'Guest')}
                  {booking.travelers && booking.travelers.length
                    ? ' + ' + booking.travelers.length + ' traveller(s)'
                    : ''}
                </span>
              </div>
              <div className="kv">
                <span className="k">Payment</span>
                <span className="v">
                  {booking.payment.method === 'card'
                    ? booking.payment.brand + ' ····' + booking.payment.last4
                    : booking.payment.brand}
                </span>
              </div>
            </div>

            <div className="center">
              <div className="qr" aria-hidden="true" />
              <div className="tiny muted mt-8">Scan at check-in</div>
            </div>
          </div>

          <div className="divider" />

          <div className="row-between wrap gap-12">
            <div>
              <div className="tiny muted">Total paid ({booking.currency || currency})</div>
              <div style={{ fontSize: '1.9rem', fontFamily: 'var(--font-display)', fontWeight: 700 }}>
                {formatMoney(booking.pricing.totalUSD, booking.currency || currency)}
              </div>
              {booking.promo ? <span className="badge badge-success">Promo {booking.promo} applied</span> : null}
            </div>
            <div className="row gap-8 wrap">
              <span className="badge badge-success">
                <ShieldIcon size={13} /> {booking.status === 'cancelled' ? 'Cancelled' : 'Confirmed'}
              </span>
              <span className="badge">
                <BagIcon size={13} /> Manage anytime in My Trips
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="card card-pad mt-24 row-between wrap gap-12">
        <div>
          <h3 style={{ marginBottom: 4 }}>What’s next?</h3>
          <p className="muted mb-0">
            {user
              ? 'This booking is saved to your account. Manage, cancel or rebook from My Trips.'
              : 'Tip: create a free account so all your bookings sync to My Trips.'}
          </p>
        </div>
        <div className="row gap-8">
          {user ? null : (
            <Link className="btn btn-dark" to="/signup">
              Create account
            </Link>
          )}
          <button
            className="btn btn-primary"
            onClick={function () {
              toast('Happy travels! ✈️', 'success');
              navigate('/trips');
            }}
          >
            Go to My Trips
          </button>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------
   Search results — one page powers all eight services with
   filters, sorting, and service-specific result cards.
------------------------------------------------------------------- */

import React, { useMemo, useState, useEffect } from 'react';
import { Link, useParams, useSearchParams, useNavigate } from 'react-router-dom';
import SearchForm from '../components/SearchForm';
import { useApp } from '../store/store';
import { formatMoney, formatDuration, formatTime12, formatDateHuman, diffDays, todayISO, addDays } from '../lib/format';
import { CITY_BY_ID, cityShort, CITIES } from '../data/cities';
import { generateFlights, flightAirlines } from '../data/flights';
import { HOTELS, hotelsByCity, AMENITIES } from '../data/hotels';
import { trainsForRoute, TRAINS } from '../data/trains';
import { generateBuses, BUS_TYPES } from '../data/buses';
import { cafesByCity, CAFES } from '../data/cafes';
import { getCarOptions, CAR_CATEGORIES } from '../data/cars';
import { getRideQuote, cityAreas, vehiclesForCity, distanceBetweenAreas } from '../data/rides';
import { EXPERIENCES, experiencesByCity, EXPERIENCE_CATEGORIES } from '../data/experiences';
import {
  SERVICE_ICONS,
  SERVICE_META,
  FilterIcon,
  CloseIcon,
  StarIcon,
  ClockIcon,
  BagIcon,
  ArrowIcon,
  CheckIcon,
  PinIcon,
  CafeIcon,
} from '../components/Icons';

function starsRow(n) {
  return <span className="stars">{'★★★★★'.slice(0, n)}</span>;
}

function priceRange(min, max, value, onChange, currency) {
  return (
    <div>
      <div className="row-between small bold mb-8">
        <span>Max price</span>
        <span className="text-coral">{formatMoney(value, currency)}</span>
      </div>
      <input
        className="range"
        type="range"
        min={Math.floor(min)}
        max={Math.ceil(max)}
        step={Math.max(1, Math.round((max - min) / 50))}
        value={value}
        onChange={function (e) {
          onChange(Number(e.target.value));
        }}
      />
    </div>
  );
}

/* ------------------------- result card shells ------------------------- */

function CheckFilter(props) {
  return (
    <label className="check">
      <input
        type="checkbox"
        checked={props.checked}
        onChange={function (e) {
          props.onToggle(props.id, e.target.checked);
        }}
      />
      <span style={{ flex: 1 }}>{props.label}</span>
      {props.count != null ? <span className="tiny muted">{props.count}</span> : null}
    </label>
  );
}

export default function SearchPage() {
  const { service } = useParams();
  const [params, setParams] = useSearchParams();
  const navigate = useNavigate();
  const { currency, pushRecent, toast } = useApp();

  const [formService, setFormService] = useState(service);
  const [sort, setSort] = useState('best');
  const [maxPrice, setMaxPrice] = useState(null);
  const [filters, setFilters] = useState({});
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(
    function () {
      setFormService(service);
      setSort('best');
      setFilters({});
      setMaxPrice(null);
      setFiltersOpen(false);
    },
    [service, params.toString()]
  );

  useEffect(
    function () {
      setLoading(true);
      const t = window.setTimeout(function () {
        setLoading(false);
      }, 240);
      return function () {
        window.clearTimeout(t);
      };
    },
    [service, params.toString()]
  );

  const q = useMemo(
    function () {
      const obj = {};
      params.forEach(function (v, k) {
        obj[k] = v;
      });
      return obj;
    },
    [params]
  );

  /* ------------------------ generate raw results ------------------------ */
  const raw = useMemo(
    function () {
      if (service === 'flight') {
        return generateFlights(q.from, q.to, q.date || todayISO());
      }
      if (service === 'hotel') {
        return hotelsByCity(q.city);
      }
      if (service === 'train') {
        return trainsForRoute(q.from, q.to);
      }
      if (service === 'bus') {
        return generateBuses(q.from, q.to, q.date || todayISO());
      }
      if (service === 'cafe') {
        return cafesByCity(q.city);
      }
      if (service === 'car') {
        const days = Math.max(1, diffDays(q.pickup || todayISO(), q.dropoff || addDays(todayISO(), 3)));
        return getCarOptions(q.city, days);
      }
      if (service === 'ride') {
        const areas = cityAreas(q.city);
        const pickup = Number(q.pickup || 0);
        const dropoff = Number(q.dropoff != null ? q.dropoff : 2);
        return vehiclesForCity(q.city)
          .map(function (v) {
            return getRideQuote(q.city, pickup, dropoff, v.id, q.when || 'now');
          })
          .filter(Boolean);
      }
      if (service === 'experience') {
        return experiencesByCity(q.city);
      }
      return [];
    },
    [service, q.from, q.to, q.city, q.date, q.pickup, q.dropoff, q.when]
  );

  /* --------------------------- filters state --------------------------- */
  function toggleFilter(key, id, checked) {
    setFilters(function (f) {
      const list = (f[key] || []).slice();
      const idx = list.indexOf(id);
      if (checked && idx < 0) list.push(id);
      if (!checked && idx >= 0) list.splice(idx, 1);
      const next = Object.assign({}, f);
      next[key] = list;
      return next;
    });
  }

  /* ------------------------------ filtering ------------------------------ */
  const bounds = useMemo(
    function () {
      if (!raw.length) return { min: 0, max: 100 };
      const prices = raw.map(function (r) {
        return r.priceUSD || 0;
      });
      return { min: Math.min.apply(null, prices), max: Math.max.apply(null, prices) };
    },
    [raw]
  );

  useEffect(
    function () {
      if (maxPrice == null && raw.length) setMaxPrice(Math.ceil(bounds.max));
    },
    [bounds, raw, maxPrice]
  );

  const filtered = useMemo(
    function () {
      let list = raw.slice();
      const cap = maxPrice != null ? maxPrice : bounds.max;

      if (service === 'flight') {
        if (filters.stops && filters.stops.length) {
          list = list.filter(function (f) {
            return filters.stops.indexOf(String(f.stops)) >= 0;
          });
        }
        if (filters.airlines && filters.airlines.length) {
          list = list.filter(function (f) {
            return filters.airlines.indexOf(f.airline.code) >= 0;
          });
        }
        if (filters.depTime && filters.depTime.length) {
          list = list.filter(function (f) {
            const h = Number(f.dep.split(':')[0]);
            return filters.depTime.some(function (slot) {
              if (slot === 'morning') return h >= 5 && h < 12;
              if (slot === 'afternoon') return h >= 12 && h < 17;
              return h >= 17;
            });
          });
        }
      }
      if (service === 'hotel') {
        if (filters.stars && filters.stars.length) {
          list = list.filter(function (h) {
            return filters.stars.indexOf(String(h.stars)) >= 0;
          });
        }
        if (filters.amenities && filters.amenities.length) {
          list = list.filter(function (h) {
            return filters.amenities.every(function (a) {
              return h.amenities.indexOf(a) >= 0;
            });
          });
        }
        if (filters.tags && filters.tags.length) {
          list = list.filter(function (h) {
            return filters.tags.some(function (t) {
              return h.tags.indexOf(t) >= 0;
            });
          });
        }
      }
      if (service === 'bus' && filters.busTypes && filters.busTypes.length) {
        list = list.filter(function (b) {
          return filters.busTypes.indexOf(b.busType.id) >= 0;
        });
      }
      if (service === 'car') {
        if (filters.cats && filters.cats.length) {
          list = list.filter(function (c) {
            return filters.cats.indexOf(c.category) >= 0;
          });
        }
        if (filters.transmission && filters.transmission.length) {
          list = list.filter(function (c) {
            return filters.transmission.indexOf(c.transmission) >= 0;
          });
        }
      }
      if (service === 'cafe' && filters.bands && filters.bands.length) {
        list = list.filter(function (c) {
          return filters.bands.indexOf(String(c.priceBand)) >= 0;
        });
      }
      if (service === 'experience') {
        if (filters.cats && filters.cats.length) {
          list = list.filter(function (e) {
            return filters.cats.indexOf(e.category) >= 0;
          });
        }
        if (filters.hours && filters.hours.length) {
          list = list.filter(function (e) {
            return filters.hours.some(function (h) {
              if (h === 'short') return e.hours <= 3;
              if (h === 'mid') return e.hours > 3 && e.hours <= 5;
              return e.hours > 5;
            });
          });
        }
      }

      list = list.filter(function (r) {
        return (r.priceUSD || 0) <= cap;
      });

      if (sort === 'price') list.sort(function (a, b) { return a.priceUSD - b.priceUSD; });
      else if (sort === 'rating') list.sort(function (a, b) { return (b.rating || 0) - (a.rating || 0); });
      else if (sort === 'duration') list.sort(function (a, b) { return (a.durationMin || 0) - (b.durationMin || 0); });
      else if (sort === 'dep') list.sort(function (a, b) { return String(a.dep || '').localeCompare(String(b.dep || '')); });

      return list;
    },
    [raw, filters, maxPrice, bounds, sort, service]
  );

  function bookLink(item) {
    if (service === 'hotel') {
      return (
        '/book/hotel/' + item.id +
        '?checkin=' + (q.checkin || addDays(todayISO(), 7)) +
        '&checkout=' + (q.checkout || addDays(todayISO(), 10)) +
        '&guests=' + (q.guests || 2) + '&rooms=' + (q.rooms || 1) + '&room=deluxe'
      );
    }
    if (service === 'flight') {
      return (
        '/book/flight/' + item.id +
        '?from=' + item.from + '&to=' + item.to + '&date=' + item.date +
        '&cabin=' + (q.cabin || 'economy') + '&pax=' + (q.pax || 1)
      );
    }
    if (service === 'train') {
      return '/book/train/' + item.id + '?date=' + (q.date || todayISO()) + '&class=' + item.classes[1].code + '&pax=' + (q.pax || 1);
    }
    if (service === 'bus') {
      return '/book/bus/' + item.id + '?date=' + (q.date || todayISO()) + '&pax=' + (q.pax || 1);
    }
    if (service === 'cafe') {
      return '/book/cafe/' + item.id + '?date=' + (q.date || todayISO()) + '&slot=19:00&party=' + (q.party || 2);
    }
    if (service === 'car') {
      return (
        '/book/car/' + item.id +
        '?city=' + (q.city || 'goa') +
        '&pickup=' + (q.pickup || todayISO()) + '&dropoff=' + (q.dropoff || addDays(todayISO(), 3))
      );
    }
    if (service === 'ride') {
      return (
        '/book/ride/quote?city=' + (q.city || 'delhi') +
        '&pickup=' + (q.pickup || 0) + '&dropoff=' + (q.dropoff != null ? q.dropoff : 2) +
        '&vehicle=' + item.vehicle.id + '&when=' + (q.when || 'now')
      );
    }
    if (service === 'experience') {
      return (
        '/book/experience/' + item.id +
        '?date=' + (q.date || todayISO()) + '&slot=' + item.slots[0] + '&guests=' + (q.guests || 2)
      );
    }
    return '/';
  }

  /* ------------------------------- filter UI ------------------------------- */
  function filterGroups() {
    const groups = [];
    if (service === 'flight') {
      const airlines = flightAirlines(raw);
      groups.push({
        key: 'stops',
        label: 'Stops',
        options: [
          { id: '0', label: 'Non-stop' },
          { id: '1', label: '1 stop' },
          { id: '2', label: '2+ stops' },
        ],
      });
      groups.push({
        key: 'airlines',
        label: 'Airlines',
        options: airlines.map(function (a) {
          return { id: a.code, label: a.name };
        }),
      });
      groups.push({
        key: 'depTime',
        label: 'Departure time',
        options: [
          { id: 'morning', label: 'Morning (5–12)' },
          { id: 'afternoon', label: 'Afternoon (12–17)' },
          { id: 'evening', label: 'Evening (17+)' },
        ],
      });
    }
    if (service === 'hotel') {
      groups.push({
        key: 'stars',
        label: 'Star rating',
        options: [5, 4, 3].map(function (s) {
          return { id: String(s), label: s + ' stars' };
        }),
      });
      groups.push({
        key: 'amenities',
        label: 'Amenities',
        options: AMENITIES.slice(0, 8).map(function (a) {
          return { id: a.id, label: a.label };
        }),
      });
      groups.push({
        key: 'tags',
        label: 'Style',
        options: [
          { id: 'beach', label: 'Beachfront' },
          { id: 'romantic', label: 'Romantic' },
          { id: 'family', label: 'Family' },
          { id: 'business', label: 'Business' },
          { id: 'heritage', label: 'Heritage' },
          { id: 'boutique', label: 'Boutique' },
          { id: 'luxury', label: 'Luxury' },
          { id: 'nightlife', label: 'Nightlife' },
        ],
      });
    }
    if (service === 'bus') {
      groups.push({
        key: 'busTypes',
        label: 'Bus type',
        options: BUS_TYPES.map(function (b) {
          return { id: b.id, label: b.name };
        }),
      });
    }
    if (service === 'car') {
      groups.push({
        key: 'cats',
        label: 'Category',
        options: CAR_CATEGORIES.map(function (c) {
          return { id: c.id, label: c.label };
        }),
      });
      groups.push({
        key: 'transmission',
        label: 'Transmission',
        options: [
          { id: 'Automatic', label: 'Automatic' },
          { id: 'Manual', label: 'Manual' },
        ],
      });
    }
    if (service === 'cafe') {
      groups.push({
        key: 'bands',
        label: 'Price band',
        options: [
          { id: '1', label: '₹ · Budget' },
          { id: '2', label: '₹₹ · Mid-range' },
          { id: '3', label: '₹₹₹ · Premium' },
        ],
      });
    }
    if (service === 'experience') {
      groups.push({
        key: 'cats',
        label: 'Category',
        options: EXPERIENCE_CATEGORIES.map(function (c) {
          return { id: c.id, label: c.label };
        }),
      });
      groups.push({
        key: 'hours',
        label: 'Duration',
        options: [
          { id: 'short', label: 'Up to 3 hours' },
          { id: 'mid', label: '3–5 hours' },
          { id: 'long', label: '5 hours +' },
        ],
      });
    }
    return groups;
  }

  const sorts = [
    { id: 'best', label: 'Best' },
    { id: 'price', label: 'Cheapest' },
    service === 'flight' || service === 'bus' || service === 'train' || service === 'ride'
      ? { id: 'duration', label: 'Fastest' }
      : { id: 'rating', label: 'Top rated' },
    service === 'flight' || service === 'bus' || service === 'train'
      ? { id: 'dep', label: 'Departure' }
      : { id: 'rating', label: 'Top rated' },
  ].filter(function (s, i, arr) {
    return arr.findIndex(function (x) { return x.id === s.id; }) === i;
  });

  const meta = SERVICE_META[service] || SERVICE_META.hotel;
  const IconC = SERVICE_ICONS[service] || SERVICE_META.hotel;

  /* ------------------------------ result cards ------------------------------ */
  function ResultCard(props) {
    const item = props.item;

    if (service === 'flight') {
      return (
        <div className="result-card flight-card">
          <div>
            <div className="airline-row">
              <div className="airline-dot" style={{ background: item.airline.color }}>{item.airline.code}</div>
              <div>
                <div className="bold">{item.airline.name}</div>
                <div className="tiny muted">{item.flightNo} · {item.aircraft}</div>
              </div>
              {item.stops === 0 ? <span className="badge badge-teal">Non-stop</span> : <span className="badge badge-amber">{item.stops} stop{item.stops > 1 ? 's' : ''}</span>}
              <span className="badge badge-outline hide-mobile">{item.onTime}% on time</span>
            </div>
            <div className="timeline">
              <div>
                <div className="t-time">{formatTime12(item.dep)}</div>
                <div className="t-code">{CITY_BY_ID[item.from].code}</div>
              </div>
              <div className="t-line">
                <div className="t-dur">{formatDuration(item.durationMin)}</div>
                <div className="t-bar" />
                <div className="t-stops">
                  {item.stops === 0 ? 'Direct' : 'via ' + item.via.map(function (v) { return CITY_BY_ID[v].code; }).join(', ')}
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="t-time">
                  {formatTime12(item.arr)}
                  {item.arrDayOffset > 0 ? <sup className="text-coral tiny"> +{item.arrDayOffset}</sup> : null}
                </div>
                <div className="t-code">{CITY_BY_ID[item.to].code}</div>
              </div>
            </div>
            <div className="row gap-8 wrap tiny muted">
              <span className="row gap-4"><BagIcon size={14} /> {item.fares.economy.checkedBags} checked</span>
              <span>·</span>
              <span>{item.fares.economy.meals}</span>
              <span>·</span>
              <span>{item.seatsLeft} seats left</span>
            </div>
          </div>
          <div className="price-block">
            <div className="amount">{formatMoney(item.priceUSD, currency)}</div>
            <div className="per">per traveller</div>
            <Link to={bookLink(item)} className="btn btn-primary btn-sm">Select</Link>
          </div>
        </div>
      );
    }

    if (service === 'train' || service === 'bus') {
      const isTrain = service === 'train';
      return (
        <div className="result-card">
          <div className="row-between wrap gap-16">
            <div style={{ flex: 2, minWidth: 220 }}>
              <div className="row gap-12">
                <div className="airline-dot" style={{ background: isTrain ? '#0f8a6a' : '#d97706' }}>
                  {isTrain ? 'RAIL' : 'BUS'}
                </div>
                <div>
                  <div className="bold">{isTrain ? item.name + ' · ' + item.number : item.operator}</div>
                  <div className="tiny muted">
                    {isTrain ? item.days : item.busType.name + ' · ' + item.busType.comfort}
                  </div>
                </div>
              </div>
              <div className="timeline">
                <div>
                  <div className="t-time">{formatTime12(item.dep)}</div>
                  <div className="t-code">{cityShort(item.from)}</div>
                </div>
                <div className="t-line">
                  <div className="t-dur">{formatDuration(item.durationMin)}</div>
                  <div className="t-bar" />
                  <div className="t-stops">{item.distanceKm} km</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div className="t-time">
                    {formatTime12(item.arr)}
                    {item.arrDayOffset > 0 ? <sup className="text-coral tiny"> +{item.arrDayOffset}</sup> : null}
                  </div>
                  <div className="t-code">{cityShort(item.to)}</div>
                </div>
              </div>
              {isTrain ? (
                <div className="row gap-8 wrap">
                  {item.classes.map(function (c) {
                    return (
                      <span key={c.code} className="badge badge-outline">
                        {c.code} · from {formatMoney(c.priceUSD, currency)}
                      </span>
                    );
                  })}
                </div>
              ) : (
                <div className="row gap-8 wrap tiny muted">
                  {item.busType.amenities.map(function (a) {
                    return <span key={a} className="badge badge-outline">{a}</span>;
                  })}
                </div>
              )}
            </div>
            <div className="price-block">
              <div className="amount">{formatMoney(item.priceUSD, currency)}</div>
              <div className="per">per seat</div>
              <Link to={bookLink(item)} className="btn btn-primary btn-sm">
                {isTrain ? 'Choose seats' : 'Choose seats'}
              </Link>
            </div>
          </div>
        </div>
      );
    }

    if (service === 'ride') {
      return (
        <div className="result-card">
          <div className="row-between wrap gap-16">
            <div className="row gap-16" style={{ flex: 1, minWidth: 220 }}>
              <div className="service-icon" style={{ background: '#0891b2' }}>
                <IconC size={24} />
              </div>
              <div>
                <div className="bold">{item.vehicle.name}</div>
                <div className="tiny muted">
                  {item.vehicle.seats} seats · {item.vehicle.note} · arrives in ~{item.etaMin} min
                </div>
                <div className="row gap-8 tiny muted mt-8">
                  <PinIcon size={13} /> {item.from.name} → {item.to.name} · {item.distanceKm} km · {formatDuration(item.durationMin)}
                </div>
                {item.surge > 1 ? <span className="badge badge-amber mt-8">Surge ×{item.surge}</span> : null}
              </div>
            </div>
            <div className="price-block">
              <div className="amount">{formatMoney(item.priceUSD, currency)}</div>
              <div className="per">total fare</div>
              <Link to={bookLink(item)} className="btn btn-primary btn-sm">Book ride</Link>
            </div>
          </div>
        </div>
      );
    }

    if (service === 'car') {
      return (
        <div className="result-card with-image">
          <div className="result-art" style={{ backgroundImage: 'url(/img/road.jpg)' }}>
            <span className="badge badge-navy">{item.category}</span>
          </div>
          <div>
            <div className="row-between">
              <div>
                <h3 style={{ marginBottom: 2 }}>{item.name}</h3>
                <div className="tiny muted">{item.supplier} · {item.transmission} · {item.fuel}</div>
              </div>
              <div className="rating-pill">{item.rating} ★</div>
            </div>
            <div className="row gap-8 wrap mt-8">
              <span className="badge">{item.seats} seats</span>
              <span className="badge">{item.bags} bags</span>
              <span className="badge badge-teal">{item.mileageKm}</span>
              {item.freeCancellation ? <span className="badge badge-success">Free cancellation</span> : null}
            </div>
            <div className="tiny muted mt-8">
              {item.fuelPolicy} · deposit {formatMoney(item.depositUSD, currency)} · min age {item.minAge}
            </div>
          </div>
          <div className="price-block">
            <div className="amount">{formatMoney(item.totalPriceUSD, currency)}</div>
            <div className="per">{item.days} day{item.days > 1 ? 's' : ''} · {formatMoney(item.pricePerDayUSD, currency)}/day</div>
            <Link to={bookLink(item)} className="btn btn-primary btn-sm">Reserve</Link>
          </div>
        </div>
      );
    }

    // hotel, cafe, experience — image-led cards
    const isHotel = service === 'hotel';
    const isCafe = service === 'cafe';
    return (
      <div className="result-card with-image">
        <div className="result-art" style={{ backgroundImage: 'url(' + item.image + ')' }}>
          {isHotel ? <span className="badge badge-coral">{item.stars}★ hotel</span> : null}
          {isCafe ? <span className="badge badge-coral">{'₹'.repeat(item.priceBand)}</span> : null}
          {!isHotel && !isCafe ? <span className="badge badge-coral">{item.category}</span> : null}
        </div>
        <div>
          <div className="row-between">
            <div>
              <h3 style={{ marginBottom: 2 }}>
                {isHotel ? item.name : isCafe ? item.name : item.title}
              </h3>
              <div className="tiny muted row gap-4">
                <PinIcon size={13} />
                {isHotel ? item.area + ', ' + cityShort(item.city) : isCafe ? item.area + ', ' + cityShort(item.city) : cityShort(item.city) + ' · ' + item.hours + ' hours'}
              </div>
            </div>
            <div className="rating-pill">
              {(isHotel ? item.rating : item.rating).toFixed(1)} ★
              <small>{(item.reviews || 0).toLocaleString()} reviews</small>
            </div>
          </div>

          <p className="small muted" style={{ margin: '10px 0' }}>
            {(isHotel ? item.blurb : isCafe ? item.blurb : item.blurb).slice(0, 130)}…
          </p>

          {isHotel ? (
            <div className="row gap-8 wrap">
              {item.amenityLabels.slice(0, 4).map(function (a) {
                return <span key={a} className="badge">{a}</span>;
              })}
            </div>
          ) : null}
          {isCafe ? (
            <div className="row gap-8 wrap">
              {item.tags.map(function (t) {
                return <span key={t} className="badge">{t}</span>;
              })}
            </div>
          ) : null}
          {!isHotel && !isCafe ? (
            <div className="row gap-8 wrap">
              {item.includes.slice(0, 4).map(function (inc) {
                return <span key={inc.key} className="badge badge-teal">{inc.label}</span>;
              })}
            </div>
          ) : null}
        </div>
        <div className="price-block">
          <div className="amount">
            {formatMoney(isHotel ? item.priceUSD : isCafe ? item.priceUSD : item.priceUSD, currency)}
          </div>
          <div className="per">
            {isHotel ? 'per night' : isCafe ? 'avg. per person' : 'per person'}
          </div>
          <Link to={bookLink(item)} className="btn btn-primary btn-sm">
            {isHotel ? 'View rooms' : isCafe ? 'Reserve table' : 'Book now'}
          </Link>
        </div>
      </div>
    );
  }

  /* --------------------------------- page --------------------------------- */
  const hasFilters = filterGroups().length > 0;
  const summaryBits = [];
  if (q.from && q.to) summaryBits.push(cityShort(q.from) + ' → ' + cityShort(q.to));
  if (q.city) summaryBits.push(cityShort(q.city));
  if (q.date) summaryBits.push(formatDateHuman(q.date, 'month'));
  if (q.checkin && q.checkout) {
    summaryBits.push(formatDateHuman(q.checkin, 'month') + ' – ' + formatDateHuman(q.checkout, 'month'));
  }

  return (
    <div style={{ paddingBottom: 40 }}>
      <div className="container" style={{ paddingTop: 22 }}>
        <SearchForm service={formService} onServiceChange={setFormService} initial={q} />
      </div>

      <div className="container" style={{ marginTop: 26 }}>
        <div className="section-head" style={{ marginBottom: 16 }}>
          <div>
            <span className="eyebrow">{meta.plural}</span>
            <h2 style={{ fontSize: '1.7rem', marginBottom: 4 }}>
              {filtered.length} {filtered.length === 1 ? 'result' : 'results'}
              {summaryBits.length ? ' · ' + summaryBits.join(' · ') : ''}
            </h2>
            <p className="small muted mb-0">
              Prices shown in {currency} · taxes & fees calculated at checkout
            </p>
          </div>
          <div className="row gap-8">
            {hasFilters ? (
              <button className="btn btn-outline btn-sm show-mobile" onClick={function () { setFiltersOpen(true); }}>
                <FilterIcon size={16} /> Filters
              </button>
            ) : null}
          </div>
        </div>

        <div className={hasFilters ? 'search-layout' : ''}>
          {hasFilters ? (
            <aside className={'filters' + (filtersOpen ? ' open' : '')}>
              <div className="row-between mb-16">
                <h3 style={{ margin: 0, fontSize: '1.15rem' }}>Filters</h3>
                <div className="row gap-8">
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={function () {
                      setFilters({});
                      setMaxPrice(Math.ceil(bounds.max));
                    }}
                  >
                    Reset
                  </button>
                  <button className="icon-btn show-mobile" aria-label="Close filters" onClick={function () { setFiltersOpen(false); }}>
                    <CloseIcon size={16} />
                  </button>
                </div>
              </div>

              <div className="filter-group">
                {bounds.max > bounds.min
                  ? priceRange(bounds.min, bounds.max, maxPrice != null ? maxPrice : bounds.max, setMaxPrice, currency)
                  : null}
              </div>

              {filterGroups().map(function (g) {
                return (
                  <div className="filter-group" key={g.key}>
                    <h4>{g.label}</h4>
                    {g.options.map(function (o) {
                      return (
                        <CheckFilter
                          key={o.id}
                          id={o.id}
                          label={o.label}
                          checked={(filters[g.key] || []).indexOf(o.id) >= 0}
                          onToggle={function (id, checked) {
                            toggleFilter(g.key, id, checked);
                          }}
                        />
                      );
                    })}
                  </div>
                );
              })}

              <button className="btn btn-primary btn-block btn-sm show-mobile mt-16" onClick={function () { setFiltersOpen(false); }}>
                Show {filtered.length} results
              </button>
            </aside>
          ) : null}

          <div>
            <div className="sort-bar">
              <div className="sort-pills">
                {sorts.map(function (s) {
                  return (
                    <button
                      key={s.id}
                      className={'sort-pill' + (sort === s.id ? ' active' : '')}
                      onClick={function () {
                        setSort(s.id);
                      }}
                    >
                      {s.label}
                    </button>
                  );
                })}
              </div>
              <div className="small muted row gap-8">
                <ClockIcon size={15} />
                {service === 'flight' || service === 'bus' || service === 'train'
                  ? 'Updated just now'
                  : 'Free cancellation on most options'}
              </div>
            </div>

            {loading ? (
              <div className="stack-16">
                {[0, 1, 2].map(function (i) {
                  return <div key={i} className="skeleton" style={{ height: 150 }} />;
                })}
              </div>
            ) : filtered.length === 0 ? (
              <div className="empty">
                <div className="service-icon" style={{ background: 'rgba(18,35,60,0.08)', color: 'var(--ink-2)', margin: '0 auto 14px' }}>
                  <IconC size={26} />
                </div>
                <h3>No {meta.plural.toLowerCase()} match your filters</h3>
                <p>
                  {service === 'train' && q.from && q.to
                    ? 'There is no rail service on this route yet. Try a popular corridor below.'
                    : service === 'bus' && q.from && q.to
                    ? 'No coaches on this route right now. Try one of our popular corridors.'
                    : 'Try widening your filters, changing the date, or exploring another city.'}
                </p>
                <div className="row gap-8 wrap" style={{ justifyContent: 'center' }}>
                  {service === 'train' ? (
                    <React.Fragment>
                      <Link className="btn btn-outline btn-sm" to={'/search/train?from=delhi&to=jaipur&date=' + todayISO()}>
                        Delhi → Jaipur
                      </Link>
                      <Link className="btn btn-outline btn-sm" to={'/search/train?from=mumbai&to=goa&date=' + todayISO()}>
                        Mumbai → Goa
                      </Link>
                      <Link className="btn btn-outline btn-sm" to={'/search/train?from=bengaluru&to=chennai&date=' + todayISO()}>
                        Bengaluru → Chennai
                      </Link>
                    </React.Fragment>
                  ) : service === 'bus' ? (
                    <React.Fragment>
                      <Link className="btn btn-outline btn-sm" to={'/search/bus?from=delhi&to=jaipur&date=' + todayISO()}>
                        Delhi → Jaipur
                      </Link>
                      <Link className="btn btn-outline btn-sm" to={'/search/bus?from=mumbai&to=goa&date=' + todayISO()}>
                        Mumbai → Goa
                      </Link>
                      <Link className="btn btn-outline btn-sm" to={'/search/bus?from=jaipur&to=udaipur&date=' + todayISO()}>
                        Jaipur → Udaipur
                      </Link>
                    </React.Fragment>
                  ) : (
                    <React.Fragment>
                      <button
                        className="btn btn-primary btn-sm"
                        onClick={function () {
                          setFilters({});
                          setMaxPrice(Math.ceil(bounds.max || 100));
                        }}
                      >
                        Clear all filters
                      </button>
                      <Link className="btn btn-outline btn-sm" to={'/search/' + service}>
                        New search
                      </Link>
                    </React.Fragment>
                  )}
                </div>
              </div>
            ) : (
              <div className="stack-16">
                {filtered.map(function (item) {
                  return <ResultCard key={item.id} item={item} />;
                })}
              </div>
            )}

            {/* Suggested destinations */}
            {!loading && filtered.length > 0 && service !== 'ride' ? (
              <div className="card card-pad mt-24">
                <h3 style={{ fontSize: '1.15rem' }}>Keep exploring</h3>
                <div className="row gap-8 wrap">
                  {CITIES.slice(0, 10).map(function (c) {
                    return (
                      <Link key={c.id} className="badge badge-outline" to={'/search/' + (service === 'flight' ? 'hotel' : service) + '?city=' + c.id + '&checkin=' + addDays(todayISO(), 14) + '&checkout=' + addDays(todayISO(), 17) + '&guests=2&rooms=1'}>
                        {c.name}
                      </Link>
                    );
                  })}
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}

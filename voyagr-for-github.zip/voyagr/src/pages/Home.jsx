/* ------------------------------------------------------------------
   Home page: hero + universal search, destinations, deals, how-it-works.
------------------------------------------------------------------- */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import SearchForm from '../components/SearchForm';
import { useApp } from '../store/store';
import { formatMoney, todayISO, addDays } from '../lib/format';
import { CITIES } from '../data/cities';
import {
  SERVICE_ICONS,
  SERVICE_META,
  ArrowIcon,
  CheckIcon,
  ShieldIcon,
  StarIcon,
  TicketIcon,
  ClockIcon,
  GlobeIcon,
} from '../components/Icons';

const DESTINATIONS = [
  { id: 'goa', img: '/img/hero.jpg', hue: 'rgba(232,97,60,0.18)' },
  { id: 'dubai', img: '/img/road.jpg', hue: 'rgba(245,166,35,0.18)' },
  { id: 'bali', img: '/img/experience.jpg', hue: 'rgba(15,138,106,0.18)' },
  { id: 'paris', img: '/img/cafe.jpg', hue: 'rgba(194,24,91,0.16)' },
  { id: 'jaipur', img: '/img/hotel.jpg', hue: 'rgba(232,97,60,0.16)' },
  { id: 'tokyo', img: '/img/train.jpg', hue: 'rgba(47,111,237,0.16)' },
];

const DEALS = [
  {
    tag: 'Flights',
    title: 'Delhi → Goa from $62',
    text: 'Sunset beaches, one hour away. Extra savings with code FLY5.',
    img: '/img/flight.jpg',
    service: 'flight',
    from: 'delhi',
    to: 'goa',
  },
  {
    tag: 'Stays',
    title: 'Up to 15% off beach resorts',
    text: 'Palm Bay Goa, Seminyak Surf House and 200+ seaside stays.',
    img: '/img/hotel.jpg',
    service: 'hotel',
    city: 'goa',
  },
  {
    tag: 'Experiences',
    title: 'Desert safari + Bedouin dinner',
    text: 'Dune bashing, falconry and a lantern-lit feast in Dubai.',
    img: '/img/experience.jpg',
    service: 'experience',
    city: 'dubai',
  },
];

export default function Home() {
  const [service, setService] = useState('hotel');
  const { currency } = useApp();
  const navigate = useNavigate();

  return (
    <div>
      {/* ---------------------------- hero ---------------------------- */}
      <section className="hero">
        <div className="hero-bg" style={{ backgroundImage: 'url(/img/hero.jpg)' }} />
        <div className="container hero-inner">
          <p className="eyebrow" style={{ color: 'var(--amber)' }}>All-in-one travel app</p>
          <h1>
            Every journey,
            <br />
            <em>one app.</em>
          </h1>
          <p className="hero-sub">
            Hotels, flights, trains, buses, café tables, car rentals, rides and experiences —
            searched, booked and managed together in Voyagr.
          </p>
          <div className="hero-chips">
            <span className="hero-chip">
              <CheckIcon size={15} /> No hidden fees
            </span>
            <span className="hero-chip">
              <ShieldIcon size={15} /> Secure test payments
            </span>
            <span className="hero-chip">
              <TicketIcon size={15} /> Instant e-tickets
            </span>
            <span className="hero-chip">
              <GlobeIcon size={15} /> 25 cities · 5 currencies
            </span>
          </div>

          <SearchForm service={service} onServiceChange={setService} />
        </div>
      </section>

      {/* -------------------------- trust strip -------------------------- */}
      <div className="container">
        <div className="trust-strip">
          <div className="trust-item">
            <div className="num">2.4M+</div>
            <div className="lbl">travellers booking with Voyagr</div>
          </div>
          <div className="trust-item">
            <div className="num">8</div>
            <div className="lbl">services in one checkout</div>
          </div>
          <div className="trust-item">
            <div className="num">4.8★</div>
            <div className="lbl">average app-store rating</div>
          </div>
          <div className="trust-item">
            <div className="num">24×7</div>
            <div className="lbl">human support, always on</div>
          </div>
        </div>
      </div>

      {/* ------------------------ destinations ------------------------ */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">Popular right now</span>
              <h2>Places everyone’s booking</h2>
              <p>Hand-picked destinations with great stays, food and things to do.</p>
            </div>
            <Link to="/search/hotel" className="btn btn-outline">
              Browse all stays <ArrowIcon size={18} />
            </Link>
          </div>

          <div className="grid grid-3">
            {DESTINATIONS.map(function (d) {
              const city = CITIES.filter(function (c) {
                return c.id === d.id;
              })[0];
              return (
                <Link
                  key={d.id}
                  to={
                    '/search/hotel?city=' +
                    d.id +
                    '&checkin=' +
                    addDays(todayISO(), 14) +
                    '&checkout=' +
                    addDays(todayISO(), 17) +
                    '&guests=2&rooms=1'
                  }
                  className="city-card"
                >
                  <div className="art" style={{ backgroundImage: 'url(' + d.img + ')' }} />
                  <div className="body">
                    <h3>{city.name}</h3>
                    <p>{city.tagline}</p>
                    <div className="price-from">
                      Stays from {formatMoney(d.id === 'male' ? 420 : d.id === 'tokyo' ? 148 : 68, currency)} · flights from{' '}
                      {formatMoney(d.id === 'paris' || d.id === 'tokyo' ? 320 : 74, currency)}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* -------------------------- services -------------------------- */}
      <section className="section-tight">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">One app for everything</span>
              <h2>Book the whole trip in one place</h2>
            </div>
          </div>
          <div className="grid grid-4">
            {Object.keys(SERVICE_META).map(function (key) {
              const meta = SERVICE_META[key];
              const IconC = SERVICE_ICONS[key];
              return (
                <Link key={key} to={'/search/' + key} className="service-tile">
                  <div className="service-icon" style={{ background: meta.color }}>
                    <IconC size={26} />
                  </div>
                  <div>
                    <h3 style={{ marginBottom: 4 }}>{meta.plural}</h3>
                    <p className="muted small mb-0">
                      {key === 'hotel' && 'Boutique stays to beach resorts'}
                      {key === 'flight' && 'Domestic & long-haul fares'}
                      {key === 'train' && 'Scenic rail across the map'}
                      {key === 'bus' && 'Intercity coaches & sleepers'}
                      {key === 'cafe' && 'Reserve tables & pre-order'}
                      {key === 'car' && 'Self-drive, unlimited km'}
                      {key === 'ride' && 'Bikes, autos, cabs & vans'}
                      {key === 'experience' && 'Tours, tastings & adventures'}
                    </p>
                  </div>
                  <span className="row gap-8 small bold text-coral">
                    Explore <ArrowIcon size={15} />
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* --------------------------- deals --------------------------- */}
      <section className="section" id="deals">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">Limited-time deals</span>
              <h2>Save more, travel further</h2>
              <p>Use these promo codes at checkout — every one of them works in this demo.</p>
            </div>
          </div>
          <div className="grid grid-3">
            {DEALS.map(function (deal) {
              const to =
                '/search/' +
                deal.service +
                '?' +
                (deal.service === 'flight'
                  ? 'from=' + deal.from + '&to=' + deal.to + '&date=' + addDays(todayISO(), 10) + '&cabin=economy&pax=1'
                  : deal.service === 'hotel'
                  ? 'city=' + deal.city + '&checkin=' + addDays(todayISO(), 10) + '&checkout=' + addDays(todayISO(), 13) + '&guests=2&rooms=1'
                  : 'city=' + deal.city + '&date=' + addDays(todayISO(), 10) + '&guests=2');
              return (
                <Link key={deal.title} to={to} className="card deal-card card-hover">
                  <div className="deal-art" style={{ backgroundImage: 'url(' + deal.img + ')' }}>
                    <span className="badge badge-coral">{deal.tag}</span>
                  </div>
                  <div className="card-pad">
                    <h3>{deal.title}</h3>
                    <p className="muted">{deal.text}</p>
                    <span className="row gap-8 small bold text-coral">
                      Book this deal <ArrowIcon size={15} />
                    </span>
                  </div>
                </Link>
              );
            })}
          </div>

          <div className="card card-pad mt-24 row-between">
            <div className="row gap-16">
              <div className="service-icon" style={{ background: 'var(--amber)', color: '#4a2c05' }}>
                <TicketIcon size={24} />
              </div>
              <div>
                <h3 style={{ marginBottom: 2 }}>Promo codes that actually work here</h3>
                <p className="muted mb-0">
                  <strong>VOYAGR10</strong> · 10% off &nbsp;·&nbsp; <strong>FLY5</strong> · 5% off flights &nbsp;·&nbsp;{' '}
                  <strong>STAY15</strong> · 15% off stays &nbsp;·&nbsp; <strong>RIDE2</strong> · $2.50 off rides
                </p>
              </div>
            </div>
            <button
              className="btn btn-dark"
              onClick={function () {
                navigate('/search/flight');
              }}
            >
              Try a booking
            </button>
          </div>
        </div>
      </section>

      {/* ------------------------ how it works ------------------------ */}
      <section className="section section-dark">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">How it works</span>
              <h2>Three steps to your next trip</h2>
            </div>
          </div>
          <div className="steps">
            <div className="step-card">
              <div className="step-num">1</div>
              <h3>Search everything at once</h3>
              <p style={{ color: 'rgba(242,237,228,0.75)' }}>
                Pick a service, set your dates and let Voyagr scan flights, stays, rails, rides and
                more across the globe.
              </p>
            </div>
            <div className="step-card">
              <div className="step-num">2</div>
              <h3>Book with transparent pricing</h3>
              <p style={{ color: 'rgba(242,237,228,0.75)' }}>
                What you see is what you pay — taxes, fees and promo codes shown before you confirm.
                Test payments, zero risk.
              </p>
            </div>
            <div className="step-card">
              <div className="step-num">3</div>
              <h3>Manage it all in My Trips</h3>
              <p style={{ color: 'rgba(242,237,228,0.75)' }}>
                E-tickets, itineraries, cancellations and rebookings — every booking lives in one
                tidy dashboard.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* --------------------------- why --------------------------- */}
      <section className="section">
        <div className="container">
          <div className="section-head">
            <div>
              <span className="eyebrow">Why Voyagr</span>
              <h2>Built like a super-app, feels like a holiday</h2>
            </div>
          </div>
          <div className="grid grid-4">
            {[
              { icon: ClockIcon, title: 'Book in 90 seconds', text: 'A single checkout for every service — no more juggling six tabs.' },
              { icon: ShieldIcon, title: 'Fair, clear pricing', text: 'Taxes and fees upfront. Free cancellation on most rates.' },
              { icon: TicketIcon, title: 'Instant e-tickets', text: 'Tickets and vouchers in your pocket, even offline once installed.' },
              { icon: StarIcon, title: 'Loved by travellers', text: '2.4M+ trips booked, 4.8★ average rating across app stores.' },
            ].map(function (f) {
              const IconC = f.icon;
              return (
                <div key={f.title} className="card card-pad">
                  <div className="service-icon" style={{ background: 'rgba(232,97,60,0.12)', color: 'var(--coral)', marginBottom: 12 }}>
                    <IconC size={24} />
                  </div>
                  <h3 style={{ fontSize: '1.12rem' }}>{f.title}</h3>
                  <p className="muted mb-0">{f.text}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* ------------------------ app CTA ------------------------ */}
      <section className="section-tight">
        <div className="container">
          <div
            className="card"
            style={{
              background: 'linear-gradient(120deg, var(--navy) 0%, var(--navy-3) 100%)',
              color: '#fff',
              padding: '46px 40px',
              position: 'relative',
              overflow: 'hidden',
            }}
          >
            <div style={{ maxWidth: 560 }}>
              <span className="eyebrow" style={{ color: 'var(--amber)' }}>
                Take it with you
              </span>
              <h2 style={{ color: '#fff' }}>Install Voyagr on your phone</h2>
              <p style={{ color: 'rgba(255,255,255,0.82)', fontSize: '1.05rem' }}>
                Works beautifully in Chrome and Safari — tap “Add to Home Screen” and launch it like
                a native app. Offline-friendly, full-screen, fast.
              </p>
              <div className="row gap-12 wrap">
                <a href="#install-help" className="btn btn-amber">
                  How to install
                </a>
                <Link to="/signup" className="btn btn-light">
                  Create free account
                </Link>
              </div>
            </div>
            <div
              style={{
                position: 'absolute',
                right: -40,
                top: -40,
                width: 320,
                height: 320,
                borderRadius: '50%',
                background: 'radial-gradient(circle, rgba(245,166,35,0.35), transparent 70%)',
              }}
            />
          </div>
        </div>
      </section>
    </div>
  );
}

/* ------------------------------------------------------------------
   My Trips dashboard — upcoming / past / cancelled bookings with
   management actions (view ticket, cancel, rebook).
------------------------------------------------------------------- */

import React, { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../store/store';
import { formatMoney, addDays, todayISO } from '../lib/format';
import { SERVICE_ICONS, SERVICE_META, TicketIcon, CloseIcon, ArrowIcon } from '../components/Icons';

const SERVICE_LABEL = {
  hotel: 'Stay',
  flight: 'Flight',
  train: 'Train',
  bus: 'Bus',
  cafe: 'Café table',
  car: 'Car rental',
  ride: 'Ride',
  experience: 'Experience',
};

export default function Trips() {
  const { myBookings, cancelBooking, currency, toast, user } = useApp();
  const [tab, setTab] = useState('upcoming');
  const [confirmId, setConfirmId] = useState(null);
  const [openId, setOpenId] = useState(null);

  const groups = useMemo(
    function () {
      const upcoming = [];
      const past = [];
      const cancelled = [];
      myBookings.forEach(function (b) {
        if (b.status === 'cancelled') {
          cancelled.push(b);
          return;
        }
        upcoming.push(b);
      });
      return { upcoming: upcoming, past: past, cancelled: cancelled };
    },
    [myBookings]
  );

  const list = groups[tab] || [];

  function rebookLink() {
    return '/search/' + (tab === 'upcoming' ? 'hotel' : 'hotel') + '?checkin=' + addDays(todayISO(), 14) + '&checkout=' + addDays(todayISO(), 17) + '&guests=2&rooms=1&city=goa';
  }

  return (
    <div className="container" style={{ paddingTop: 30, paddingBottom: 60 }}>
      <div className="section-head">
        <div>
          <span className="eyebrow">Your dashboard</span>
          <h2>My Trips</h2>
          <p>
            {user
              ? 'Every booking under ' + user.email + ' lives here.'
              : 'Guest bookings from this browser live here — sign in to sync them to your account.'}
          </p>
        </div>
        <Link className="btn btn-primary" to="/">
          Book something new
        </Link>
      </div>

      <div className="tabs mb-24">
        {[
          { id: 'upcoming', label: 'Upcoming' },
          { id: 'past', label: 'Past' },
          { id: 'cancelled', label: 'Cancelled' },
        ].map(function (t) {
          return (
            <button
              key={t.id}
              className={'tab' + (tab === t.id ? ' active' : '')}
              onClick={function () {
                setTab(t.id);
              }}
            >
              {t.label} ({(groups[t.id] || []).length})
            </button>
          );
        })}
      </div>

      {list.length === 0 ? (
        <div className="empty">
          <div
            className="service-icon"
            style={{ background: 'rgba(18,35,60,0.08)', color: 'var(--ink-2)', margin: '0 auto 14px' }}
          >
            <TicketIcon size={26} />
          </div>
          <h3>{tab === 'upcoming' ? 'No upcoming trips yet' : tab === 'past' ? 'No past trips' : 'Nothing cancelled'}</h3>
          <p>
            {tab === 'upcoming'
              ? 'When you book a stay, flight, ride or experience, it will show up here with its e-ticket.'
              : tab === 'past'
              ? 'Your completed journeys will be archived here.'
              : 'Cancelled bookings are kept here for your records.'}
          </p>
          <Link className="btn btn-primary" to="/">
            Start planning
          </Link>
        </div>
      ) : (
        <div className="stack-16">
          {list.map(function (b) {
            const IconC = SERVICE_ICONS[b.service] || TicketIcon;
            const meta = SERVICE_META[b.service] || { color: '#e8613c' };
            const isOpen = openId === b.id;
            return (
              <div className="card trip-card" key={b.id}>
                <div className="trip-thumb" style={{ backgroundImage: 'url(' + (b.image || '/img/hero.jpg') + ')' }} />
                <div className="trip-main">
                  <div className="row gap-8 wrap">
                    <span className="badge" style={{ background: meta.color, color: '#fff' }}>
                      <IconC size={13} /> {SERVICE_LABEL[b.service]}
                    </span>
                    <span className="badge badge-outline">{b.id}</span>
                    <span className={'badge ' + (b.status === 'cancelled' ? 'badge-danger' : 'badge-success')}>
                      {b.status === 'cancelled' ? 'Cancelled' : 'Confirmed'}
                    </span>
                  </div>
                  <h3 style={{ margin: '8px 0 2px', fontSize: '1.2rem' }}>{b.title}</h3>
                  <div className="small muted">
                    {b.subtitle} · {b.dateLabel}
                  </div>
                  <div className="small bold mt-8">
                    {formatMoney(b.pricing.totalUSD, b.currency || currency)}
                    <span className="muted small">
                      {' '}
                      · {b.quantity} {b.unitLabel}
                      {b.quantity > 1 ? 's' : ''}
                    </span>
                  </div>
                </div>
                <div className="trip-actions">
                  <Link className="btn btn-outline btn-sm" to={'/confirmation/' + b.id}>
                    <TicketIcon size={15} /> Ticket
                  </Link>
                  {b.status !== 'cancelled' ? (
                    <button
                      className="btn btn-danger btn-sm"
                      onClick={function () {
                        setConfirmId(b.id);
                      }}
                    >
                      Cancel
                    </button>
                  ) : null}
                  <Link className="btn btn-ghost btn-sm" to={rebookLink()}>
                    Book again <ArrowIcon size={14} />
                  </Link>
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={function () {
                      setOpenId(isOpen ? null : b.id);
                    }}
                  >
                    {isOpen ? 'Hide details' : 'Details'}
                  </button>
                </div>

                {isOpen ? (
                  <div style={{ flexBasis: '100%' }}>
                    <div className="divider" />
                    {(b.details || []).map(function (d) {
                      return (
                        <div className="kv" key={d.k}>
                          <span className="k">{d.k}</span>
                          <span className="v">{d.v}</span>
                        </div>
                      );
                    })}
                    <div className="kv">
                      <span className="k">Payment</span>
                      <span className="v">
                        {b.payment.method === 'card' ? b.payment.brand + ' ····' + b.payment.last4 : b.payment.brand}
                      </span>
                    </div>
                  </div>
                ) : null}
              </div>
            );
          })}
        </div>
      )}

      {confirmId ? (
        <div
          className="overlay"
          onClick={function () {
            setConfirmId(null);
          }}
        >
          <div
            className="modal"
            onClick={function (e) {
              e.stopPropagation();
            }}
          >
            <div className="modal-head">
              <h3 style={{ margin: 0 }}>Cancel this booking?</h3>
              <button
                className="icon-btn"
                aria-label="Close"
                onClick={function () {
                  setConfirmId(null);
                }}
              >
                <CloseIcon size={16} />
              </button>
            </div>
            <div className="modal-body">
              <p className="muted">
                Free-cancellation eligible bookings are refunded in full to the original payment method
                (instantly in this demo). You can book again anytime.
              </p>
              <div className="row gap-12" style={{ justifyContent: 'flex-end' }}>
                <button
                  className="btn btn-ghost"
                  onClick={function () {
                    setConfirmId(null);
                  }}
                >
                  Keep booking
                </button>
                <button
                  className="btn btn-danger"
                  onClick={function () {
                    cancelBooking(confirmId);
                    setConfirmId(null);
                    toast('Booking cancelled — refund initiated', 'success');
                  }}
                >
                  Cancel booking
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

/* ------------------------------------------------------------------
   Sign in / Sign up pages.
------------------------------------------------------------------- */

import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useApp } from '../store/store';
import { isEmail } from '../lib/format';
import { CheckIcon, ShieldIcon, MailIcon, UserIcon } from '../components/Icons';

function AuthShell(props) {
  return (
    <div className="auth-wrap">
      <div className="auth-art" style={{ backgroundImage: 'url(/img/hero.jpg)' }}>
        <div>
          <h2 style={{ color: '#fff', fontSize: '2.1rem' }}>{props.artTitle}</h2>
          <p style={{ color: 'rgba(255,255,255,0.85)', maxWidth: 420 }}>{props.artText}</p>
          <div className="row gap-12 wrap mt-16">
            <span className="hero-chip">
              <CheckIcon size={14} /> 8 services, 1 account
            </span>
            <span className="hero-chip">
              <ShieldIcon size={14} /> Secure & private
            </span>
          </div>
        </div>
      </div>
      <div className="auth-form">
        <div className="auth-form-inner">{props.children}</div>
      </div>
    </div>
  );
}

export function Login() {
  const { login, toast } = useApp();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});

  async function submit(e) {
    e.preventDefault();
    const errs = {};
    if (!isEmail(email)) errs.email = 'Enter a valid email';
    if (!password) errs.password = 'Password required';
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const res = await login(email, password);
    if (res.ok) {
      toast(res.message, 'success');
      navigate('/trips');
    } else {
      setErrors({ password: res.message });
    }
  }

  return (
    <AuthShell
      artTitle="Welcome back."
      artText="Sign in to see your trips, manage bookings and check out faster with saved travellers."
    >
      <span className="eyebrow">Sign in</span>
      <h1 style={{ fontSize: '2.15rem' }}>Good to see you again</h1>
      <p className="muted">
        New here?{' '}
        <Link to="/signup" className="text-coral bold">
          Create a free account
        </Link>
      </p>

      <form className="stack-16 mt-24" onSubmit={submit}>
        <div className="field">
          <label>Email</label>
          <input
            className={'input' + (errors.email ? ' error' : '')}
            type="email"
            value={email}
            placeholder="demo@voyagr.app"
            onChange={function (e) {
              setEmail(e.target.value);
            }}
          />
          {errors.email ? <span className="field-error">{errors.email}</span> : null}
        </div>
        <div className="field">
          <label>Password</label>
          <input
            className={'input' + (errors.password ? ' error' : '')}
            type="password"
            value={password}
            placeholder="voyagr123"
            onChange={function (e) {
              setPassword(e.target.value);
            }}
          />
          {errors.password ? <span className="field-error">{errors.password}</span> : null}
        </div>
        <button className="btn btn-primary btn-block btn-lg" type="submit">
          Sign in
        </button>
      </form>

      <div className="card card-pad mt-24" style={{ background: 'var(--cream)', boxShadow: 'none' }}>
        <div className="row gap-12">
          <UserIcon size={20} style={{ color: 'var(--coral)' }} />
          <div className="small">
            <strong>Demo account:</strong> demo@voyagr.app · voyagr123
            <button
              className="btn btn-ghost btn-sm"
              style={{ marginLeft: 8 }}
              onClick={function () {
                setEmail('demo@voyagr.app');
                setPassword('voyagr123');
              }}
            >
              Fill for me
            </button>
          </div>
        </div>
      </div>
    </AuthShell>
  );
}

export function Signup() {
  const { signup, toast } = useApp();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});

  async function submit(e) {
    e.preventDefault();
    const errs = {};
    if (!name.trim()) errs.name = 'Tell us your name';
    if (!isEmail(email)) errs.email = 'Enter a valid email';
    if (password.length < 6) errs.password = 'At least 6 characters';
    setErrors(errs);
    if (Object.keys(errs).length) return;

    const res = await signup(name, email, password, phone);
    if (res.ok) {
      toast(res.message, 'success');
      navigate('/trips');
    } else {
      setErrors({ email: res.message });
    }
  }

  return (
    <AuthShell
      artTitle="One account. Every journey."
      artText="Save travellers, sync trips across devices and unlock member-only fares and café perks."
    >
      <span className="eyebrow">Create account</span>
      <h1 style={{ fontSize: '2.15rem' }}>Join Voyagr free</h1>
      <p className="muted">
        Already a member?{' '}
        <Link to="/login" className="text-coral bold">
          Sign in
        </Link>
      </p>

      <form className="stack-16 mt-24" onSubmit={submit}>
        <div className="field">
          <label>Full name</label>
          <input
            className={'input' + (errors.name ? ' error' : '')}
            value={name}
            placeholder="Aarav Sharma"
            onChange={function (e) {
              setName(e.target.value);
            }}
          />
          {errors.name ? <span className="field-error">{errors.name}</span> : null}
        </div>
        <div className="field">
          <label>Email</label>
          <input
            className={'input' + (errors.email ? ' error' : '')}
            type="email"
            value={email}
            placeholder="you@email.com"
            onChange={function (e) {
              setEmail(e.target.value);
            }}
          />
          {errors.email ? <span className="field-error">{errors.email}</span> : null}
        </div>
        <div className="field">
          <label>Phone (optional)</label>
          <input
            className="input"
            value={phone}
            placeholder="+91 98765 43210"
            onChange={function (e) {
              setPhone(e.target.value);
            }}
          />
        </div>
        <div className="field">
          <label>Password</label>
          <input
            className={'input' + (errors.password ? ' error' : '')}
            type="password"
            value={password}
            placeholder="At least 6 characters"
            onChange={function (e) {
              setPassword(e.target.value);
            }}
          />
          {errors.password ? <span className="field-error">{errors.password}</span> : null}
        </div>
        <button className="btn btn-primary btn-block btn-lg" type="submit">
          Create account
        </button>
        <p className="tiny muted center">
          By joining you agree to the Voyagr demo terms — no real data leaves your browser.
        </p>
      </form>
    </AuthShell>
  );
}

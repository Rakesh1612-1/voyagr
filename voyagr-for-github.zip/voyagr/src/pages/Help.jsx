/* ------------------------------------------------------------------
   Help centre — FAQ accordion + contact + install instructions.
------------------------------------------------------------------- */

import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ChevronIcon, ShieldIcon, PhoneIcon, MailIcon, GlobeIcon, CheckIcon, InfoIcon } from '../components/Icons';

const FAQS = [
  {
    q: 'Is this a real travel agency? Can I actually fly?',
    a: 'Voyagr is a fully functional demo super-app: every search, booking, payment and ticket flow works end-to-end, but inventory and payments are simulated so you can test freely. Real airline/hotel APIs can be plugged into the same interfaces later.',
  },
  {
    q: 'How do promo codes work?',
    a: 'Enter a code at checkout (VOYAGR10, FLY5, STAY15, RIDE2, RAIL10, FEAST20, ROADTRIP, WANDER25). Each has its own rules — minimum spend, service restrictions and caps — which are enforced exactly like production.',
  },
  {
    q: 'Which payment methods are supported?',
    a: 'Credit/debit cards (with Luhn validation), UPI IDs and the Voyagr Wallet. The test gateway accepts any Luhn-valid card such as 4242 4242 4242 4242 — no real money moves.',
  },
  {
    q: 'Can I cancel a booking?',
    a: 'Yes — open My Trips, pick the booking and hit Cancel. Refundable rates are refunded instantly in the demo, and the booking moves to your Cancelled tab.',
  },
  {
    q: 'Does it work on iPhone Safari and Android Chrome?',
    a: 'Absolutely. Voyagr is a progressive web app (PWA): it runs in every modern browser and installs to your home screen with a full-screen, app-like experience. See the install steps below.',
  },
  {
    q: 'How do I install the app?',
    a: 'On iPhone/iPad: open the site in Safari → Share → Add to Home Screen. On Android: open in Chrome → menu → Install app. On desktop Chrome: click the install icon in the address bar. Your trips and settings stay in sync locally.',
  },
  {
    q: 'Where are my bookings stored?',
    a: 'In your browser’s local storage — nothing is sent to a server. That also means bookings persist across reloads and work offline once the app is installed.',
  },
];

export default function Help() {
  const [open, setOpen] = useState(0);

  return (
    <div style={{ paddingBottom: 60 }}>
      <section className="hero" style={{ padding: '56px 0 64px' }}>
        <div className="hero-bg" style={{ backgroundImage: 'url(/img/experience.jpg)', opacity: 0.5 }} />
        <div className="container hero-inner">
          <span className="eyebrow" style={{ color: 'var(--amber)' }}>
            Help centre
          </span>
          <h1 style={{ fontSize: 'clamp(2rem, 5vw, 3rem)' }}>How can we help?</h1>
          <p className="hero-sub mb-0">
            Answers about bookings, payments, cancellations and installing the app — plus a human on
            the other end if you need one.
          </p>
        </div>
      </section>

      <div className="container" style={{ marginTop: 40 }}>
        <div className="grid grid-3 mb-24">
          <a className="card card-pad card-hover" href="mailto:hello@voyagr.app">
            <MailIcon size={24} style={{ color: 'var(--coral)' }} />
            <h3 style={{ margin: '12px 0 4px', fontSize: '1.15rem' }}>Email us</h3>
            <p className="muted mb-0 small">hello@voyagr.app · replies within 2 hours</p>
          </a>
          <a className="card card-pad card-hover" href="tel:+18005550199">
            <PhoneIcon size={24} style={{ color: 'var(--coral)' }} />
            <h3 style={{ margin: '12px 0 4px', fontSize: '1.15rem' }}>Call support</h3>
            <p className="muted mb-0 small">+1 800 555 0199 · 24×7 for travellers</p>
          </a>
          <div className="card card-pad card-hover">
            <GlobeIcon size={24} style={{ color: 'var(--coral)' }} />
            <h3 style={{ margin: '12px 0 4px', fontSize: '1.15rem' }}>Global coverage</h3>
            <p className="muted mb-0 small">25 cities · 5 currencies · 8 services</p>
          </div>
        </div>

        <div className="search-layout" style={{ gridTemplateColumns: '1fr 380px' }}>
          <div>
            <h2 style={{ fontSize: '1.7rem' }}>Frequently asked questions</h2>
            <div className="stack-12 mt-16">
              {FAQS.map(function (f, i) {
                const isOpen = open === i;
                return (
                  <div className="card" key={f.q}>
                    <button
                      className="row-between full"
                      style={{
                        background: 'none',
                        border: 'none',
                        padding: '18px 22px',
                        textAlign: 'left',
                        cursor: 'pointer',
                        borderRadius: 'var(--radius-l)',
                      }}
                      onClick={function () {
                        setOpen(isOpen ? -1 : i);
                      }}
                    >
                      <strong style={{ fontSize: '1.02rem' }}>{f.q}</strong>
                      <ChevronIcon
                        size={18}
                        style={{ transform: isOpen ? 'rotate(180deg)' : 'none', transition: 'transform 0.2s' }}
                      />
                    </button>
                    {isOpen ? (
                      <p className="muted" style={{ padding: '0 22px 18px', margin: 0 }}>
                        {f.a}
                      </p>
                    ) : null}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="summary-card" id="install-help">
            <div className="summary-art" style={{ backgroundImage: 'url(/img/hero.jpg)' }} />
            <div className="summary-body">
              <h3 style={{ fontSize: '1.2rem' }}>Install Voyagr as an app</h3>
              <div className="stack-12 mt-16 small">
                <div className="row gap-8">
                  <span className="badge badge-coral">iOS</span>
                  <span>Safari → Share → Add to Home Screen</span>
                </div>
                <div className="row gap-8">
                  <span className="badge badge-teal">Android</span>
                  <span>Chrome → ⋮ menu → Install app</span>
                </div>
                <div className="row gap-8">
                  <span className="badge badge-amber">Desktop</span>
                  <span>Chrome address bar → Install icon</span>
                </div>
              </div>
              <div className="divider" />
              <ul className="stack-8 small">
                <li className="row gap-8">
                  <CheckIcon size={15} style={{ color: 'var(--success)' }} /> Full-screen, app-like UI
                </li>
                <li className="row gap-8">
                  <CheckIcon size={15} style={{ color: 'var(--success)' }} /> Works offline after install
                </li>
                <li className="row gap-8">
                  <CheckIcon size={15} style={{ color: 'var(--success)' }} /> No app-store account needed
                </li>
              </ul>
              <Link className="btn btn-primary btn-block mt-16" to="/">
                Start booking
              </Link>
            </div>
          </div>
        </div>

        <div className="card card-pad mt-24 row gap-16 wrap">
          <InfoIcon size={22} style={{ color: 'var(--sky)' }} />
          <div style={{ flex: 1, minWidth: 220 }}>
            <strong>Demo environment</strong>
            <p className="muted small mb-0">
              All bookings, payments and emails in Voyagr are simulated locally in your browser.
              Test everything — you can’t break anything real.
            </p>
          </div>
          <Link className="btn btn-dark" to="/signup">
            Create account
          </Link>
        </div>
      </div>
    </div>
  );
}

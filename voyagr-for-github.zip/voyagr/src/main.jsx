import React from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App';
import { AppProvider } from './store/store';
import './styles/base.css';
import './styles/ui.css';

const container = document.getElementById('root');
createRoot(container).render(
  <BrowserRouter>
    <AppProvider>
      <App />
    </AppProvider>
  </BrowserRouter>
);

// Register the service worker for the installable, offline-capable PWA.
// Production only — dev server stays uncached for a fast feedback loop.
if (import.meta.env.PROD && 'serviceWorker' in navigator) {
  window.addEventListener('load', function () {
    navigator.serviceWorker.register('/sw.js').catch(function () {
      /* offline support unavailable — app still works online */
    });
  });
}

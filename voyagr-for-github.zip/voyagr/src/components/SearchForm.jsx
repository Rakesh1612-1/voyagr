/* ------------------------------------------------------------------
   Unified search form: one component powers every service tab.
------------------------------------------------------------------- */

import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CITIES, searchCities, CITY_BY_ID } from '../data/cities';
import { cityAreas } from '../data/rides';
import { todayISO, addDays } from '../lib/format';
import {
  SERVICE_ICONS,
  FlightIcon,
  HotelIcon,
  TrainIcon,
  BusIcon,
  CafeIcon,
  CarIcon,
  RideIcon,
  ExpIcon,
  SearchIcon,
} from './Icons';

export const SERVICES = [
  { id: 'hotel', label: 'Hotels', icon: HotelIcon },
  { id: 'flight', label: 'Flights', icon: FlightIcon },
  { id: 'train', label: 'Trains', icon: TrainIcon },
  { id: 'bus', label: 'Buses', icon: BusIcon },
  { id: 'cafe', label: 'Cafés', icon: CafeIcon },
  { id: 'car', label: 'Car rentals', icon: CarIcon },
  { id: 'ride', label: 'Rides', icon: RideIcon },
  { id: 'experience', label: 'Experiences', icon: ExpIcon },
];

function CityPicker(props) {
  const [query, setQuery] = useState(props.value ? (CITY_BY_ID[props.value] || {}).name || '' : '');
  const [open, setOpen] = useState(false);
  const wrapRef = useRef(null);

  useEffect(function () {
    function onDoc(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('click', onDoc);
    return function () {
      document.removeEventListener('click', onDoc);
    };
  }, []);

  useEffect(function () {
    if (props.value && CITY_BY_ID[props.value]) setQuery(CITY_BY_ID[props.value].name);
  }, [props.value]);

  const results = searchCities(query).slice(0, 7);

  return (
    <div className="rel" ref={wrapRef}>
      <input
        className="input"
        value={query}
        placeholder={props.placeholder || 'Where to?'}
        aria-label={props.label || 'City'}
        onChange={function (e) {
          setQuery(e.target.value);
          setOpen(true);
          if (props.onChange) props.onChange('');
        }}
        onFocus={function () {
          setOpen(true);
        }}
      />
      {open && results.length > 0 ? (
        <div className="city-suggest">
          {results.map(function (c) {
            return (
              <button
                key={c.id}
                type="button"
                onClick={function () {
                  setQuery(c.name);
                  setOpen(false);
                  if (props.onChange) props.onChange(c.id);
                }}
              >
                <span className="badge badge-outline">{c.code}</span>
                <span>
                  <strong>{c.name}</strong>
                  <span className="muted small"> · {c.country}</span>
                </span>
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
}

export default function SearchForm(props) {
  const navigate = useNavigate();
  const service = props.service;
  const setService = props.onServiceChange;
  const [form, setForm] = useState(function () {
    const init = props.initial || {};
    return Object.assign(
      {
        city: 'goa',
        from: 'delhi',
        to: 'goa',
        date: addDays(todayISO(), 7),
        checkin: addDays(todayISO(), 7),
        checkout: addDays(todayISO(), 10),
        guests: 2,
        rooms: 1,
        pax: 1,
        cabin: 'economy',
        party: 2,
        pickup: 0,
        dropoff: 2,
        when: 'now',
      },
      init
    );
  });

  function set(key, value) {
    setForm(function (f) {
      const next = Object.assign({}, f);
      next[key] = value;
      return next;
    });
  }

  function submit(e) {
    if (e) e.preventDefault();
    const q = new URLSearchParams();
    if (service === 'hotel') {
      q.set('city', form.city);
      q.set('checkin', form.checkin);
      q.set('checkout', form.checkout);
      q.set('guests', String(form.guests));
      q.set('rooms', String(form.rooms));
    } else if (service === 'flight') {
      q.set('from', form.from);
      q.set('to', form.to);
      q.set('date', form.date);
      q.set('cabin', form.cabin);
      q.set('pax', String(form.pax));
    } else if (service === 'train' || service === 'bus') {
      q.set('from', form.from);
      q.set('to', form.to);
      q.set('date', form.date);
      q.set('pax', String(form.pax));
    } else if (service === 'cafe') {
      q.set('city', form.city);
      q.set('date', form.date);
      q.set('party', String(form.party));
    } else if (service === 'car') {
      q.set('city', form.city);
      q.set('pickup', form.checkin);
      q.set('dropoff', form.checkout);
    } else if (service === 'ride') {
      q.set('city', form.city);
      q.set('pickup', String(form.pickup));
      q.set('dropoff', String(form.dropoff));
      q.set('when', form.when);
    } else if (service === 'experience') {
      q.set('city', form.city);
      q.set('date', form.date);
      q.set('guests', String(form.guests));
    }
    if (props.onSearch) props.onSearch(q);
    navigate('/search/' + service + '?' + q.toString());
  }

  const areas = cityAreas(form.city);

  let fields = null;
  if (service === 'hotel') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>Destination</label>
          <CityPicker value={form.city} onChange={function (v) { if (v) set('city', v); }} />
        </div>
        <div className="search-field">
          <label>Check-in</label>
          <input type="date" value={form.checkin} min={todayISO()} onChange={function (e) { set('checkin', e.target.value); }} />
        </div>
        <div className="search-field">
          <label>Check-out</label>
          <input type="date" value={form.checkout} min={form.checkin} onChange={function (e) { set('checkout', e.target.value); }} />
        </div>
        <div className="search-field">
          <label>Guests & rooms</label>
          <select value={form.guests} onChange={function (e) { set('guests', e.target.value); }}>
            {[1, 2, 3, 4, 5, 6].map(function (n) {
              return <option key={n} value={n}>{n} guest{n > 1 ? 's' : ''} · {form.rooms} room{form.rooms > 1 ? 's' : ''}</option>;
            })}
          </select>
        </div>
      </React.Fragment>
    );
  } else if (service === 'flight') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>From</label>
          <CityPicker value={form.from} placeholder="Departure city" onChange={function (v) { if (v) set('from', v); }} />
        </div>
        <div className="search-field">
          <label>To</label>
          <CityPicker value={form.to} placeholder="Arrival city" onChange={function (v) { if (v) set('to', v); }} />
        </div>
        <div className="search-field">
          <label>Departure</label>
          <input type="date" value={form.date} min={todayISO()} onChange={function (e) { set('date', e.target.value); }} />
        </div>
        <div className="search-field">
          <label>Cabin & travellers</label>
          <select value={form.cabin} onChange={function (e) { set('cabin', e.target.value); }}>
            <option value="economy">Economy · {form.pax} pax</option>
            <option value="premium">Premium · {form.pax} pax</option>
            <option value="business">Business · {form.pax} pax</option>
          </select>
        </div>
      </React.Fragment>
    );
  } else if (service === 'train' || service === 'bus') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>From</label>
          <CityPicker value={form.from} placeholder="Departure city" onChange={function (v) { if (v) set('from', v); }} />
        </div>
        <div className="search-field">
          <label>To</label>
          <CityPicker value={form.to} placeholder="Arrival city" onChange={function (v) { if (v) set('to', v); }} />
        </div>
        <div className="search-field">
          <label>Journey date</label>
          <input type="date" value={form.date} min={todayISO()} onChange={function (e) { set('date', e.target.value); }} />
        </div>
      </React.Fragment>
    );
  } else if (service === 'cafe') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>City</label>
          <CityPicker value={form.city} onChange={function (v) { if (v) set('city', v); }} />
        </div>
        <div className="search-field">
          <label>Date</label>
          <input type="date" value={form.date} min={todayISO()} onChange={function (e) { set('date', e.target.value); }} />
        </div>
        <div className="search-field">
          <label>Party size</label>
          <select value={form.party} onChange={function (e) { set('party', e.target.value); }}>
            {[1, 2, 3, 4, 5, 6, 8, 10, 12].map(function (n) {
              return <option key={n} value={n}>{n} {n > 1 ? 'guests' : 'guest'}</option>;
            })}
          </select>
        </div>
      </React.Fragment>
    );
  } else if (service === 'car') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>Pick-up city</label>
          <CityPicker value={form.city} onChange={function (v) { if (v) set('city', v); }} />
        </div>
        <div className="search-field">
          <label>Pick-up date</label>
          <input type="date" value={form.checkin} min={todayISO()} onChange={function (e) { set('checkin', e.target.value); }} />
        </div>
        <div className="search-field">
          <label>Drop-off date</label>
          <input type="date" value={form.checkout} min={form.checkin} onChange={function (e) { set('checkout', e.target.value); }} />
        </div>
      </React.Fragment>
    );
  } else if (service === 'ride') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>City</label>
          <CityPicker value={form.city} onChange={function (v) { if (v) set('city', v); }} />
        </div>
        <div className="search-field">
          <label>Pick-up</label>
          <select value={form.pickup} onChange={function (e) { set('pickup', e.target.value); }}>
            {areas.map(function (a, i) {
              return <option key={a.id} value={i}>{a.name}</option>;
            })}
          </select>
        </div>
        <div className="search-field">
          <label>Drop-off</label>
          <select value={form.dropoff} onChange={function (e) { set('dropoff', e.target.value); }}>
            {areas.map(function (a, i) {
              return <option key={a.id} value={i}>{a.name}</option>;
            })}
          </select>
        </div>
        <div className="search-field">
          <label>When</label>
          <select value={form.when} onChange={function (e) { set('when', e.target.value); }}>
            <option value="now">Ride now</option>
            <option value="later">Schedule for later</option>
          </select>
        </div>
      </React.Fragment>
    );
  } else if (service === 'experience') {
    fields = (
      <React.Fragment>
        <div className="search-field">
          <label>City</label>
          <CityPicker value={form.city} onChange={function (v) { if (v) set('city', v); }} />
        </div>
        <div className="search-field">
          <label>Date</label>
          <input type="date" value={form.date} min={todayISO()} onChange={function (e) { set('date', e.target.value); }} />
        </div>
        <div className="search-field">
          <label>Guests</label>
          <select value={form.guests} onChange={function (e) { set('guests', e.target.value); }}>
            {[1, 2, 3, 4, 5, 6, 8, 10].map(function (n) {
              return <option key={n} value={n}>{n} {n > 1 ? 'guests' : 'guest'}</option>;
            })}
          </select>
        </div>
      </React.Fragment>
    );
  }

  const colClass =
    service === 'ride' || service === 'flight' || service === 'hotel'
      ? 'search-fields'
      : service === 'train' || service === 'bus' || service === 'car'
      ? 'search-fields compact-3'
      : 'search-fields compact-3';

  return (
    <div className="search-card">
      <div className="service-tabs" role="tablist" aria-label="Choose a service">
        {SERVICES.map(function (s) {
          const IconC = s.icon;
          return (
            <button
              key={s.id}
              type="button"
              role="tab"
              aria-selected={service === s.id}
              className={'service-tab' + (service === s.id ? ' active' : '')}
              onClick={function () {
                if (setService) setService(s.id);
              }}
            >
              <IconC size={19} />
              {s.label}
            </button>
          );
        })}
      </div>
      <form className={colClass} onSubmit={submit}>
        {fields}
        <div className="search-btn-wrap">
          <button className="btn btn-primary" type="submit">
            <SearchIcon size={19} />
            Search
          </button>
        </div>
      </form>
    </div>
  );
}

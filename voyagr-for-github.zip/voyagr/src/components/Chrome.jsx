/* ------------------------------------------------------------------
   App chrome: header, mobile nav, footer, toasts, install prompt.
------------------------------------------------------------------- */

import React, { useEffect, useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useApp } from '../store/store';
import { CURRENCY_LIST, formatMoney } from '../lib/format';
import {
  Logo,
  HomeIcon,
  SearchIcon,
  TripsIcon,
  UserIcon,
  GlobeIcon,
  CheckIcon,
  CloseIcon,
  InfoIcon,
  ShieldIcon,
  PhoneIcon,
  MailIcon,
} from './Icons';

export function Header() {
  const { currency, setCurrency, user, logout, toast } = useApp();
  const navigate = useNavigate();

  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link to="/" className="logo" aria-label="Voyagr home">
          <Logo />
          <span>
            Voy<em>agr</em>
          </span>
        </Link>

        <nav className="main-nav" aria-label="Primary">
          <NavLink to="/search/hotel">Stays</NavLink>
          <NavLink to="/search/flight">Flights</NavLink>
          <NavLink to="/search/train">Trains</NavLink>
          <NavLink to="/search/ride">Rides</NavLink>
          <NavLink to="/search/experience">Experiences</NavLink>
          <NavLink to="/trips">My Trips</NavLink>
          <NavLink to="/help">Help</NavLink>
        </nav>

        <div className="header-actions">
          <div className="row gap-8">
            <GlobeIcon size={18} style={{ color: 'var(--ink-3)' }} />
            <select
              className="currency-select"
              value={currency}
              aria-label="Currency"
              onChange={function (e) {
                setCurrency(e.target.value);
                toast('Prices now shown in ' + e.target.value);
              }}
            >
              {CURRENCY_LIST.map(function (c) {
                return (
                  <option key={c.code} value={c.code}>
                    {c.code}
                  </option>
                );
              })}
            </select>
          </div>

          {user ? (
            <div className="user-chip">
              <span className="avatar">{(user.name || 'U').charAt(0).toUpperCase()}</span>
              <span>{user.name.split(' ')[0]}</span>
              <button
                className="btn btn-ghost btn-sm"
                onClick={function () {
                  logout();
                  toast('Signed out');
                  navigate('/');
                }}
              >
                Sign out
              </button>
            </div>
          ) : (
            <div className="row gap-8">
              <Link to="/login" className="btn btn-ghost btn-sm">
                Sign in
              </Link>
              <Link to="/signup" className="btn btn-primary btn-sm">
                Join free
              </Link>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}

export function MobileNav() {
  return (
    <nav className="mobile-nav" aria-label="Mobile">
      <div className="mobile-nav-inner">
        <NavLink to="/" end>
          <span className="mnav-icon">
            <HomeIcon size={21} />
          </span>
          Home
        </NavLink>
        <NavLink to="/search/hotel">
          <span className="mnav-icon">
            <SearchIcon size={21} />
          </span>
          Explore
        </NavLink>
        <NavLink to="/trips">
          <span className="mnav-icon">
            <TripsIcon size={21} />
          </span>
          Trips
        </NavLink>
        <NavLink to="/help">
          <span className="mnav-icon">
            <InfoIcon size={21} />
          </span>
          Help
        </NavLink>
        <NavLink to="/login">
          <span className="mnav-icon">
            <UserIcon size={21} />
          </span>
          Account
        </NavLink>
      </div>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          <div>
            <div className="logo" style={{ color: '#fdf7ee', marginBottom: 14 }}>
              <Logo />
              <span>
                Voy<em>agr</em>
              </span>
            </div>
            <p style={{ maxWidth: 320, fontSize: '0.95rem', lineHeight: 1.7 }}>
              Every journey, one app. Hotels, flights, trains, buses, café tables, car rentals, rides
              and experiences — searched, booked and managed in one place.
            </p>
            <div className="row gap-12 mt-16">
              <span className="badge badge-amber">
                <ShieldIcon size={14} /> Secure checkout
              </span>
              <span className="badge badge-amber">24×7 support</span>
            </div>
          </div>

          <div>
            <h4>Explore</h4>
            <Link to="/search/hotel">Hotels & stays</Link>
            <Link to="/search/flight">Flights</Link>
            <Link to="/search/train">Trains</Link>
            <Link to="/search/bus">Buses</Link>
            <Link to="/search/cafe">Café tables</Link>
            <Link to="/search/car">Car rentals</Link>
            <Link to="/search/ride">Rides</Link>
            <Link to="/search/experience">Experiences</Link>
          </div>

          <div>
            <h4>Company</h4>
            <Link to="/help">Help centre</Link>
            <Link to="/trips">My trips</Link>
            <Link to="/signup">Create account</Link>
            <Link to="/login">Sign in</Link>
            <a href="#deals">Deals</a>
          </div>

          <div>
            <h4>Contact</h4>
            <a href="mailto:hello@voyagr.app">
              <MailIcon size={15} /> hello@voyagr.app
            </a>
            <a href="tel:+18005550199">
              <PhoneIcon size={15} /> +1 800 555 0199
            </a>
            <p className="small" style={{ marginTop: 12, color: 'rgba(242,237,228,0.55)' }}>
              Voyagr demo environment — bookings and payments are simulated and safe to test.
            </p>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Voyagr. All rights reserved.</span>
          <span>Made for travellers · Works on Chrome & Safari · Installable app</span>
        </div>
      </div>
    </footer>
  );
}

export function Toasts() {
  const { toasts } = useApp();
  return (
    <div className="toasts" role="status" aria-live="polite">
      {toasts.map(function (t) {
        return (
          <div key={t.id} className={'toast ' + (t.kind || '')}>
            {t.kind === 'success' ? <CheckIcon size={18} /> : t.kind === 'error' ? <CloseIcon size={18} /> : <InfoIcon size={18} />}
            <span>{t.message}</span>
          </div>
        );
      })}
    </div>
  );
}

export function InstallPrompt() {
  const [deferred, setDeferred] = useState(null);
  const [visible, setVisible] = useState(false);
  const [isStandalone, setIsStandalone] = useState(false);

  useEffect(function () {
    const standalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      window.navigator.standalone === true;
    setIsStandalone(standalone);
    if (standalone) return undefined;

    let dismissed = false;
    try {
      dismissed = window.localStorage.getItem('voyagr.installDismissed') === '1';
    } catch (e) {
      /* noop */
    }

    function onPrompt(e) {
      e.preventDefault();
      setDeferred(e);
      if (!dismissed) setVisible(true);
    }
    window.addEventListener('beforeinstallprompt', onPrompt);

    // Safari/iOS has no beforeinstallprompt — show a gentle manual hint.
    const isIOS = /iPad|iPhone|iPod/.test(window.navigator.userAgent) && !window.MSStream;
    if (isIOS && !dismissed) setVisible(true);

    return function () {
      window.removeEventListener('beforeinstallprompt', onPrompt);
    };
  }, []);

  if (!visible || isStandalone) return null;

  function dismiss() {
    setVisible(false);
    try {
      window.localStorage.setItem('voyagr.installDismissed', '1');
    } catch (e) {
      /* noop */
    }
  }

  return (
    <div className="install-banner">
      <div style={{ flex: 1 }}>
        <div className="bold">Install Voyagr</div>
        <div className="small muted">
          Add the app to your home screen for one-tap booking — works on iPhone & Android.
        </div>
      </div>
      <button
        className="btn btn-primary btn-sm"
        onClick={function () {
          if (deferred && deferred.prompt) {
            deferred.prompt();
            setDeferred(null);
            setVisible(false);
          } else {
            dismiss();
          }
        }}
      >
        Install
      </button>
      <button className="icon-btn" aria-label="Dismiss" onClick={dismiss}>
        <CloseIcon size={16} />
      </button>
    </div>
  );
}

export function Money(props) {
  const { currency } = useApp();
  return <span>{formatMoney(props.usd, currency, props.opts)}</span>;
}

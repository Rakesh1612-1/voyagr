/* ------------------------------------------------------------------
   Inline SVG icon set (no external deps, crisp on every browser).
------------------------------------------------------------------- */

import React from 'react';

function S(props) {
  const size = props.size || 22;
  const stroke = props.stroke || 1.8;
  return React.createElement(
    'svg',
    {
      width: size,
      height: size,
      viewBox: '0 0 24 24',
      fill: 'none',
      stroke: 'currentColor',
      strokeWidth: stroke,
      strokeLinecap: 'round',
      strokeLinejoin: 'round',
      'aria-hidden': 'true',
      focusable: 'false',
      className: props.className,
      style: props.style,
    },
    props.children
  );
}

export function Logo(props) {
  return (
    <svg width={props.size || 38} height={props.size || 38} viewBox="0 0 48 48" aria-hidden="true">
      <defs>
        <linearGradient id="vyg-g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor="#0e1e33" />
          <stop offset="1" stopColor="#23446c" />
        </linearGradient>
        <linearGradient id="vyg-n" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f5a623" />
          <stop offset="1" stopColor="#e8613c" />
        </linearGradient>
      </defs>
      <rect x="2" y="2" width="44" height="44" rx="13" fill="url(#vyg-g)" />
      <circle cx="24" cy="24" r="13.5" fill="none" stroke="#f2ede4" strokeOpacity="0.35" strokeWidth="1.6" />
      <path d="M24 11.5 L27.6 22.8 L24 36.5 L20.4 22.8 Z" fill="url(#vyg-n)" />
      <path d="M24 11.5 L27.6 22.8 L24 22.8 Z" fill="#f5a623" />
      <circle cx="24" cy="24" r="2.1" fill="#0e1e33" stroke="#f2ede4" strokeWidth="1.1" />
    </svg>
  );
}

export const FlightIcon = function (p) {
  return (
    <S {...p}>
      <path d="M10.5 13.5 3 11l1.2-2 7 1 5-6 2 1-3.2 6.4 5.8 1.2 2-2.2 1.8.8-.6 3-2.2 1.4-6.5-1.1-3 5.4-2-.8 1.7-5.4-4.4.8-.6-1.6z" strokeWidth="1.4" fill="currentColor" stroke="none" />
    </S>
  );
};

export const HotelIcon = function (p) {
  return (
    <S {...p}>
      <path d="M3 20V8l9-4 9 4v12" />
      <path d="M7 20v-6h10v6" />
      <path d="M7 10h2M15 10h2M7 13h2M15 13h2" />
      <path d="M2 20h20" />
    </S>
  );
};

export const TrainIcon = function (p) {
  return (
    <S {...p}>
      <rect x="5" y="3" width="14" height="14" rx="4" />
      <path d="M8 7h8M7 12h10" />
      <circle cx="9" cy="13.8" r="0.6" fill="currentColor" />
      <circle cx="15" cy="13.8" r="0.6" fill="currentColor" />
      <path d="M8 17l-2.5 4M16 17l2.5 4M5 21h14" />
    </S>
  );
};

export const BusIcon = function (p) {
  return (
    <S {...p}>
      <rect x="4" y="3" width="16" height="15" rx="3" />
      <path d="M4 10h16M8 14h.01M16 14h.01" />
      <path d="M7 18v2M17 18v2M6 6h12" />
    </S>
  );
};

export const CafeIcon = function (p) {
  return (
    <S {...p}>
      <path d="M5 8h11v6a5 5 0 0 1-5 5h-1a5 5 0 0 1-5-5V8z" />
      <path d="M16 9h2.2a2.3 2.3 0 0 1 0 4.6H16" />
      <path d="M8 3c0 1-.8 1.2-.8 2.2M12 3c0 1-.8 1.2-.8 2.2" />
      <path d="M4 21h13" />
    </S>
  );
};

export const CarIcon = function (p) {
  return (
    <S {...p}>
      <path d="M4 14l1.6-4.6A3 3 0 0 1 8.4 7.4h7.2a3 3 0 0 1 2.8 2L20 14" />
      <rect x="3" y="13" width="18" height="6" rx="2.2" />
      <circle cx="7.5" cy="19" r="1.6" />
      <circle cx="16.5" cy="19" r="1.6" />
      <path d="M6.5 16h11" />
    </S>
  );
};

export const RideIcon = function (p) {
  return (
    <S {...p}>
      <path d="M3 15h18" />
      <path d="M5 15l1.4-4.2A2.6 2.6 0 0 1 8.9 9h6.2a2.6 2.6 0 0 1 2.5 1.8L19 15" />
      <rect x="4" y="15" width="16" height="4.4" rx="1.8" />
      <circle cx="8" cy="19.5" r="1.3" />
      <circle cx="16" cy="19.5" r="1.3" />
      <path d="M12 3v4M9.5 5.5 12 7l2.5-1.5" />
    </S>
  );
};

export const ExpIcon = function (p) {
  return (
    <S {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M15.2 8.8l-2 4.4-4.4 2 2-4.4z" />
      <circle cx="12" cy="12" r="1" fill="currentColor" />
    </S>
  );
};

export const SearchIcon = function (p) {
  return (
    <S {...p}>
      <circle cx="11" cy="11" r="7" />
      <path d="M20 20l-3.6-3.6" />
    </S>
  );
};

export const CalendarIcon = function (p) {
  return (
    <S {...p}>
      <rect x="3" y="5" width="18" height="16" rx="3" />
      <path d="M8 3v4M16 3v4M3 10h18" />
    </S>
  );
};

export const UserIcon = function (p) {
  return (
    <S {...p}>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 20c1.6-3.4 4.4-5 8-5s6.4 1.6 8 5" />
    </S>
  );
};

export const PinIcon = function (p) {
  return (
    <S {...p}>
      <path d="M12 21s7-5.2 7-11a7 7 0 1 0-14 0c0 5.8 7 11 7 11z" />
      <circle cx="12" cy="10" r="2.6" />
    </S>
  );
};

export const StarIcon = function (p) {
  return (
    <S {...p}>
      <path d="M12 3.6l2.5 5.2 5.7.8-4.1 4 1 5.7-5.1-2.7-5.1 2.7 1-5.7-4.1-4 5.7-.8z" fill="currentColor" stroke="none" />
    </S>
  );
};

export const ArrowIcon = function (p) {
  return (
    <S {...p}>
      <path d="M5 12h14M13 6l6 6-6 6" />
    </S>
  );
};

export const CheckIcon = function (p) {
  return (
    <S {...p}>
      <path d="M4.5 12.5l5 5L19.5 7" />
    </S>
  );
};

export const CloseIcon = function (p) {
  return (
    <S {...p}>
      <path d="M6 6l12 12M18 6L6 18" />
    </S>
  );
};

export const FilterIcon = function (p) {
  return (
    <S {...p}>
      <path d="M4 6h16M7 12h10M10 18h4" />
    </S>
  );
};

export const ClockIcon = function (p) {
  return (
    <S {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7.5V12l3.2 2" />
    </S>
  );
};

export const BagIcon = function (p) {
  return (
    <S {...p}>
      <rect x="5" y="8" width="14" height="12" rx="2.5" />
      <path d="M9 8V6a3 3 0 0 1 6 0v2" />
    </S>
  );
};

export const WifiIcon = function (p) {
  return (
    <S {...p}>
      <path d="M2.5 9a15 15 0 0 1 19 0M5.5 12.5a10.5 10.5 0 0 1 13 0M8.5 16a6 6 0 0 1 7 0" />
      <circle cx="12" cy="19" r="1.1" fill="currentColor" />
    </S>
  );
};

export const ChevronIcon = function (p) {
  return (
    <S {...p}>
      <path d="M6 9l6 6 6-6" />
    </S>
  );
};

export const GlobeIcon = function (p) {
  return (
    <S {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.6 2.6 3.9 5.6 3.9 9S14.6 18.4 12 21c-2.6-2.6-3.9-5.6-3.9-9S9.4 5.6 12 3z" />
    </S>
  );
};

export const CardIcon = function (p) {
  return (
    <S {...p}>
      <rect x="2.5" y="5.5" width="19" height="13" rx="2.6" />
      <path d="M2.5 10h19M6 14.5h4" />
    </S>
  );
};

export const ShieldIcon = function (p) {
  return (
    <S {...p}>
      <path d="M12 3l7.5 3v5.2c0 4.8-3 8.4-7.5 9.8-4.5-1.4-7.5-5-7.5-9.8V6z" />
      <path d="M9 12l2.2 2.2L15.5 10" />
    </S>
  );
};

export const MenuIcon = function (p) {
  return (
    <S {...p}>
      <path d="M4 7h16M4 12h16M4 17h16" />
    </S>
  );
};

export const HomeIcon = function (p) {
  return (
    <S {...p}>
      <path d="M4 11l8-7 8 7" />
      <path d="M6 10v9h12v-9" />
      <path d="M10 19v-5h4v5" />
    </S>
  );
};

export const TripsIcon = function (p) {
  return (
    <S {...p}>
      <rect x="4" y="7" width="16" height="13" rx="2.5" />
      <path d="M9 7V5.5A1.5 1.5 0 0 1 10.5 4h3A1.5 1.5 0 0 1 15 5.5V7" />
      <path d="M4 12h16" />
    </S>
  );
};

export const PlusIcon = function (p) {
  return (
    <S {...p}>
      <path d="M12 5v14M5 12h14" />
    </S>
  );
};

export const MinusIcon = function (p) {
  return (
    <S {...p}>
      <path d="M5 12h14" />
    </S>
  );
};

export const PhoneIcon = function (p) {
  return (
    <S {...p}>
      <path d="M7 3h3l1.5 4-2 1.6a12.5 12.5 0 0 0 5.9 5.9L17 12.5 21 14v3a3 3 0 0 1-3.2 3A16.5 16.5 0 0 1 4 6.2 3 3 0 0 1 7 3z" />
    </S>
  );
};

export const MailIcon = function (p) {
  return (
    <S {...p}>
      <rect x="3" y="5" width="18" height="14" rx="2.5" />
      <path d="M3.5 7l8.5 6 8.5-6" />
    </S>
  );
};

export const InfoIcon = function (p) {
  return (
    <S {...p}>
      <circle cx="12" cy="12" r="9" />
      <path d="M12 11v5" />
      <circle cx="12" cy="8" r="0.8" fill="currentColor" />
    </S>
  );
};

export const HeartIcon = function (p) {
  return (
    <S {...p}>
      <path d="M12 20s-7.2-4.4-7.2-9.6A4.1 4.1 0 0 1 12 7.4a4.1 4.1 0 0 1 7.2 3c0 5.2-7.2 9.6-7.2 9.6z" />
    </S>
  );
};

export const TicketIcon = function (p) {
  return (
    <S {...p}>
      <path d="M4 8a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v2a2 2 0 0 0 0 4v2a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2v-2a2 2 0 0 0 0-4V8z" />
      <path d="M13 6v2M13 11v2M13 16v2" />
    </S>
  );
};

export const SERVICE_ICONS = {
  flight: FlightIcon,
  hotel: HotelIcon,
  train: TrainIcon,
  bus: BusIcon,
  cafe: CafeIcon,
  car: CarIcon,
  ride: RideIcon,
  experience: ExpIcon,
};

export const SERVICE_META = {
  flight: { label: 'Flights', plural: 'Flights', color: '#2f6fed' },
  hotel: { label: 'Hotels', plural: 'Hotels', color: '#e8613c' },
  train: { label: 'Trains', plural: 'Trains', color: '#0f8a6a' },
  bus: { label: 'Buses', plural: 'Buses', color: '#d97706' },
  cafe: { label: 'Cafés', plural: 'Café tables', color: '#c2185b' },
  car: { label: 'Car rentals', plural: 'Car rentals', color: '#6b4fbb' },
  ride: { label: 'Rides', plural: 'Rides', color: '#0891b2' },
  experience: { label: 'Experiences', plural: 'Experiences', color: '#e11d48' },
};

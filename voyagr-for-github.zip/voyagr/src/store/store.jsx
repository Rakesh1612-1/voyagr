/* ------------------------------------------------------------------
   Global app state: currency, auth, bookings, toasts, recents.

   Storage strategy (hybrid):
   · Bookings & account are always cached in localStorage (instant,
     offline-friendly).
   · When signed in, everything syncs to the Voyagr API server so the
     same account sees the same trips on every device.
   · Guest bookings stay local until an account is created — they are
     then migrated to the server automatically.
   · If the server is unreachable, the app keeps working in local mode.
------------------------------------------------------------------- */

import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import { CURRENCIES, uid, formatMoney } from '../lib/format';
import { api, getToken, setToken } from '../lib/api';

const LS = {
  currency: 'voyagr.currency',
  session: 'voyagr.session',
  users: 'voyagr.users',
  bookings: 'voyagr.bookings',
  recents: 'voyagr.recents',
};

function load(key, fallback) {
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    return fallback;
  }
}

function save(key, value) {
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch (e) {
    /* storage full or private mode — non-fatal */
  }
}

const AppContext = createContext(null);

function seedDemoUser() {
  const users = load(LS.users, null);
  if (users && users.length) return users;
  const demo = [
    {
      id: 'u-demo',
      name: 'Aarav Sharma',
      email: 'demo@voyagr.app',
      password: 'voyagr123',
      phone: '+91 98765 43210',
      createdAt: new Date().toISOString(),
    },
  ];
  save(LS.users, demo);
  return demo;
}

function sortBookings(list) {
  return list.slice().sort(function (a, b) {
    return String(b.createdAt || '').localeCompare(String(a.createdAt || ''));
  });
}

export function AppProvider({ children }) {
  const [currency, setCurrencyState] = useState(function () {
    const saved = load(LS.currency, null);
    return saved && CURRENCIES[saved] ? saved : 'USD';
  });
  const [user, setUser] = useState(function () {
    return load(LS.session, null);
  });
  const [bookings, setBookings] = useState(function () {
    return load(LS.bookings, []);
  });
  const [toasts, setToasts] = useState([]);
  const [recents, setRecents] = useState(function () {
    return load(LS.recents, []);
  });

  useEffect(function () {
    seedDemoUser();
  }, []);

  useEffect(function () {
    save(LS.currency, currency);
  }, [currency]);

  useEffect(function () {
    if (user) save(LS.session, user);
    else {
      try {
        window.localStorage.removeItem(LS.session);
      } catch (e) {
        /* noop */
      }
    }
  }, [user]);

  useEffect(function () {
    save(LS.bookings, bookings);
  }, [bookings]);

  useEffect(function () {
    save(LS.recents, recents);
  }, [recents]);

  /* ------------------------- server sync helpers ------------------------- */

  const mergeServerBookings = useCallback(function (serverList) {
    setBookings(function (prev) {
      const map = {};
      prev.forEach(function (b) {
        map[b.id] = b;
      });
      serverList.forEach(function (b) {
        const local = map[b.id];
        map[b.id] = local ? Object.assign({}, local, b) : b;
      });
      return sortBookings(Object.keys(map).map(function (k) {
        return map[k];
      }));
    });
  }, []);

  const migrateGuestBookings = useCallback(
    function (token, ownerEmail) {
      const locals = load(LS.bookings, []).filter(function (b) {
        return b.ownerEmail === 'guest' || !b.ownerEmail;
      });
      const pushes = locals.map(function (b) {
        return api('/bookings', { method: 'POST', token: token, body: b }).catch(function () {
          /* retried on next sign-in */
        });
      });
      setBookings(function (prev) {
        return prev.map(function (b) {
          return b.ownerEmail === 'guest' || !b.ownerEmail
            ? Object.assign({}, b, { ownerEmail: ownerEmail })
            : b;
        });
      });
      return Promise.all(pushes);
    },
    []
  );

  /* --------------------------- session restore --------------------------- */
  useEffect(function () {
    const token = getToken();
    if (!token) return;
    api('/auth/me', { token: token })
      .then(function (res) {
        setUser(res.user);
        return api('/bookings', { token: token });
      })
      .then(function (res) {
        mergeServerBookings(res.bookings || []);
      })
      .catch(function (err) {
        if (err.status === 401) {
          setToken('');
          setUser(null);
        }
        // offline → keep cached session & bookings as-is
      });
  }, [mergeServerBookings]);

  /* ------------------------------- toasts ------------------------------- */
  const toast = useCallback(function (message, kind) {
    const id = uid('t');
    setToasts(function (prev) {
      return prev.concat([{ id: id, message: message, kind: kind || 'info' }]);
    });
    window.setTimeout(function () {
      setToasts(function (prev) {
        return prev.filter(function (t) {
          return t.id !== id;
        });
      });
    }, 3600);
  }, []);

  /* -------------------------------- auth -------------------------------- */

  const signup = useCallback(
    function (name, email, password, phone) {
      return api('/auth/signup', {
        method: 'POST',
        body: { name: name, email: email, password: password, phone: phone },
      })
        .then(function (res) {
          setToken(res.token);
          setUser(res.user);
          return migrateGuestBookings(res.token, res.user.email).then(function () {
            return { ok: true, message: 'Welcome to Voyagr, ' + String(name).split(' ')[0] + '!' };
          });
        })
        .catch(function (err) {
          if (!err.offline) return { ok: false, message: err.message };
          // Offline fallback — local-only account
          const users = seedDemoUser();
          const exists = users.some(function (u) {
            return u.email.toLowerCase() === String(email).toLowerCase();
          });
          if (exists) return { ok: false, message: 'An account with that email already exists' };
          const newUser = {
            id: uid('u'),
            name: name,
            email: email,
            password: password,
            phone: phone || '',
            createdAt: new Date().toISOString(),
          };
          save(LS.users, users.concat([newUser]));
          setUser({ id: newUser.id, name: newUser.name, email: newUser.email, phone: newUser.phone });
          return {
            ok: true,
            message: 'Welcome! (Offline mode — trips stay on this device until the server is back.)',
          };
        });
    },
    [migrateGuestBookings]
  );

  const login = useCallback(
    function (email, password) {
      return api('/auth/login', { method: 'POST', body: { email: email, password: password } })
        .then(function (res) {
          setToken(res.token);
          setUser(res.user);
          return migrateGuestBookings(res.token, res.user.email).then(function () {
            return api('/bookings', { token: res.token });
          });
        })
        .then(function (res) {
          if (res && res.bookings) mergeServerBookings(res.bookings);
          return { ok: true, message: 'Welcome back!' };
        })
        .catch(function (err) {
          if (!err.offline) {
            // Offline fallback: local demo users only if the server rejects nothing better
            const users = seedDemoUser();
            const found = users.filter(function (u) {
              return u.email.toLowerCase() === String(email).toLowerCase() && u.password === password;
            })[0];
            if (found) {
              setUser({ id: found.id, name: found.name, email: found.email, phone: found.phone });
              return {
                ok: true,
                message: 'Signed in locally (server unreachable) — trips sync when back online.',
              };
            }
            return { ok: false, message: err.message };
          }
          // offline: local auth
          const users = seedDemoUser();
          const found = users.filter(function (u) {
            return u.email.toLowerCase() === String(email).toLowerCase() && u.password === password;
          })[0];
          if (!found) return { ok: false, message: 'Invalid email or password (offline mode)' };
          setUser({ id: found.id, name: found.name, email: found.email, phone: found.phone });
          return {
            ok: true,
            message: 'Signed in locally (offline mode) — trips sync when back online.',
          };
        });
    },
    [mergeServerBookings, migrateGuestBookings]
  );

  const logout = useCallback(function () {
    setToken('');
    setUser(null);
  }, []);

  /* ------------------------------ bookings ------------------------------ */

  const addBooking = useCallback(
    function (booking) {
      const record = Object.assign({}, booking, {
        id: booking.id || uid('b'),
        createdAt: booking.createdAt || new Date().toISOString(),
        status: booking.status || 'confirmed',
        ownerEmail: booking.ownerEmail || (user && user.email) || 'guest',
      });
      setBookings(function (prev) {
        return sortBookings([record].concat(prev));
      });
      const token = getToken();
      if (token && user) {
        api('/bookings', { method: 'POST', token: token, body: record }).catch(function () {
          /* cached locally — will sync on next visit */
        });
      }
      return record;
    },
    [user]
  );

  const cancelBooking = useCallback(function (bookingId) {
    setBookings(function (prev) {
      return prev.map(function (b) {
        return b.id === bookingId
          ? Object.assign({}, b, { status: 'cancelled', cancelledAt: new Date().toISOString() })
          : b;
      });
    });
    const token = getToken();
    if (token) {
      api('/bookings/' + encodeURIComponent(bookingId), {
        method: 'PATCH',
        token: token,
        body: { status: 'cancelled', cancelledAt: new Date().toISOString() },
      }).catch(function () {
        /* stays cancelled locally */
      });
    }
  }, []);

  const myBookings = useMemo(
    function () {
      const email = user && user.email;
      return bookings.filter(function (b) {
        return email ? b.ownerEmail === email || b.ownerEmail === 'guest' : b.ownerEmail === 'guest';
      });
    },
    [bookings, user]
  );

  const pushRecent = useCallback(function (entry) {
    setRecents(function (prev) {
      const filtered = prev.filter(function (r) {
        return JSON.stringify(r) !== JSON.stringify(entry);
      });
      return [entry].concat(filtered).slice(0, 6);
    });
  }, []);

  const setCurrency = useCallback(function (code) {
    if (CURRENCIES[code]) setCurrencyState(code);
  }, []);

  const value = useMemo(
    function () {
      return {
        currency: currency,
        setCurrency: setCurrency,
        user: user,
        signup: signup,
        login: login,
        logout: logout,
        bookings: bookings,
        myBookings: myBookings,
        addBooking: addBooking,
        cancelBooking: cancelBooking,
        toasts: toasts,
        toast: toast,
        recents: recents,
        pushRecent: pushRecent,
        synced: Boolean(user && getToken()),
      };
    },
    [currency, setCurrency, user, signup, login, logout, bookings, myBookings, addBooking, cancelBooking, toasts, toast, recents, pushRecent]
  );

  return React.createElement(AppContext.Provider, { value: value }, children);
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used inside AppProvider');
  return ctx;
}

/** Convenience hook: format a USD amount in the active display currency. */
export function useMoney() {
  const { currency } = useApp();
  return useCallback(
    function (usd, opts) {
      return formatMoney(usd, currency, opts);
    },
    [currency]
  );
}

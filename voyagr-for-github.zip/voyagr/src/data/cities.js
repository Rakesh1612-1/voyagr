/* -----------------------------
   Cities & lightweight geo data
------------------------------ */

export const CITIES = [
  // India
  { id: 'delhi', name: 'New Delhi', country: 'India', code: 'DEL', lat: 28.61, lng: 77.21, tagline: 'Mughal grandeur meets street-food heaven', vibe: 'history,food,culture' },
  { id: 'mumbai', name: 'Mumbai', country: 'India', code: 'BOM', lat: 19.08, lng: 72.88, tagline: 'The city that never sleeps', vibe: 'nightlife,food,coast' },
  { id: 'bengaluru', name: 'Bengaluru', country: 'India', code: 'BLR', lat: 12.97, lng: 77.59, tagline: 'Gardens, breweries and bright ideas', vibe: 'food,nightlife,tech' },
  { id: 'goa', name: 'Goa', country: 'India', code: 'GOI', lat: 15.29, lng: 74.02, tagline: 'Beach sunsets and slow living', vibe: 'beach,nightlife,food' },
  { id: 'jaipur', name: 'Jaipur', country: 'India', code: 'JAI', lat: 26.91, lng: 75.79, tagline: 'The rose-pink royal city', vibe: 'history,culture,shopping' },
  { id: 'chennai', name: 'Chennai', country: 'India', code: 'MAA', lat: 13.08, lng: 80.27, tagline: 'Temples, filter coffee, Marina sands', vibe: 'beach,food,culture' },
  { id: 'kolkata', name: 'Kolkata', country: 'India', code: 'CCU', lat: 22.57, lng: 88.36, tagline: 'Art, adda and legendary sweets', vibe: 'culture,food,history' },
  { id: 'hyderabad', name: 'Hyderabad', country: 'India', code: 'HYD', lat: 17.38, lng: 78.49, tagline: 'Pearls, biryani and tech towers', vibe: 'food,history,tech' },
  { id: 'kochi', name: 'Kochi', country: 'India', code: 'COK', lat: 9.93, lng: 76.27, tagline: 'Chinese nets and spice-scented lanes', vibe: 'beach,food,culture' },
  { id: 'udaipur', name: 'Udaipur', country: 'India', code: 'UDR', lat: 24.58, lng: 73.71, tagline: 'Lakes, palaces and golden light', vibe: 'history,romance,culture' },
  // Asia & Middle East
  { id: 'dubai', name: 'Dubai', country: 'UAE', code: 'DXB', lat: 25.2, lng: 55.27, tagline: 'Sky-high luxury and desert nights', vibe: 'luxury,shopping,desert' },
  { id: 'singapore', name: 'Singapore', country: 'Singapore', code: 'SIN', lat: 1.35, lng: 103.82, tagline: 'A garden city of flavours', vibe: 'food,city,shopping' },
  { id: 'bangkok', name: 'Bangkok', country: 'Thailand', code: 'BKK', lat: 13.75, lng: 100.5, tagline: 'Golden temples and night markets', vibe: 'food,nightlife,culture' },
  { id: 'bali', name: 'Bali', country: 'Indonesia', code: 'DPS', lat: -8.41, lng: 115.19, tagline: 'Rice terraces and surf beaches', vibe: 'beach,wellness,nature' },
  { id: 'tokyo', name: 'Tokyo', country: 'Japan', code: 'HND', lat: 35.68, lng: 139.69, tagline: 'Neon nights, quiet shrines', vibe: 'city,food,culture' },
  { id: 'kualalumpur', name: 'Kuala Lumpur', country: 'Malaysia', code: 'KUL', lat: 3.14, lng: 101.69, tagline: 'Skyline views and hawker feasts', vibe: 'food,city,shopping' },
  { id: 'male', name: 'Malé Atolls', country: 'Maldives', code: 'MLE', lat: 4.2, lng: 73.51, tagline: 'Overwater villas and turquoise reefs', vibe: 'beach,luxury,romance' },
  { id: 'istanbul', name: 'Istanbul', country: 'Türkiye', code: 'IST', lat: 41.01, lng: 28.98, tagline: 'Where Europe meets Asia', vibe: 'history,food,culture' },
  // Europe
  { id: 'london', name: 'London', country: 'UK', code: 'LHR', lat: 51.51, lng: -0.13, tagline: 'Royalty, markets and riverside pubs', vibe: 'city,culture,history' },
  { id: 'paris', name: 'Paris', country: 'France', code: 'CDG', lat: 48.86, lng: 2.35, tagline: 'Cafés, couture and the Seine', vibe: 'romance,culture,food' },
  { id: 'rome', name: 'Rome', country: 'Italy', code: 'FCO', lat: 41.9, lng: 12.5, tagline: 'An open-air museum of empire', vibe: 'history,food,culture' },
  { id: 'amsterdam', name: 'Amsterdam', country: 'Netherlands', code: 'AMS', lat: 52.37, lng: 4.9, tagline: 'Canals, cycles and cosy cafés', vibe: 'city,culture,nightlife' },
  // Americas & Oceania
  { id: 'newyork', name: 'New York', country: 'USA', code: 'JFK', lat: 40.71, lng: -74.01, tagline: 'The five-borough buzz', vibe: 'city,food,culture' },
  { id: 'sanfrancisco', name: 'San Francisco', country: 'USA', code: 'SFO', lat: 37.77, lng: -122.42, tagline: 'Fog, bridges and bold flavours', vibe: 'city,food,tech' },
  { id: 'sydney', name: 'Sydney', country: 'Australia', code: 'SYD', lat: -33.87, lng: 151.21, tagline: 'Harbour sails and surf beaches', vibe: 'beach,city,nature' },
];

export const CITY_BY_ID = {};
CITIES.forEach(function (c) {
  CITY_BY_ID[c.id] = c;
});

export function cityLabel(id) {
  const c = CITY_BY_ID[id];
  return c ? c.name + ', ' + c.country : id;
}

export function cityShort(id) {
  const c = CITY_BY_ID[id];
  return c ? c.name : id;
}

export function searchCities(q) {
  const query = String(q || '').trim().toLowerCase();
  if (!query) return CITIES.slice(0, 8);
  return CITIES.filter(function (c) {
    return (
      c.name.toLowerCase().indexOf(query) >= 0 ||
      c.country.toLowerCase().indexOf(query) >= 0 ||
      c.code.toLowerCase().indexOf(query) >= 0
    );
  });
}

export const POPULAR_PAIRS = [
  { from: 'delhi', to: 'goa', label: 'Beach escape' },
  { from: 'mumbai', to: 'dubai', label: 'Weekend luxury' },
  { from: 'bengaluru', to: 'singapore', label: 'Food & city' },
  { from: 'delhi', to: 'london', label: 'Long-haul classic' },
  { from: 'chennai', to: 'bali', label: 'Island vibes' },
  { from: 'mumbai', to: 'jaipur', label: 'Royal road' },
];

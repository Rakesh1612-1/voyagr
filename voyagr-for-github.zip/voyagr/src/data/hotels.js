/* ------------------------------------------------------------------
   Hotel inventory. Compact raw rows are expanded into full objects,
   with room types generated deterministically per hotel.
------------------------------------------------------------------- */

import { seededRandom, intBetween, between, round2 } from '../lib/format';

const AMENITY_LABELS = {
  wifi: 'Free Wi-Fi',
  breakfast: 'Breakfast included',
  pool: 'Swimming pool',
  spa: 'Spa & wellness',
  gym: 'Fitness centre',
  restaurant: 'Restaurant',
  bar: 'Bar & lounge',
  parking: 'Free parking',
  ac: 'Air conditioning',
  airport: 'Airport shuttle',
  family: 'Family rooms',
  pet: 'Pet friendly',
  beach: 'Beach access',
  workspace: 'Co-working space',
};

// [id, name, city, area, stars, rating, reviews, priceUSD, amenities, tags, blurb]
const RAW = [
  ['marigold-jaipur', 'The Marigold Jaipur', 'jaipur', 'Civil Lines', 5, 4.7, 2841, 142, 'wifi,breakfast,pool,spa,restaurant,bar,parking,ac,family', 'heritage,romantic', 'A restored 1920s haveli with courtyards, mirror-work interiors and a rooftop restaurant overlooking the Pink City.'],
  ['lake-palace-udaipur', 'Lakeview Palace Udaipur', 'udaipur', 'Lake Pichola', 5, 4.8, 3620, 188, 'wifi,breakfast,pool,spa,restaurant,bar,parking,ac,airport', 'romantic,luxury,heritage', 'Marble corridors, a lake-facing infinity pool and sunset boat rides from a private jetty.'],
  ['aravalli-retreat', 'Aravalli Retreat', 'udaipur', 'Sajjangarh', 4, 4.4, 1204, 96, 'wifi,breakfast,pool,restaurant,parking,ac,family', 'family,views', 'A hillside hideaway with valley views, candle-lit dinners and easy access to the monsoon palace.'],
  ['indigo-court-delhi', 'Indigo Court New Delhi', 'delhi', 'Connaught Place', 5, 4.5, 5210, 154, 'wifi,breakfast,pool,gym,restaurant,bar,parking,ac,airport,workspace', 'business,city', 'Art-deco glamour in the heart of Lutyens’ Delhi, steps from galleries, markets and metro lines.'],
  ['garden-nine-delhi', 'Garden Nine Delhi', 'delhi', 'Hauz Khas', 4, 4.3, 2210, 88, 'wifi,breakfast,restaurant,bar,ac,gym,workspace', 'boutique,nightlife', 'A leafy boutique stay beside Hauz Khas village, with a courtyard café and design-led suites.'],
  ['marine-drive-mumbai', 'Marine Drive Grand', 'mumbai', 'Marine Drive', 5, 4.6, 6890, 176, 'wifi,breakfast,pool,gym,restaurant,bar,ac,airport,workspace', 'business,sea-view', 'Sea-facing rooms along the Queen’s Necklace, legendary breakfasts and a rooftop infinity pool.'],
  ['bandra-lane-mumbai', 'Bandra Lane House', 'mumbai', 'Bandra West', 4, 4.4, 2432, 102, 'wifi,breakfast,restaurant,bar,ac,gym,workspace', 'boutique,nightlife', 'A Portuguese-era villa turned boutique hotel among Bandra’s cafés, street art and sunset promenades.'],
  ['cubbon-bengaluru', 'Cubbon Park Residency', 'bengaluru', 'Central Bengaluru', 5, 4.5, 4120, 132, 'wifi,breakfast,pool,gym,restaurant,bar,ac,parking,workspace', 'business,family', 'Colonial charm beside Cubbon Park, with a conservatory bar and some of the city’s best dosas at breakfast.'],
  ['indiranagar-loft', 'Indiranagar Loft', 'bengaluru', 'Indiranagar', 4, 4.2, 1580, 74, 'wifi,breakfast,restaurant,bar,ac,workspace,gym', 'nightlife,boutique', 'Loft-style rooms above the city’s liveliest brewery strip — soundproofed, stylish and central.'],
  ['goa-palm-bay', 'Palm Bay Goa', 'goa', 'Candolim', 5, 4.6, 5230, 128, 'wifi,breakfast,pool,spa,restaurant,bar,ac,beach,family,parking', 'beach,family', 'A laid-back resort with a palm-fringed pool, beach shack service and live music on weekends.'],
  ['goa-casa-mar', 'Casa Mar Goa', 'goa', 'Assagao', 4, 4.5, 1892, 86, 'wifi,breakfast,pool,restaurant,bar,ac,pet,parking', 'boutique,romantic', 'A restored Portuguese farmhouse in quiet Assagao, with a saltwater pool and garden breakfasts.'],
  ['azure-chennai', 'Azure Marina Chennai', 'chennai', 'Marina Beach', 5, 4.4, 3210, 118, 'wifi,breakfast,pool,gym,restaurant,bar,ac,airport,workspace', 'sea-view,business', 'Modern seafront tower with sunrise views over Marina Beach and a celebrated Chettinad kitchen.'],
  ['coromandel-chennai', 'Coromandel House', 'chennai', 'Mylapore', 4, 4.2, 1240, 68, 'wifi,breakfast,restaurant,ac,family,parking', 'heritage,family', 'A heritage home near Kapaleeshwarar temple with courtyard rooms and filter-coffee mornings.'],
  ['hooghly-kolkata', 'Hooghly River House', 'kolkata', 'Park Street', 4, 4.3, 1980, 72, 'wifi,breakfast,restaurant,bar,ac,gym,workspace', 'heritage,city', 'Riverside balconies, a colonial-era library bar and Park Street’s live music on your doorstep.'],
  ['victoria-kolkata', 'The Victoria Kolkata', 'kolkata', 'Ballygunge', 5, 4.5, 2640, 112, 'wifi,breakfast,pool,spa,gym,restaurant,bar,ac,airport', 'luxury,family', 'Grand suites, a marble spa and a rooftop pool with views across the Maidan.'],
  ['charminar-hyderabad', 'Charminar Grand', 'hyderabad', 'Banjara Hills', 5, 4.5, 3890, 122, 'wifi,breakfast,pool,gym,restaurant,bar,ac,airport,workspace,parking', 'business,family', 'Banjara Hills glamour with a biryani kitchen that has its own fan club and a skyline pool.'],
  ['kokum-kochi', 'Kokum Kochi', 'kochi', 'Fort Kochi', 4, 4.6, 1720, 78, 'wifi,breakfast,restaurant,bar,ac,spa,beach', 'boutique,heritage', 'Teak beams, spice-garden showers and a café facing the Chinese nets of Fort Kochi.'],
  ['backwaters-kochi', 'Backwater Haven Kumarakom', 'kochi', 'Kumarakom', 5, 4.7, 2210, 156, 'wifi,breakfast,pool,spa,restaurant,bar,ac,beach,family', 'romantic,nature', 'Overwater villas on the Vembanad backwaters with houseboat sunsets and Ayurvedic spa rituals.'],
  ['dubai-marina-sky', 'Marina Sky Dubai', 'dubai', 'Dubai Marina', 5, 4.7, 8920, 210, 'wifi,breakfast,pool,gym,restaurant,bar,ac,airport,spa,workspace', 'luxury,city', 'A soaring marina tower with private beach access, skyline views and world-class dining.'],
  ['desert-dubai', 'Desert Ember Resort', 'dubai', 'Al Marmoom', 5, 4.8, 2140, 268, 'wifi,breakfast,pool,spa,restaurant,bar,ac,parking,family', 'desert,romantic,luxury', 'Dune-side villas, falconry at dawn and starlit dinners in the desert conservation reserve.'],
  ['orchard-singapore', 'Orchard Garden Singapore', 'singapore', 'Orchard Road', 5, 4.6, 7120, 198, 'wifi,breakfast,pool,gym,spa,restaurant,bar,ac,airport,workspace', 'city,shopping', 'A green oasis above Orchard Road with sky gardens, a 50 m pool and hawker-inspired fine dining.'],
  ['marina-singapore', 'Marina Bay Lumen', 'singapore', 'Marina Bay', 5, 4.8, 9340, 246, 'wifi,breakfast,pool,gym,spa,restaurant,bar,ac,airport,workspace', 'luxury,city', 'Infinity pool on the 40th floor, light art installations and bay views from every room.'],
  ['riverside-bangkok', 'Riverside Bangkok', 'bangkok', 'Riverside', 5, 4.5, 6210, 132, 'wifi,breakfast,pool,spa,restaurant,bar,ac,airport,family', 'city,family', 'Chao Phraya sunsets, a flower-market breakfast and a shuttle boat to the old town.'],
  ['sukhumvit-bangkok', 'Sukhumvit Social', 'bangkok', 'Sukhumvit', 4, 4.3, 2890, 66, 'wifi,breakfast,pool,restaurant,bar,ac,gym,workspace', 'nightlife,city', 'Bright rooms over Bangkok’s best street-food lanes, with a rooftop bar and late-night kitchen.'],
  ['ubud-bali', 'Ubud Canopy Bali', 'bali', 'Ubud', 5, 4.8, 4520, 164, 'wifi,breakfast,pool,spa,restaurant,bar,ac,family', 'nature,wellness,romantic', 'Jungle villas with private plunge pools, yoga decks above the Ayung river and farm-to-table dining.'],
  ['seminyak-bali', 'Seminyak Surf House', 'bali', 'Seminyak', 4, 4.5, 3320, 98, 'wifi,breakfast,pool,restaurant,bar,ac,beach', 'beach,nightlife', 'Barefoot luxury a wave from the beach, with surf lessons, sun loungers and sunset cocktails.'],
  ['tokyo-sky', 'Sky Lantern Tokyo', 'tokyo', 'Shinjuku', 5, 4.6, 5680, 222, 'wifi,breakfast,gym,restaurant,bar,ac,airport,workspace', 'city,business', 'Minimalist rooms with city views, a tea lounge on the 30th floor and instant train access.'],
  ['kyoto-ish-tokyo', 'Old Tokyo Ryokan', 'tokyo', 'Asakusa', 4, 4.5, 1920, 148, 'wifi,breakfast,restaurant,ac,spa', 'heritage,family', 'A lantern-lit ryokan near Sensō-ji with tatami suites, kaiseki dinners and cedar baths.'],
  ['london-mayfair', 'Mayfair Rowan London', 'london', 'Mayfair', 5, 4.7, 4820, 268, 'wifi,breakfast,gym,spa,restaurant,bar,ac,airport,workspace', 'luxury,city', 'A Georgian townhouse hotel with a Michelin-starred dining room and a hidden cocktail library.'],
  ['shoreditch-london', 'Shoreditch Yard', 'london', 'Shoreditch', 4, 4.4, 2310, 156, 'wifi,breakfast,restaurant,bar,ac,gym,workspace', 'nightlife,boutique', 'Warehouse-loft rooms around a courtyard of street-food stalls, record shops and galleries.'],
  ['paris-leftbank', 'Left Bank Maison', 'paris', 'Saint-Germain', 5, 4.7, 5210, 288, 'wifi,breakfast,restaurant,bar,ac,spa,airport', 'romantic,luxury', 'Silk-wallpapered rooms on a quiet Saint-Germain street, with a bistro that spills onto the sidewalk.'],
  ['marais-paris', 'Le Marais Atelier', 'paris', 'Le Marais', 4, 4.4, 2140, 172, 'wifi,breakfast,restaurant,bar,ac,workspace', 'boutique,city', 'An art-studio hotel among the Marais’ vintage shops, galleries and falafel legends.'],
  ['rome-trastevere', 'Trastevere Oro', 'rome', 'Trastevere', 4, 4.5, 2680, 148, 'wifi,breakfast,restaurant,bar,ac,family', 'heritage,food', 'Ivy-covered walls, cobbled lanes and a rooftop where the whole of Rome turns gold at sunset.'],
  ['amsterdam-canals', 'Canal House Amsterdam', 'amsterdam', 'Jordaan', 4, 4.5, 2890, 178, 'wifi,breakfast,restaurant,bar,ac,bike,workspace', 'boutique,city', 'A gabled canal house with bike hire, Dutch breakfasts and a candle-lit cellar bar.'],
  ['newyork-soho', 'Soho Grand Atelier', 'newyork', 'SoHo', 5, 4.6, 6720, 298, 'wifi,breakfast,gym,restaurant,bar,ac,workspace,airport', 'city,nightlife', 'Cast-iron loft glamour with a rooftop members’ bar and every downtown address within walking distance.'],
  ['brooklyn-newyork', 'Brooklyn Bridge Lodge', 'newyork', 'Brooklyn Heights', 4, 4.4, 3120, 196, 'wifi,breakfast,restaurant,bar,ac,gym,workspace', 'city,family', 'Bridge-view rooms, a bakery café and leafy Brooklyn Heights promenades outside the door.'],
  ['bayview-sf', 'Bayview San Francisco', 'sanfrancisco', 'Embarcadero', 5, 4.5, 4210, 232, 'wifi,breakfast,gym,restaurant,bar,ac,workspace,airport', 'business,city', 'Fog-kissed bay views, a seafood raw bar and streetcars rattling past the entrance.'],
  ['sydney-cove', 'Sydney Cove Hotel', 'sydney', 'Circular Quay', 5, 4.7, 5340, 244, 'wifi,breakfast,pool,gym,spa,restaurant,bar,ac,airport', 'sea-view,luxury', 'Opera House views from your bed, a harbour-facing pool and ferry rides from the doorstep.'],
  ['manila-ish-sydney', 'Bondi Salt House', 'sydney', 'Bondi Beach', 4, 4.5, 2760, 168, 'wifi,breakfast,restaurant,bar,ac,beach,gym', 'beach,nightlife', 'A salt-weathered beach house with surfboard storage, rooftop yoga and café-quality flat whites.'],
  ['kl-towers', 'Twin Towers View KL', 'kualalumpur', 'KLCC', 5, 4.5, 4890, 118, 'wifi,breakfast,pool,gym,spa,restaurant,bar,ac,airport,family', 'city,family', 'Petronas views from the infinity pool, a hawker-style food hall and monorail at the door.'],
  ['male-overwater', 'Coral Atoll Villas Malé', 'male', 'North Malé', 5, 4.9, 1820, 420, 'wifi,breakfast,pool,spa,restaurant,bar,ac,beach,airport', 'beach,romantic,luxury', 'Overwater villas with glass floors, private reefs and a seaplane lounge experience.'],
  ['istanbul-bosphorus', 'Bosphorus Ember', 'istanbul', 'Sultanahmet', 5, 4.6, 5120, 158, 'wifi,breakfast,pool,spa,restaurant,bar,ac,airport,family', 'heritage,city', 'Between the Blue Mosque and the Grand Bazaar, with a hamam, terrace breakfasts and sea views.'],
];

function makeRooms(hotel, rng) {
  const templates = [
    { id: 'deluxe', name: 'Deluxe Room', bed: '1 king or 2 singles', sqm: 26, factor: 1, view: 'City view' },
    { id: 'superior', name: 'Superior Room', bed: '1 king', sqm: 32, factor: 1.22, view: 'Pool or garden view' },
    { id: 'suite', name: 'Executive Suite', bed: '1 king + sofa bed', sqm: 46, factor: 1.55, view: 'Panoramic view' },
    { id: 'family', name: 'Family Room', bed: '1 king + 2 singles', sqm: 42, factor: 1.38, view: 'Garden view' },
  ];
  return templates.map(function (t, idx) {
    return {
      id: t.id,
      name: t.name,
      bed: t.bed,
      sqm: t.sqm + intBetween(rng, 0, 6),
      view: t.view,
      priceFactor: round2(t.factor * between(rng, 0.97, 1.08)),
      refundable: idx !== 0 || rng() > 0.4,
      breakfast: hotel.amenities.indexOf('breakfast') >= 0,
      left: intBetween(rng, 1, 9),
    };
  });
}

function makeGallery(hotel, rng) {
  const scenes = [
    { src: '/img/hotel.jpg', label: 'Pool & views' },
    { src: '/img/experience.jpg', label: 'Around the property' },
    { src: '/img/cafe.jpg', label: 'Dining' },
    { src: '/img/road.jpg', label: 'Neighbourhood' },
  ];
  return scenes.map(function (s) {
    return { src: s.src, label: s.label, hue: intBetween(rng, 160, 220) };
  });
}

export const HOTELS = RAW.map(function (row) {
  const rng = seededRandom('hotel', row[0]);
  const amenities = row[8].split(',');
  const hotel = {
    id: row[0],
    name: row[1],
    city: row[2],
    area: row[3],
    stars: row[4],
    rating: row[5],
    reviews: row[6],
    priceUSD: row[7],
    amenities: amenities,
    amenityLabels: amenities.map(function (a) {
      return AMENITY_LABELS[a] || a;
    }),
    tags: row[9].split(','),
    blurb: row[10],
    image: '/img/hotel.jpg',
    hue: intBetween(rng, 180, 260),
    checkIn: '14:00',
    checkOut: '11:00',
    distanceKm: round2(between(rng, 0.3, 6.5)),
  };
  hotel.rooms = makeRooms(hotel, rng);
  hotel.gallery = makeGallery(hotel, rng);
  return hotel;
});

const HOTELS_BY_ID = {};
HOTELS.forEach(function (h) {
  HOTELS_BY_ID[h.id] = h;
});

export function getHotel(id) {
  return HOTELS_BY_ID[id] || null;
}

export function hotelsByCity(cityId) {
  return HOTELS.filter(function (h) {
    return h.city === cityId;
  });
}

export const AMENITIES = Object.keys(AMENITY_LABELS).map(function (k) {
  return { id: k, label: AMENITY_LABELS[k] };
});

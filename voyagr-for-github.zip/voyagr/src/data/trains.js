/* ------------------------------------------------------------------
   Rail inventory + seat map generator (deterministic per train/date).
------------------------------------------------------------------- */

import { CITY_BY_ID } from './cities';
import { seededRandom, intBetween, between, haversineKm, round2, addMinutesToTime } from '../lib/format';

const IN_RAIL_CLASSES = [
  { code: '1A', name: 'First AC', farePerKm: 0.052, coaches: 2, berths: 2, layout: 'berth', comfort: 'private coupe, meals, linens' },
  { code: '2A', name: 'AC 2-Tier', farePerKm: 0.036, coaches: 3, berths: 4, layout: 'berth', comfort: 'AC coach, curtains, linens' },
  { code: '3A', name: 'AC 3-Tier', farePerKm: 0.026, coaches: 5, berths: 6, layout: 'berth', comfort: 'AC coach, bedding' },
  { code: 'SL', name: 'Sleeper', farePerKm: 0.014, coaches: 6, berths: 6, layout: 'berth', comfort: 'open coach, fan cooled' },
  { code: 'CC', name: 'Chair Car', farePerKm: 0.022, coaches: 4, berths: 0, layout: 'chair', comfort: 'AC seating, 2+3 layout' },
];

const INT_RAIL_CLASSES = [
  { code: 'STD', name: 'Standard', farePerKm: 0.09, coaches: 4, berths: 0, layout: 'chair', comfort: 'comfortable seating, café car' },
  { code: 'FIRST', name: 'First Class', farePerKm: 0.15, coaches: 2, berths: 0, layout: 'chair', comfort: 'spacious seats, at-seat service' },
  { code: 'BIZ', name: 'Business', farePerKm: 0.22, coaches: 1, berths: 0, layout: 'chair', comfort: 'lie-flat seats, lounge access' },
];

// [id, number, name, from, to, dep, durationMin, days, international]
const RAW = [
  ['nb-2001', 'NV 2001', 'Capital Shatabdi', 'delhi', 'jaipur', '06:10', 265, 'Daily', false],
  ['nb-2002', 'NV 2002', 'Pink City Express', 'delhi', 'jaipur', '17:45', 280, 'Daily', false],
  ['nb-2201', 'NV 2201', 'Konkan Link', 'mumbai', 'goa', '07:20', 495, 'Daily', false],
  ['nb-2202', 'NV 2202', 'Coastal Rider', 'mumbai', 'goa', '21:15', 520, 'Mon,Wed,Fri,Sun', false],
  ['nb-2401', 'NV 2401', 'Deccan Superfast', 'bengaluru', 'chennai', '08:05', 335, 'Daily', false],
  ['nb-2402', 'NV 2402', 'Garden City Mail', 'bengaluru', 'chennai', '20:30', 355, 'Daily', false],
  ['nb-2601', 'NV 2601', 'Heritage Express', 'jaipur', 'udaipur', '09:40', 365, 'Daily', false],
  ['nb-2801', 'NV 2801', 'Peninsula Rapid', 'chennai', 'kochi', '16:25', 645, 'Tue,Thu,Sat', false],
  ['nb-2802', 'NV 2802', 'Kaveri Link', 'hyderabad', 'bengaluru', '06:55', 585, 'Daily', false],
  ['nb-2803', 'NV 2803', 'Southern Star', 'delhi', 'kolkata', '18:15', 1020, 'Daily', false],
  ['nb-2804', 'NV 2804', 'Marudhar Express', 'mumbai', 'hyderabad', '22:40', 830, 'Daily', false],
  ['nb-2805', 'NV 2805', 'Himalaya Vista', 'delhi', 'mumbai', '16:50', 985, 'Daily', false],
  ['nb-9001', 'ES 9001', 'Channel Star', 'london', 'paris', '08:01', 155, 'Daily', true],
  ['nb-9002', 'ES 9002', 'Rhine Valley Express', 'paris', 'amsterdam', '10:25', 195, 'Daily', true],
  ['nb-9003', 'KL 9003', 'Peninsula Rail', 'singapore', 'kualalumpur', '09:30', 420, 'Daily', true],
];

function classesFor(international) {
  return international ? INT_RAIL_CLASSES : IN_RAIL_CLASSES;
}

export const TRAINS = RAW.map(function (row) {
  const from = CITY_BY_ID[row[3]];
  const to = CITY_BY_ID[row[4]];
  const dist = haversineKm(from, to);
  return {
    id: row[0],
    type: 'train',
    number: row[1],
    name: row[2],
    from: row[3],
    to: row[4],
    dep: row[5],
    arr: addMinutesToTime(row[5], row[6]).time,
    arrDayOffset: addMinutesToTime(row[5], row[6]).dayOffset,
    durationMin: row[6],
    days: row[7],
    international: row[8],
    distanceKm: dist,
    classes: classesFor(row[8]).map(function (c) {
      return {
        code: c.code,
        name: c.name,
        layout: c.layout,
        coaches: c.coaches,
        berths: c.berths,
        comfort: c.comfort,
        priceUSD: round2(2.5 + dist * c.farePerKm),
      };
    }),
    onBoard: row[8] ? 'Café car, power sockets, Wi-Fi' : 'Pantry service, bedrolls, charging points',
    punctual: intBetween(seededRandom('punc', row[0]), 72, 94),
  };
});

const TRAINS_BY_ID = {};
TRAINS.forEach(function (t) {
  TRAINS_BY_ID[t.id] = t;
});

export function getTrain(id) {
  return TRAINS_BY_ID[id] || null;
}

export function trainsForRoute(fromId, toId) {
  return TRAINS.filter(function (t) {
    return t.from === fromId && t.to === toId;
  });
}

/**
 * Seat map for a train class on a date.
 * Berth layout: 8 coupes of 8 berths (lower/middle/upper + side lower/upper).
 * Chair layout: 11 rows of 5 (2+3).
 */
export function generateSeatMap(trainId, classCode, dateISO) {
  const train = TRAINS_BY_ID[trainId];
  if (!train) return [];
  const cls = train.classes.filter(function (c) {
    return c.code === classCode;
  })[0];
  if (!cls) return [];

  const rng = seededRandom('seats', trainId, classCode, dateISO);
  const coaches = [];
  const letters = 'ABCDEFGHJKLMN';

  for (let c = 0; c < Math.min(cls.coaches, 6); c += 1) {
    const coachId = letters[c];
    const seats = [];
    if (cls.layout === 'berth') {
      const bayCount = 8;
      const types = ['Lower', 'Middle', 'Upper', 'Side Lower', 'Side Upper'];
      for (let b = 0; b < bayCount; b += 1) {
        for (let t = 0; t < (cls.berths >= 6 ? 5 : cls.berths); t += 1) {
          const n = b * 8 + t + 1;
          seats.push({
            id: coachId + '-' + n,
            coach: coachId,
            number: n,
            type: types[t],
            window: t === 0 || t === 3,
            booked: rng() < 0.34,
          });
        }
      }
    } else {
      for (let r = 0; r < 11; r += 1) {
        const positions = ['Window', 'Aisle', 'Aisle', 'Middle', 'Window'];
        for (let p = 0; p < 5; p += 1) {
          const n = r * 5 + p + 1;
          seats.push({
            id: coachId + '-' + n,
            coach: coachId,
            number: n,
            type: positions[p],
            window: p === 0 || p === 4,
            booked: rng() < 0.3,
          });
        }
      }
    }
    coaches.push({ id: coachId, seats: seats });
  }
  return coaches;
}

/* ------------------------------------------------------------------
   Intercity bus inventory + seat layouts (deterministic per route/date).
------------------------------------------------------------------- */

import { CITY_BY_ID } from './cities';
import { seededRandom, intBetween, between, haversineKm, round2, addMinutesToTime } from '../lib/format';

export const OPERATORS = [
  'Starliner',
  'Greenway Express',
  'Swift Wheels',
  'Royal Cruiser',
  'CityLink',
  'Blue Arrow',
  'Voyagr Coach',
];

export const BUS_TYPES = [
  { id: 'seater', name: 'Non-AC Seater', perKm: 0.016, layout: 'seater', comfort: '2+2 seating', amenities: ['water', 'charging'] },
  { id: 'ac_seater', name: 'AC Seater', perKm: 0.024, layout: 'seater', comfort: '2+2 recliners', amenities: ['ac', 'water', 'charging', 'blanket'] },
  { id: 'ac_sleeper', name: 'AC Sleeper', perKm: 0.032, layout: 'sleeper', comfort: '2+1 berths', amenities: ['ac', 'water', 'charging', 'blanket', 'toilet'] },
  { id: 'luxury', name: 'Luxury Sleeper', perKm: 0.045, layout: 'sleeper', comfort: 'private berths', amenities: ['ac', 'water', 'charging', 'blanket', 'toilet', 'snacks', 'wifi'] },
];

// [id, from, to, durationMin]
const ROUTES = [
  ['r1', 'delhi', 'jaipur', 320],
  ['r2', 'mumbai', 'goa', 660],
  ['r3', 'bengaluru', 'chennai', 360],
  ['r4', 'bengaluru', 'goa', 540],
  ['r5', 'jaipur', 'udaipur', 380],
  ['r6', 'chennai', 'kochi', 540],
  ['r7', 'hyderabad', 'bengaluru', 420],
  ['r8', 'mumbai', 'hyderabad', 540],
  ['r9', 'delhi', 'udaipur', 720],
  ['r10', 'kolkata', 'chennai', 960],
  ['r11', 'mumbai', 'jaipur', 840],
  ['r12', 'delhi', 'kolkata', 1200],
  ['r13', 'singapore', 'kualalumpur', 330],
  ['r14', 'london', 'amsterdam', 480],
  ['r15', 'paris', 'amsterdam', 330],
  ['r16', 'bangkok', 'kualalumpur', 780],
];

function buildBusesForRoute(route, dateISO) {
  const rng = seededRandom('buses', route[0], dateISO);
  const from = CITY_BY_ID[route[1]];
  const to = CITY_BY_ID[route[2]];
  const dist = haversineKm(from, to);
  const count = intBetween(rng, 4, 7);
  const list = [];

  for (let i = 0; i < count; i += 1) {
    const operator = OPERATORS[intBetween(rng, 0, OPERATORS.length - 1)];
    const type = BUS_TYPES[intBetween(rng, 0, BUS_TYPES.length - 1)];
    const depHour = 6 + i * (17 / count) + between(rng, -0.5, 0.5);
    const h = Math.floor(depHour);
    const m = Math.floor((depHour - h) * 60);
    const dep = (h < 10 ? '0' + h : String(h)) + ':' + (m < 10 ? '0' + m : String(m));
    const durationMin = Math.round(route[3] * between(rng, 0.92, 1.12));
    const arr = addMinutesToTime(dep, durationMin);
    const priceUSD = round2((3 + dist * type.perKm) * between(rng, 0.88, 1.22));

    list.push({
      id: 'bus-' + route[0] + '-' + dateISO + '-' + i,
      type: 'bus',
      from: route[1],
      to: route[2],
      date: dateISO,
      operator: operator,
      busType: type,
      dep: dep,
      arr: arr.time,
      arrDayOffset: arr.dayOffset,
      durationMin: durationMin,
      distanceKm: dist,
      priceUSD: priceUSD,
      rating: round2(between(rng, 3.6, 4.8)),
      seatsLeft: intBetween(rng, 2, 38),
      boardingPoints: [from.name + ' Central Bus Stand', from.name + ' Inter-city Terminal'],
      droppingPoints: [to.name + ' Central Bus Stand', to.name + ' City Gate'],
    });
  }
  list.sort(function (a, b) {
    return a.priceUSD - b.priceUSD;
  });
  return list;
}

export function generateBuses(fromId, toId, dateISO) {
  const matches = ROUTES.filter(function (r) {
    return r[1] === fromId && r[2] === toId;
  });
  const out = [];
  matches.forEach(function (r) {
    buildBusesForRoute(r, dateISO).forEach(function (b) {
      out.push(b);
    });
  });
  out.sort(function (a, b) {
    return a.priceUSD - b.priceUSD;
  });
  return out;
}

export function getBus(fromId, toId, dateISO, busId) {
  const list = generateBuses(fromId, toId, dateISO);
  for (let i = 0; i < list.length; i += 1) {
    if (list[i].id === busId) return list[i];
  }
  return null;
}

/** Seat layout for a bus on a date. */
export function generateBusSeats(busId, layout, dateISO) {
  const rng = seededRandom('bus-seats', busId, dateISO);
  const seats = [];
  if (layout === 'sleeper') {
    const rows = 11;
    for (let r = 0; r < rows; r += 1) {
      ['L', 'R'].forEach(function (side, sideIdx) {
        ['Lower', 'Upper'].forEach(function (tier, tierIdx) {
          seats.push({
            id: 'S' + (r + 1) + side + tier.charAt(0),
            row: r + 1,
            side: side === 'L' ? 'Single side' : 'Double side',
            type: tier,
            window: sideIdx === 0 || tierIdx === 0,
            booked: rng() < 0.32,
          });
        });
      });
    }
  } else {
    const rows = 11;
    for (let r = 0; r < rows; r += 1) {
      const positions = [
        { p: 'L1', t: 'Window' },
        { p: 'L2', t: 'Aisle' },
        { p: 'R1', t: 'Window' },
        { p: 'R2', t: 'Middle' },
        { p: 'R3', t: 'Aisle' },
      ];
      positions.forEach(function (pos) {
        seats.push({
          id: 'S' + (r + 1) + pos.p,
          row: r + 1,
          side: pos.p.charAt(0) === 'L' ? 'Left' : 'Right',
          type: pos.t,
          window: pos.t === 'Window',
          booked: rng() < 0.28,
        });
      });
    }
  }
  return seats;
}

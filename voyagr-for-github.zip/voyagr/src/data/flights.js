/* ------------------------------------------------------------------
   Flight inventory engine.
   Flights are generated deterministically from (from, to, date) so the
   same search always returns the same results — like a real GDS feed.
------------------------------------------------------------------- */

import { CITY_BY_ID, CITIES } from './cities';
import {
  seededRandom,
  intBetween,
  between,
  haversineKm,
  addMinutesToTime,
  round2,
} from '../lib/format';

export const AIRLINES = [
  { code: 'AN', name: 'Aurora Air', color: '#e8613c' },
  { code: 'ZP', name: 'Zephyr Airways', color: '#2f6fed' },
  { code: 'LT', name: 'Lotus Air', color: '#c2185b' },
  { code: 'SM', name: 'Summit Airlines', color: '#0f8a6a' },
  { code: 'NV', name: 'Nova Wings', color: '#6b4fbb' },
  { code: 'PC', name: 'Pacific Crest', color: '#0891b2' },
  { code: 'EM', name: 'Ember Jet', color: '#d97706' },
  { code: 'KT', name: 'Kite Air', color: '#e11d48' },
];

const AIRCRAFT_SHORT = ['Airbus A320neo', 'Boeing 737 MAX', 'Embraer E195', 'Airbus A220'];
const AIRCRAFT_LONG = ['Boeing 787-9', 'Airbus A350-900', 'Boeing 777-300ER', 'Airbus A330neo'];

export function routeDistanceKm(fromId, toId) {
  const a = CITY_BY_ID[fromId];
  const b = CITY_BY_ID[toId];
  if (!a || !b) return 0;
  return haversineKm(a, b);
}

function buildFares(rng, base, stops) {
  const refundEco = rng() > 0.55;
  return {
    economy: {
      code: 'economy',
      label: 'Economy',
      priceUSD: round2(base),
      cabinBags: '7 kg',
      checkedBags: stops > 0 ? '20 kg' : '15 kg',
      seatSelection: rng() > 0.5 ? 'Free standard seats' : 'Paid preferred seats',
      refundable: refundEco,
      changeable: true,
      meals: 'Complimentary snack',
    },
    premium: {
      code: 'premium',
      label: 'Premium',
      priceUSD: round2(base * 1.58),
      cabinBags: '10 kg',
      checkedBags: '25 kg',
      seatSelection: 'Free extra-legroom seats',
      refundable: true,
      changeable: true,
      meals: 'Hot meal & beverages',
    },
    business: {
      code: 'business',
      label: 'Business',
      priceUSD: round2(base * 2.92),
      cabinBags: '12 kg',
      checkedBags: '40 kg',
      seatSelection: 'Lie-flat seats',
      refundable: true,
      changeable: true,
      meals: 'Multi-course dining & lounge',
    },
  };
}

/** Deterministic flight list for a route + date. */
export function generateFlights(fromId, toId, dateISO) {
  const from = CITY_BY_ID[fromId];
  const to = CITY_BY_ID[toId];
  if (!from || !to || fromId === toId) return [];

  const dist = haversineKm(from, to);
  const rng = seededRandom('flights', fromId, toId, dateISO);
  const count = intBetween(rng, 7, 11);
  const longHaul = dist > 3500;
  const list = [];

  for (let i = 0; i < count; i += 1) {
    const airline = AIRLINES[(intBetween(rng, 0, AIRLINES.length - 1) + i) % AIRLINES.length];
    const flightNo = airline.code + ' ' + String(intBetween(rng, 101, 989));

    // Departure time spread across the day
    const depHourRaw = 5 + i * (16 / count) + between(rng, -0.4, 0.6);
    const depHour = Math.floor(depHourRaw);
    const depMin = Math.floor((depHourRaw - depHour) * 60);
    const dep =
      (depHour < 10 ? '0' + depHour : String(depHour)) +
      ':' +
      (depMin < 10 ? '0' + depMin : String(depMin));

    // Stops
    let stops = 0;
    if (longHaul) stops = rng() > 0.62 ? 1 : 0;
    else if (dist > 1400) stops = rng() > 0.78 ? 1 : 0;
    if (rng() > 0.94) stops += 1;

    // Via points — prefer hubs that are roughly on the way (no Delhi→Goa via Maldives)
    const via = [];
    for (let s = 0; s < stops; s += 1) {
      const base = CITIES.filter(function (c) {
        return c.id !== fromId && c.id !== toId && via.indexOf(c.id) < 0;
      });
      const corridor = base.filter(function (c) {
        const detour = haversineKm(from, c) + haversineKm(c, to);
        return detour < dist * 1.8;
      });
      const pool = corridor.length ? corridor : base;
      via.push(pool[intBetween(rng, 0, pool.length - 1)].id);
    }

    const durationMin = Math.round(55 + dist / 11.5 + stops * between(rng, 50, 95));
    const arr = addMinutesToTime(dep, durationMin);

    // Pricing
    const jitter = between(rng, 0.8, 1.3);
    const depHourNum = depHour + depMin / 60;
    let timeFactor = 1;
    if (depHourNum < 7) timeFactor = 0.9;
    else if (depHourNum > 21) timeFactor = 0.88;
    else if (depHourNum >= 9 && depHourNum <= 17) timeFactor = 1.08;
    const stopsFactor = 1 - 0.07 * stops;
    const weekendish = rng() > 0.7 ? 1.06 : 1;
    const base = (18 + dist * 0.072) * jitter * timeFactor * stopsFactor * weekendish;

    const seatsLeft = intBetween(rng, 2, 42);
    const co2 = Math.round((dist * (0.095 + rng() * 0.03)) / (1 + 0.12 * (longHaul ? 1 : 0)));

    list.push({
      id: fromId + '-' + toId + '-' + dateISO + '-f' + i,
      type: 'flight',
      from: fromId,
      to: toId,
      date: dateISO,
      airline: airline,
      flightNo: flightNo,
      dep: dep,
      arr: arr.time,
      arrDayOffset: arr.dayOffset,
      durationMin: durationMin,
      stops: stops,
      via: via,
      aircraft: (longHaul ? AIRCRAFT_LONG : AIRCRAFT_SHORT)[intBetween(rng, 0, 3)],
      seatsLeft: seatsLeft,
      onTime: intBetween(rng, 68, 96),
      co2Kg: co2,
      distanceKm: dist,
      fares: buildFares(rng, base, stops),
      // convenience: cheapest fare
      priceUSD: round2(base),
    });
  }

  list.sort(function (a, b) {
    return a.priceUSD - b.priceUSD;
  });
  return list;
}

export function getFlight(fromId, toId, dateISO, flightId) {
  const list = generateFlights(fromId, toId, dateISO);
  for (let i = 0; i < list.length; i += 1) {
    if (list[i].id === flightId) return list[i];
  }
  return null;
}

export function flightAirlines(list) {
  const seen = {};
  const out = [];
  list.forEach(function (f) {
    if (!seen[f.airline.code]) {
      seen[f.airline.code] = true;
      out.push(f.airline);
    }
  });
  return out;
}

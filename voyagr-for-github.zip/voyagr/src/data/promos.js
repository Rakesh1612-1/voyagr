/* ------------------------------------------------------------------
   Promo codes & pricing helpers shared by every booking flow.
------------------------------------------------------------------- */

export const PROMOS = [
  { code: 'VOYAGR10', kind: 'percent', value: 10, maxUSD: 45, minUSD: 0, services: 'all', label: '10% off (up to $45)' },
  { code: 'FLY5', kind: 'percent', value: 5, maxUSD: 30, minUSD: 0, services: ['flight'], label: '5% off flights (up to $30)' },
  { code: 'STAY15', kind: 'percent', value: 15, maxUSD: 70, minUSD: 60, services: ['hotel'], label: '15% off stays over $60' },
  { code: 'RIDE2', kind: 'flat', value: 2.5, maxUSD: 2.5, minUSD: 0, services: ['ride'], label: '$2.50 off any ride' },
  { code: 'FEAST20', kind: 'percent', value: 20, maxUSD: 15, minUSD: 0, services: ['cafe'], label: '20% off café tables (up to $15)' },
  { code: 'RAIL10', kind: 'percent', value: 10, maxUSD: 20, minUSD: 0, services: ['train', 'bus'], label: '10% off rail & bus (up to $20)' },
  { code: 'WANDER25', kind: 'percent', value: 25, maxUSD: 60, minUSD: 150, services: ['experience'], label: '25% off experiences over $150' },
  { code: 'ROADTRIP', kind: 'percent', value: 12, maxUSD: 50, minUSD: 80, services: ['car'], label: '12% off car rentals over $80' },
];

/**
 * @returns {{ok: boolean, message: string, discountUSD: number, promo: object|null}}
 */
export function applyPromo(code, service, subtotalUSD) {
  const input = String(code || '').trim().toUpperCase();
  if (!input) {
    return { ok: false, message: 'Enter a promo code', discountUSD: 0, promo: null };
  }
  let promo = null;
  for (let i = 0; i < PROMOS.length; i += 1) {
    if (PROMOS[i].code === input) promo = PROMOS[i];
  }
  if (!promo) {
    return { ok: false, message: 'That code isn’t valid', discountUSD: 0, promo: null };
  }
  const applies =
    promo.services === 'all' ||
    (Array.isArray(promo.services) && promo.services.indexOf(service) >= 0);
  if (!applies) {
    return { ok: false, message: 'Not valid for ' + service + ' bookings', discountUSD: 0, promo: null };
  }
  if (subtotalUSD < promo.minUSD) {
    return {
      ok: false,
      message: 'Needs a subtotal of at least $' + promo.minUSD,
      discountUSD: 0,
      promo: null,
    };
  }
  let discount = promo.kind === 'flat' ? promo.value : (subtotalUSD * promo.value) / 100;
  if (promo.maxUSD) discount = Math.min(discount, promo.maxUSD);
  discount = Math.min(discount, subtotalUSD);
  return {
    ok: true,
    message: promo.label + ' applied',
    discountUSD: Math.round(discount * 100) / 100,
    promo: promo,
  };
}

/** Tax + fee schedule per service (percent of base + flat platform fee in USD). */
export const TAX_SCHEDULE = {
  hotel: { pct: 0.12, fee: 3.5, label: 'Taxes & city fees' },
  flight: { pct: 0.18, fee: 2.5, label: 'Taxes & carrier charges' },
  train: { pct: 0.05, fee: 1.5, label: 'Reservation & service fee' },
  bus: { pct: 0.08, fee: 1.2, label: 'Taxes & booking fee' },
  cafe: { pct: 0.08, fee: 1.5, label: 'Service charge & taxes' },
  car: { pct: 0.1, fee: 4.5, label: 'Insurance & taxes' },
  ride: { pct: 0.06, fee: 0.8, label: 'Tolls & platform fee' },
  experience: { pct: 0.1, fee: 2.0, label: 'Taxes & booking fee' },
};

export function priceBreakdown(service, baseUSD, quantity, discountUSD) {
  const sched = TAX_SCHEDULE[service] || TAX_SCHEDULE.hotel;
  const qty = quantity || 1;
  const base = Math.round(baseUSD * qty * 100) / 100;
  const discount = Math.min(discountUSD || 0, base);
  const taxable = base - discount;
  const taxes = Math.round(taxable * sched.pct * 100) / 100;
  const fees = sched.fee;
  const total = Math.round((taxable + taxes + fees) * 100) / 100;
  return {
    baseUSD: base,
    quantity: qty,
    discountUSD: Math.round(discount * 100) / 100,
    taxesUSD: taxes,
    feesUSD: fees,
    totalUSD: total,
    taxLabel: sched.label,
  };
}

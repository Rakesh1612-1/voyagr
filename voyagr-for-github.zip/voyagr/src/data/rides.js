/* ------------------------------------------------------------------
   In-city rides: vehicle types, landmarks per city, fare quotes.
------------------------------------------------------------------- */

import { CITY_BY_ID } from './cities';
import { seededRandom, intBetween, between, round2 } from '../lib/format';

export const VEHICLE_TYPES = [
  { id: 'bike', name: 'Bike Taxi', seats: 1, baseFare: 0.8, perKm: 0.28, perMin: 0.02, eta: 3, note: 'Beat the traffic', markets: ['India', 'Thailand', 'Indonesia', 'Malaysia'] },
  { id: 'auto', name: 'Auto Rickshaw', seats: 3, baseFare: 1.0, perKm: 0.32, perMin: 0.025, eta: 4, note: 'Three wheels, zero fuss', markets: ['India'] },
  { id: 'hatch', name: 'Hatchback', seats: 4, baseFare: 1.6, perKm: 0.55, perMin: 0.04, eta: 5, note: 'Everyday rides at low fares' },
  { id: 'sedan', name: 'Sedan', seats: 4, baseFare: 2.2, perKm: 0.72, perMin: 0.05, eta: 6, note: 'Extra comfort & boot space' },
  { id: 'suv', name: 'SUV', seats: 6, baseFare: 3.2, perKm: 0.95, perMin: 0.06, eta: 8, note: 'Room for the whole crew' },
  { id: 'premium', name: 'Premium', seats: 4, baseFare: 5.5, perKm: 1.5, perMin: 0.08, eta: 10, note: 'Top-rated pro drivers' },
  { id: 'van', name: 'XL Van', seats: 7, baseFare: 4.4, perKm: 1.15, perMin: 0.07, eta: 12, note: 'Groups & luggage' },
];

const AREAS_OVERRIDE = {
  delhi: ['Indira Gandhi Airport', 'Connaught Place', 'India Gate', 'Hauz Khas Village', 'Cyber City Gurugram', 'Chandni Chowk'],
  mumbai: ['Mumbai Airport', 'Bandra Kurla Complex', 'Marine Drive', 'Juhu Beach', 'Lower Parel', 'Colaba Causeway'],
  bengaluru: ['Kempegowda Airport', 'Indiranagar', 'MG Road', 'Whitefield Tech Park', 'Koramangala', 'Cubbon Park'],
  goa: ['Goa Airport', 'Calangute Beach', 'Anjuna Flea Market', 'Panjim Market', 'Dudhsagar Falls Road', 'Palolem Beach'],
  jaipur: ['Jaipur Airport', 'Hawa Mahal', 'Amber Fort', 'City Palace', 'Johari Bazaar', 'Nahargarh Fort Road'],
  udaipur: ['Udaipur Airport', 'Lake Pichola', 'City Palace', 'Fateh Sagar', 'Ambrai Ghat', 'Sajjangarh Road'],
  chennai: ['Chennai Airport', 'Marina Beach', 'Mylapore Temple', 'T. Nagar', 'IT Expressway', 'Besant Nagar'],
  kolkata: ['Kolkata Airport', 'Park Street', 'Victoria Memorial', 'Howrah Bridge', 'Salt Lake', 'New Market'],
  hyderabad: ['Hyderabad Airport', 'Charminar', 'Hitech City', 'Banjara Hills', 'Golconda Fort Road', 'Hussain Sagar'],
  kochi: ['Kochi Airport', 'Fort Kochi', 'Marine Drive', 'Lulu Mall', 'Vyttila Hub', 'Kumarakom Road'],
  dubai: ['Dubai International Airport', 'Burj Khalifa', 'Dubai Marina', 'Palm Jumeirah', 'Gold Souk', 'Global Village'],
  singapore: ['Changi Airport', 'Marina Bay Sands', 'Orchard Road', 'Sentosa', 'Gardens by the Bay', 'Clarke Quay'],
  bangkok: ['Suvarnabhumi Airport', 'Grand Palace', 'Sukhumvit', 'Chatuchak Market', 'Khao San Road', 'ICONSIAM'],
  bali: ['Ngurah Rai Airport', 'Ubud Centre', 'Seminyak Beach', 'Uluwatu Temple', 'Canggu', 'Tegallalang'],
  tokyo: ['Haneda Airport', 'Shibuya Crossing', 'Tokyo Skytree', 'Shinjuku', 'Asakusa', 'Tsukiji Outer Market'],
  london: ['Heathrow Airport', 'Tower Bridge', 'Covent Garden', 'Buckingham Palace', 'Camden Market', 'Canary Wharf'],
  paris: ['Charles de Gaulle', 'Eiffel Tower', 'Louvre', 'Montmartre', 'Champs-Élysées', 'Le Marais'],
  newyork: ['JFK Airport', 'Times Square', 'Central Park', 'Brooklyn Bridge', 'SoHo', 'Empire State Building'],
  rome: ['Fiumicino Airport', 'Colosseum', 'Trastevere', 'Vatican City', 'Trevi Fountain', 'Termini'],
  istanbul: ['Istanbul Airport', 'Sultanahmet', 'Grand Bazaar', 'Taksim Square', 'Bosphorus Bridge', 'Kadıköy'],
  sydney: ['Sydney Airport', 'Opera House', 'Bondi Beach', 'Harbour Bridge', 'Circular Quay', 'Darling Harbour'],
};

export function cityAreas(cityId) {
  const override = AREAS_OVERRIDE[cityId];
  const city = CITY_BY_ID[cityId];
  const names = override || [
    (city ? city.name : 'City') + ' Airport',
    'City Centre',
    'Old Town',
    'Central Station',
    'Market District',
    city && city.vibe.indexOf('beach') >= 0 ? 'Beach Promenade' : 'Riverside Promenade',
  ];
  return names.map(function (name, i) {
    return { id: cityId + '-a' + i, name: name, index: i };
  });
}

const MARKET_FACTOR = {
  India: 0.42,
  UAE: 0.85,
  Singapore: 1.1,
  Thailand: 0.55,
  Indonesia: 0.5,
  Japan: 1.15,
  Malaysia: 0.6,
  Maldives: 0.9,
  'Türkiye': 0.6,
  UK: 1.25,
  France: 1.2,
  Italy: 1.1,
  Netherlands: 1.2,
  USA: 1.3,
  Australia: 1.25,
};

export function vehiclesForCity(cityId) {
  const city = CITY_BY_ID[cityId];
  const country = city ? city.country : 'USA';
  return VEHICLE_TYPES.filter(function (v) {
    return !v.markets || v.markets.indexOf(country) >= 0;
  });
}

export function distanceBetweenAreas(cityId, fromIdx, toIdx) {
  if (fromIdx === toIdx) return 0;
  const rng = seededRandom('ride-dist', cityId, Math.min(fromIdx, toIdx), Math.max(fromIdx, toIdx));
  return round2(between(rng, 2.6, 21.5));
}

const DRIVER_NAMES = ['Aarav', 'Meera', 'Rahul', 'Priya', 'Daniel', 'Sofia', 'Kenji', 'Amira', 'Lucas', 'Elena', 'Jamal', 'Sara', 'Vikram', 'Chen', 'Omar', 'Ines'];

export function getRideQuote(cityId, fromIdx, toIdx, vehicleId, when) {
  const city = CITY_BY_ID[cityId];
  const vehicles = vehiclesForCity(cityId);
  let vehicle = null;
  for (let i = 0; i < vehicles.length; i += 1) {
    if (vehicles[i].id === vehicleId) vehicle = vehicles[i];
  }
  if (!vehicle) vehicle = vehicles[0];
  if (!vehicle || fromIdx === toIdx) return null;

  const dist = distanceBetweenAreas(cityId, fromIdx, toIdx);
  const rng = seededRandom('ride-quote', cityId, fromIdx, toIdx, vehicleId, when || 'now');
  const durationMin = Math.round(dist * between(rng, 1.9, 3.4) + 6);
  const factor = city ? MARKET_FACTOR[city.country] || 1 : 1;
  const surge = rng() > 0.82 ? round2(between(rng, 1.15, 1.45)) : 1;
  const waitMin = vehicle.eta + intBetween(rng, 0, 5);

  const base = round2(vehicle.baseFare * factor);
  const distanceFee = round2(dist * vehicle.perKm * factor);
  const timeFee = round2(durationMin * vehicle.perMin * factor);
  const subtotal = round2(base + distanceFee + timeFee);
  const total = round2(subtotal * surge);

  const areas = cityAreas(cityId);
  return {
    id: 'ride-' + cityId + '-' + fromIdx + '-' + toIdx + '-' + vehicleId + '-' + (when || 'now'),
    type: 'ride',
    city: cityId,
    vehicle: vehicle,
    from: areas[fromIdx],
    to: areas[toIdx],
    distanceKm: dist,
    durationMin: durationMin,
    etaMin: waitMin,
    surge: surge,
    when: when || 'now',
    driverName: DRIVER_NAMES[intBetween(rng, 0, DRIVER_NAMES.length - 1)],
    driverRating: round2(between(rng, 4.5, 4.99)),
    vehicleNo: String.fromCharCode(65 + intBetween(rng, 0, 25)) + String.fromCharCode(65 + intBetween(rng, 0, 25)) + ' ' + intBetween(rng, 1000, 9999) + ' ' + String.fromCharCode(65 + intBetween(rng, 0, 25)),
    fare: {
      baseUSD: base,
      distanceUSD: distanceFee,
      timeUSD: timeFee,
      surgeMultiplier: surge,
      totalUSD: total,
    },
    priceUSD: total,
  };
}

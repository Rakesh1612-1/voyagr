/* ------------------------------------------------------------------
   Tours & experiences inventory.
------------------------------------------------------------------- */

// [id, title, city, category, hours, maxGroup, priceUSD, rating, reviews, level, includes, blurb]
const RAW = [
  ['exp-foodwalk-delhi', 'Old Delhi Street Food Walk', 'delhi', 'food', 4, 12, 34, 4.8, 2140, 'easy', 'guide,tastings,water,hotel-pickup', 'Follow a local storyteller through Chandni Chowk’s legendary parathe wali gali, jalebi stalls and spice markets — eight tastings included.'],
  ['exp-heritage-jaipur', 'Amber Fort & Pink City Heritage Tour', 'jaipur', 'culture', 5, 15, 39, 4.7, 1820, 'easy', 'guide,entry,transport,lunch', 'Sunrise at Amber Fort, fresco hunting in Shekhawati havelis and a royal thali lunch.'],
  ['exp-bollywood-mumbai', 'Mumbai Film City & Bollywood Night', 'mumbai', 'culture', 4, 20, 42, 4.4, 1210, 'easy', 'guide,entry,transport,snacks', 'Studio floors, costume rooms and a live dance finale — plus street-food bites at sunset.'],
  ['exp-segway-bengaluru', 'Bengaluru Brewery & Art Crawl', 'bengaluru', 'nightlife', 3.5, 14, 28, 4.5, 860, 'easy', 'guide,tastings', 'Three craft breweries, one street-art lane and the city’s best filter-coffee nightcap.'],
  ['exp-beach-goa', 'Goa Sunset Catamaran Cruise', 'goa', 'water', 3, 24, 46, 4.7, 2410, 'easy', 'boat,drinks,music,snacks', 'Sail into the Arabian Sea sunset with live music, Goan tapas and a dolphin-spotting detour.'],
  ['exp-surfschool-bali', 'Seminyak Surf Lesson', 'bali', 'adventure', 2.5, 8, 38, 4.8, 3120, 'moderate', 'board,instructor,photos', 'Beginner-friendly waves, ISA-certified coaches and photos of your first pop-up.'],
  ['exp-ubud-rice', 'Tegallalang Rice Terrace Trek & Coffee', 'bali', 'nature', 4, 12, 32, 4.7, 1980, 'moderate', 'guide,meals,water,transport', 'Sunrise trek through the terraces, a swing over the valley and a luwak coffee tasting.'],
  ['exp-hamam-istanbul', 'Ottoman Hamam & Bazaar Evening', 'istanbul', 'wellness', 3, 10, 58, 4.6, 1420, 'easy', 'hamam,guide,tea', 'Marble steam, traditional kese scrub and a guided Grand Bazaar wander with Turkish delight.'],
  ['exp-sushi-tokyo', 'Tokyo Sushi Masterclass & Market Tour', 'tokyo', 'food', 3.5, 8, 89, 4.9, 2210, 'easy', 'guide,ingredients,meal', 'Tsukiji outer-market sourcing, knife skills with a sushi master and a chef’s omakase lunch.'],
  ['exp-tea-paris', 'Paris Pâtisserie & Chocolate Walk', 'paris', 'food', 3.5, 10, 72, 4.8, 1890, 'easy', 'guide,tastings', 'Croissant-by-croissant through Saint-Germain: six tastings, one pastry kitchen visit.'],
  ['exp-eiffel-picnic', 'Seine Sunset Picnic & Hidden Paris', 'paris', 'culture', 2.5, 16, 34, 4.6, 2340, 'easy', 'picnic,guide,wine', 'Cheese, baguette and Côtes du Rhône on the Champ de Mars, with secret courtyards en route.'],
  ['exp-london-pub', 'London Historical Pub Crawl', 'london', 'nightlife', 3.5, 18, 39, 4.5, 1610, 'easy', 'guide,drinks', 'Four centuries of stories across four riverside pubs, ales included.'],
  ['exp-bridge-climb-sydney', 'Sydney Harbour Bridge Climb at Dawn', 'sydney', 'adventure', 3, 12, 148, 4.9, 1240, 'moderate', 'guide,gear,photos', 'Summit the arch as the sun rises over the Opera House — unforgettable.'],
  ['exp-venice-rome', 'Rome Gladiator & Colosseum Night', 'rome', 'culture', 2.5, 20, 55, 4.7, 2680, 'easy', 'guide,entry', 'After-dark Colosseum access with a historian storyteller and underground chambers.'],
  ['exp-amsterdam-canal', 'Amsterdam Canal & Cheese Cruise', 'amsterdam', 'water', 1.5, 24, 29, 4.5, 3210, 'easy', 'boat,cheese,drinks', 'Golden-age canals, Dutch cheese pairings and a glass of local bubbles.'],
  ['exp-dubai-desert', 'Dubai Desert Safari & Bedouin Dinner', 'dubai', 'adventure', 6, 26, 78, 4.7, 5210, 'easy', '4x4,dinner,shows,transport', 'Dune bashing, camel rides, falconry and a lantern-lit Bedouin camp feast.'],
  ['exp-singapore-food', 'Singapore Hawker Heritage Crawl', 'singapore', 'food', 3, 12, 45, 4.8, 2890, 'easy', 'guide,tastings', 'Chilli crab, kaya toast and chicken rice across three legendary hawker centres.'],
  ['exp-bangkok-market', 'Bangkok Floating Market & Temples', 'bangkok', 'culture', 5, 14, 36, 4.5, 2120, 'easy', 'boat,guide,meals,transport', 'Long-tail boats at Damnoen Saduak, Wat Arun at golden hour and mango sticky rice.'],
  ['exp-kochi-backwater', 'Kerala Backwaters Houseboat Day', 'kochi', 'nature', 7, 16, 62, 4.8, 1710, 'easy', 'boat,lunch,guide', 'Palm-fringed canals, toddy-shop lunch and village walks on Vembanad lake.'],
  ['exp-udaipur-lake', 'Udaipur Lake Palace Sunset Boat', 'udaipur', 'water', 2, 18, 32, 4.7, 1420, 'easy', 'boat,guide,drinks', 'Glide past ghats and palaces as the city turns gold — sparkling wine included.'],
  ['exp-sf-wine', 'Napa Valley Wine & Vineyard Tour', 'sanfrancisco', 'food', 7, 14, 128, 4.7, 980, 'easy', 'transport,tastings,lunch', 'Three boutique wineries, a chef’s lunch and sommelier storytelling all day.'],
  ['exp-nyc-brooklyn', 'Brooklyn Bridge & DUMBO Photo Walk', 'newyork', 'culture', 3, 12, 42, 4.6, 2040, 'moderate', 'guide,photos', 'Golden-hour skyline shots from the bridge, DUMBO’s cobbles and a pizza stop.'],
];

const CATEGORIES = [
  { id: 'food', label: 'Food & drink' },
  { id: 'culture', label: 'Culture & history' },
  { id: 'nature', label: 'Nature & scenery' },
  { id: 'adventure', label: 'Adventure' },
  { id: 'water', label: 'On the water' },
  { id: 'wellness', label: 'Wellness' },
  { id: 'nightlife', label: 'Nightlife' },
];

const INCLUDE_LABELS = {
  guide: 'Local guide',
  tastings: 'All tastings',
  water: 'Bottled water',
  transport: 'Hotel transfers',
  entry: 'Entry tickets',
  lunch: 'Lunch included',
  meals: 'Meals included',
  drinks: 'Welcome drinks',
  boat: 'Boat ride',
  music: 'Live music',
  snacks: 'Snacks',
  board: 'Surfboard & rash guard',
  instructor: 'Certified instructor',
  photos: 'Free photos',
  hamam: 'Traditional hamam',
  tea: 'Turkish tea service',
  ingredients: 'All ingredients',
  meal: 'Sit-down meal',
  picnic: 'Gourmet picnic',
  wine: 'Wine pairing',
  gear: 'Safety gear',
  '4x4': '4×4 dune bashing',
  dinner: 'BBQ dinner',
  shows: 'Live shows',
  cheese: 'Cheese board',
  tickets: 'Tickets',
  bike: 'Bike & helmet',
  'hotel-pickup': 'Hotel pickup',
};

export const EXPERIENCES = RAW.map(function (row) {
  return {
    id: row[0],
    type: 'experience',
    title: row[1],
    city: row[2],
    category: row[3],
    hours: row[4],
    maxGroup: row[5],
    priceUSD: row[6],
    rating: row[7],
    reviews: row[8],
    level: row[9],
    includes: row[10].split(',').map(function (k) {
      return { key: k, label: INCLUDE_LABELS[k] || k };
    }),
    blurb: row[11],
    image: row[3] === 'water' || row[3] === 'nature' ? '/img/experience.jpg' : row[3] === 'food' ? '/img/cafe.jpg' : '/img/hero.jpg',
    slots: row[4] > 4 ? ['07:30', '08:30', '09:00', '13:30'] : ['07:30', '09:00', '11:00', '14:00', '16:30', '18:30'],
    freeCancellation: true,
    instantConfirmation: true,
    languages: ['English', 'Local host'],
  };
});

const BY_ID = {};
EXPERIENCES.forEach(function (e) {
  BY_ID[e.id] = e;
});

export function getExperience(id) {
  return BY_ID[id] || null;
}

export function experiencesByCity(cityId) {
  return EXPERIENCES.filter(function (e) {
    return e.city === cityId;
  });
}

export const EXPERIENCE_CATEGORIES = CATEGORIES;

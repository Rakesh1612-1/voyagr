/* ------------------------------------------------------------------
   Car rental fleet + pricing.
------------------------------------------------------------------- */

import { seededRandom, intBetween, between, round2 } from '../lib/format';
import { CITY_BY_ID } from './cities';

// [id, brand, model, category, seats, bags, transmission, fuel, basePriceUSD, rating, features]
const FLEET = [
  ['volt-hatch', 'Volt', 'Spark Hatch', 'hatchback', 4, 2, 'Manual', 'Petrol', 28, 4.2, 'bluetooth,ac,usb'],
  ['metro-mini', 'Metro', 'Mini Go', 'hatchback', 4, 1, 'Manual', 'Petrol', 22, 4.0, 'ac,usb'],
  ['comet-sedan', 'Comet', 'Aria Sedan', 'sedan', 5, 3, 'Automatic', 'Petrol', 42, 4.5, 'bluetooth,ac,usb,cruise'],
  ['comet-sedan-d', 'Comet', 'Aria Sedan Diesel', 'sedan', 5, 3, 'Automatic', 'Diesel', 46, 4.4, 'bluetooth,ac,usb,cruise'],
  ['ridge-suv', 'Ridge', 'Trail SUV', 'suv', 5, 4, 'Automatic', 'Diesel', 62, 4.6, 'bluetooth,ac,usb,cruise,4wd'],
  ['ridge-suv-xl', 'Ridge', 'Summit SUV XL', 'suv', 7, 5, 'Automatic', 'Diesel', 78, 4.5, 'bluetooth,ac,usb,cruise,4wd,tv'],
  ['ember-luxe', 'Ember', 'Regent Luxury', 'luxury', 5, 4, 'Automatic', 'Petrol', 128, 4.8, 'leather,bluetooth,ac,usb,cruise,chauffeur-option'],
  ['voyager-van', 'Voyager', 'Family Van', 'van', 8, 6, 'Automatic', 'Diesel', 88, 4.4, 'bluetooth,ac,usb,tv,sliding-doors'],
];

// Multiplier applied to daily rates per market.
const MARKET_FACTOR = {
  India: 0.62,
  UAE: 0.95,
  Singapore: 1.15,
  Thailand: 0.7,
  Indonesia: 0.68,
  Japan: 1.1,
  Malaysia: 0.72,
  Maldives: 1.25,
  'Türkiye': 0.75,
  UK: 1.2,
  France: 1.15,
  Italy: 1.05,
  Netherlands: 1.12,
  USA: 1.18,
  Australia: 1.14,
};

export const CAR_CATEGORIES = [
  { id: 'hatchback', label: 'Hatchback', hint: 'City-friendly & efficient' },
  { id: 'sedan', label: 'Sedan', hint: 'Comfort for highway runs' },
  { id: 'suv', label: 'SUV', hint: 'Space for family & bags' },
  { id: 'luxury', label: 'Luxury', hint: 'Arrive in style' },
  { id: 'van', label: 'Van', hint: 'Groups of 7–8' },
];

export function getCarOptions(cityId, days) {
  const city = CITY_BY_ID[cityId];
  const rng = seededRandom('cars', cityId);
  const factor = city ? MARKET_FACTOR[city.country] || 1 : 1;
  const nDays = Math.max(1, days || 1);

  return FLEET.map(function (row) {
    const pricePerDay = round2(row[8] * factor * between(rng, 0.92, 1.12));
    return {
      id: row[0] + '-' + cityId,
      type: 'car',
      modelId: row[0],
      brand: row[1],
      model: row[2],
      name: row[1] + ' ' + row[2],
      category: row[3],
      seats: row[4],
      bags: row[5],
      transmission: row[6],
      fuel: row[7],
      pricePerDayUSD: pricePerDay,
      totalPriceUSD: round2(pricePerDay * nDays),
      days: nDays,
      rating: row[9],
      features: row[10].split(','),
      depositUSD: round2(pricePerDay * 8),
      unlimitedKm: row[3] === 'luxury' || rng() > 0.45,
      mileageKm: row[3] === 'luxury' ? 'Unlimited' : intBetween(rng, 150, 300) + ' km/day',
      fuelPolicy: 'Full to full',
      freeCancellation: rng() > 0.35,
      supplier: ['DriveEasy', 'City Wheels', 'Prime Rentals', 'AutoNest'][intBetween(rng, 0, 3)],
      minAge: row[3] === 'luxury' ? 25 : 21,
      image: '/img/road.jpg',
      pickupNote: city ? 'Pick up at ' + city.name + ' Airport or city locations' : 'Airport or city pickup',
    };
  });
}

export function getCar(carId, cityId, days) {
  const list = getCarOptions(cityId, days);
  for (let i = 0; i < list.length; i += 1) {
    if (list[i].id === carId) return list[i];
  }
  return null;
}

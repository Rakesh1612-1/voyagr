/* ------------------------------------------------------------------
   Café reservations: venues, deterministic menus, time slots.
------------------------------------------------------------------- */

import { seededRandom, intBetween, between, round2 } from '../lib/format';

const MENU_TEMPLATE = [
  { id: 'flat-white', name: 'Flat White', cat: 'Coffee', priceUSD: 3.8, tag: 'House favourite' },
  { id: 'cortado', name: 'Cortado', cat: 'Coffee', priceUSD: 3.4 },
  { id: 'cold-brew', name: 'Slow Cold Brew', cat: 'Coffee', priceUSD: 4.2, tag: 'Signature' },
  { id: 'filter', name: 'Single-origin Filter', cat: 'Coffee', priceUSD: 4.6, tag: 'Roaster pick' },
  { id: 'matcha', name: 'Ceremonial Matcha Latte', cat: 'Tea', priceUSD: 4.8 },
  { id: 'chai', name: 'Spiced Masala Chai', cat: 'Tea', priceUSD: 2.9 },
  { id: 'croissant', name: 'Butter Croissant', cat: 'Bakery', priceUSD: 3.2, tag: 'Baked hourly' },
  { id: 'banana-bread', name: 'Walnut Banana Bread', cat: 'Bakery', priceUSD: 3.6 },
  { id: 'avocado-toast', name: 'Avocado Toast & Poached Eggs', cat: 'Brunch', priceUSD: 9.4, tag: 'Bestseller' },
  { id: 'shakshuka', name: 'Shakshuka Skillet', cat: 'Brunch', priceUSD: 10.2 },
  { id: 'pancakes', name: 'Buttermilk Pancakes', cat: 'Brunch', priceUSD: 8.6 },
  { id: 'club-sandwich', name: 'Triple Club Sandwich', cat: 'All-day', priceUSD: 8.9 },
  { id: 'grain-bowl', name: 'Roasted Veggie Grain Bowl', cat: 'All-day', priceUSD: 9.8, tag: 'Vegan' },
  { id: 'pasta', name: 'Truffle Mushroom Pasta', cat: 'All-day', priceUSD: 12.4 },
  { id: 'cheesecake', name: 'Basque Cheesecake', cat: 'Dessert', priceUSD: 5.6, tag: 'Signature' },
  { id: 'tiramisu', name: 'Espresso Tiramisu', cat: 'Dessert', priceUSD: 5.9 },
  { id: 'cookie', name: 'Brown Butter Cookie', cat: 'Dessert', priceUSD: 2.8 },
  { id: 'smoothie', name: 'Berry Kefir Smoothie', cat: 'Drinks', priceUSD: 5.2 },
  { id: 'lemonade', name: 'Rosemary Lemonade', cat: 'Drinks', priceUSD: 3.9 },
  { id: 'wine', name: 'Glass of House Wine', cat: 'Drinks', priceUSD: 6.5 },
];

// [id, name, city, area, rating, reviews, priceBand, tags, blurb]
const RAW = [
  ['cafe-ember-delhi', 'Ember & Bean', 'delhi', 'Hauz Khas', 4.6, 1284, 2, 'brunch,cozy,wifi', 'Sunlit corner café with courtyard seating, slow-bar coffee and an all-day brunch menu.'],
  ['cafe-lodi-delhi', 'The Lodi Roastery', 'delhi', 'Lodhi Colony', 4.5, 962, 2, 'coffee,work,quiet', 'A specialty roastery among the art-lined lanes of Lodhi — great single-origins and quiet tables.'],
  ['cafe-marine-mumbai', 'Marine Drive Coffee Co.', 'mumbai', 'Marine Drive', 4.4, 2140, 2, 'sea-view,brunch,trendy', 'Sea-facing brews, brioche breakfasts and the best sunset tables on the Queen’s Necklace.'],
  ['cafe-bandstand-mumbai', 'Bandstand Bakehouse', 'mumbai', 'Bandra West', 4.7, 1876, 3, 'bakery,brunch,pet', 'Sourdough loaves, laminated pastries and a breezy veranda a few steps from the promenade.'],
  ['cafe-cubbon-bengaluru', 'Cubbon Conservatory Café', 'bengaluru', 'Central Bengaluru', 4.6, 2410, 2, 'garden,brunch,family', 'A glasshouse café beside the park — pancakes, pour-overs and plenty of shade.'],
  ['cafe-indira-bengaluru', 'Third Wave Indiranagar', 'bengaluru', 'Indiranagar', 4.5, 3120, 2, 'coffee,trendy,wifi', 'The neighbourhood living room: espresso flights, matcha and laptops everywhere by noon.'],
  ['cafe-anjuna-goa', 'Anjuna Sunset Shack', 'goa', 'Anjuna', 4.5, 1620, 2, 'sea-view,chill,brunch', 'Barefoot tables on the sand, fresh coconut cold brews and live guitar at golden hour.'],
  ['cafe-assagao-goa', 'Assagao Garden Café', 'goa', 'Assagao', 4.7, 1210, 3, 'garden,brunch,quiet', 'A walled garden with mango trees, wood-fired brunch and floral coolers.'],
  ['cafe-pinkcity-jaipur', 'Pink City Chai Room', 'jaipur', 'Old City', 4.4, 890, 1, 'tea,views,local', 'Rooftop chai and kachori breakfasts with a direct line of sight to Hawa Mahal.'],
  ['cafe-marina-chennai', 'Marina Filter House', 'chennai', 'Mylapore', 4.5, 1120, 1, 'local,coffee,quick', 'Traditional filter coffee done seriously, with dosa sandwiches and sea-breeze mornings.'],
  ['cafe-park-kolkata', 'Park Street Poetry Café', 'kolkata', 'Park Street', 4.6, 1440, 2, 'books,cozy,wifi', 'Book-lined walls, live poetry nights and legendary hot chocolate.'],
  ['cafe-hitech-hyderabad', 'HiTech Brew Lab', 'hyderabad', 'Hitech City', 4.3, 980, 2, 'work,wifi,coffee', 'A bright work-friendly café with fast Wi-Fi, pour-over flights and power at every seat.'],
  ['cafe-fort-kochi', 'Fort Kochi Spice Café', 'kochi', 'Fort Kochi', 4.6, 1330, 2, 'views,local,brunch', 'Cinnamon-shaded veranda facing the Chinese nets; banana-leaf breakfasts and Kerala coffee.'],
  ['cafe-dubai-marina', 'Marina Brew Society', 'dubai', 'Dubai Marina', 4.5, 2890, 3, 'luxury,views,trendy', 'Gold-standard espresso on the marina promenade with skyline views and patisserie counters.'],
  ['cafe-orchard-singapore', 'Orchard Tea Atelier', 'singapore', 'Orchard Road', 4.6, 2210, 3, 'tea,elegant,brunch', 'A hushed tea salon with 40 single-estate teas, kaya toast and dainty set menus.'],
  ['cafe-sukhumvit-bangkok', 'Sukhumvit Roast Lab', 'bangkok', 'Sukhumvit', 4.4, 1780, 2, 'coffee,trendy,late', 'Thai single-origins, coconut desserts and a neon-lit late-night counter.'],
  ['cafe-ubud-bali', 'Ubud Jungle Brew', 'bali', 'Ubud', 4.7, 2640, 2, 'nature,brunch,healthy', 'Open-air decks over the rice terraces; smoothie bowls, Bali kintamani coffee and zero rush.'],
  ['cafe-asakusa-tokyo', 'Asakusa Kissaten', 'tokyo', 'Asakusa', 4.8, 1520, 2, 'traditional,quiet,coffee', 'A 1960s kissaten: hand-dripped coffee, thick toast and jazz on vinyl.'],
  ['cafe-marais-paris', 'Le Marais Corner', 'paris', 'Le Marais', 4.5, 3020, 3, 'pastry,romantic,classic', 'Zinc counter, croissants at 7 am and perfect people-watching terraces.'],
  ['cafe-shoreditch-london', 'Shoreditch Grind Room', 'london', 'Shoreditch', 4.4, 2760, 2, 'coffee,trendy,brunch', 'Warehouse café with roastery vibes, all-day plates and a buzzing weekend queue.'],
  ['cafe-jordan-amsterdam', 'Jordaan Canal Café', 'amsterdam', 'Jordaan', 4.6, 1940, 2, 'views,cozy,pastry', 'Canal-side window seats, apple pie à la mode and excellent flat whites.'],
  ['cafe-soho-newyork', 'SoHo Marble Counter', 'newyork', 'SoHo', 4.5, 3480, 3, 'trendy,brunch,classic', 'Marble counters, chopped salads and the downtown cappuccino benchmark.'],
];

export const CAFES = RAW.map(function (row) {
  const rng = seededRandom('cafe', row[0]);
  const menu = MENU_TEMPLATE.map(function (item) {
    return {
      id: item.id,
      name: item.name,
      cat: item.cat,
      tag: item.tag || null,
      priceUSD: round2(item.priceUSD * between(rng, 0.85, 1.25) * (row[6] === 3 ? 1.25 : row[6] === 1 ? 0.8 : 1)),
    };
  });
  return {
    id: row[0],
    type: 'cafe',
    name: row[1],
    city: row[2],
    area: row[3],
    rating: row[4],
    reviews: row[5],
    priceBand: row[6],
    tags: row[7].split(','),
    blurb: row[8],
    menu: menu,
    image: '/img/cafe.jpg',
    priceUSD: round2(8 + row[6] * 6),
    openFrom: '08:00',
    openTo: '23:00',
    slots: ['08:30', '10:00', '11:30', '13:00', '14:30', '16:00', '17:30', '19:00', '20:30', '22:00'],
    seats: intBetween(rng, 24, 90),
  };
});

const CAFES_BY_ID = {};
CAFES.forEach(function (c) {
  CAFES_BY_ID[c.id] = c;
});

export function getCafe(id) {
  return CAFES_BY_ID[id] || null;
}

export function cafesByCity(cityId) {
  return CAFES.filter(function (c) {
    return c.city === cityId;
  });
}

export function cafeMenuCategories(cafe) {
  const cats = [];
  cafe.menu.forEach(function (m) {
    if (cats.indexOf(m.cat) < 0) cats.push(m.cat);
  });
  return cats;
}

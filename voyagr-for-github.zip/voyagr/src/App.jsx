/* ------------------------------------------------------------------
   App root: routing + page chrome.
------------------------------------------------------------------- */

import React, { useEffect } from 'react';
import { Routes, Route, useLocation, Navigate } from 'react-router-dom';
import { Header, MobileNav, Footer, Toasts, InstallPrompt } from './components/Chrome';
import Home from './pages/Home';
import SearchPage from './pages/Search';
import BookPage from './pages/Book';
import Confirmation from './pages/Confirmation';
import Trips from './pages/Trips';
import { Login, Signup } from './pages/Auth';
import Help from './pages/Help';
import NotFound from './pages/NotFound';

function ScrollToTop() {
  const location = useLocation();
  useEffect(
    function () {
      window.scrollTo(0, 0);
    },
    [location.pathname, location.search]
  );
  return null;
}

export default function App() {
  return (
    <div className="app">
      <ScrollToTop />
      <Header />
      <main>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/search/:service" element={<SearchPage />} />
          <Route path="/book/:service/:itemId" element={<BookPage />} />
          <Route path="/confirmation/:bookingId" element={<Confirmation />} />
          <Route path="/trips" element={<Trips />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/help" element={<Help />} />
          <Route path="/404" element={<NotFound />} />
          <Route path="*" element={<Navigate to="/404" replace />} />
        </Routes>
      </main>
      <Footer />
      <MobileNav />
      <Toasts />
      <InstallPrompt />
    </div>
  );
}

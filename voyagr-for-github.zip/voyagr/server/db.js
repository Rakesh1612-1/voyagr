/* ------------------------------------------------------------------
   Voyagr JSON database — zero-dependency persistent store.
   Lives at server/data/db.json; created & seeded on first run.
------------------------------------------------------------------- */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

export function hashPassword(password, salt) {
  return crypto.scryptSync(String(password), salt, 64).toString('hex');
}

function initialDb() {
  const demoSalt = crypto.randomBytes(16).toString('hex');
  return {
    secret: crypto.randomBytes(32).toString('hex'),
    users: [
      {
        id: 'u-demo',
        name: 'Aarav Sharma',
        email: 'demo@voyagr.app',
        phone: '+91 98765 43210',
        salt: demoSalt,
        hash: hashPassword('voyagr123', demoSalt),
        createdAt: new Date().toISOString(),
      },
    ],
    bookings: [],
  };
}

let cache = null;

export function getDb() {
  if (cache) return cache;
  try {
    cache = JSON.parse(fs.readFileSync(DB_PATH, 'utf8'));
  } catch (e) {
    cache = initialDb();
    saveDb(cache);
  }
  return cache;
}

export function saveDb(db) {
  cache = db;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = DB_PATH + '.' + process.pid + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
    fs.renameSync(tmp, DB_PATH);
  } catch (e) {
    console.error('[voyagr-db] persist failed:', e.message);
  }
}

export function publicUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone || '',
    createdAt: user.createdAt,
  };
}

export function findUserByEmail(email) {
  const db = getDb();
  const needle = String(email || '').trim().toLowerCase();
  for (let i = 0; i < db.users.length; i += 1) {
    if (db.users[i].email.toLowerCase() === needle) return db.users[i];
  }
  return null;
}

export function verifyPassword(user, password) {
  const candidate = hashPassword(password, user.salt);
  const a = Buffer.from(candidate, 'hex');
  const b = Buffer.from(user.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export function createBooking(userId, booking) {
  const db = getDb();
  const now = new Date().toISOString();
  const record = Object.assign({}, booking, {
    id: booking.id || 'VYG-' + crypto.randomBytes(4).toString('hex').toUpperCase(),
    ownerEmail: booking.ownerEmail,
    ownerUserId: userId,
    createdAt: booking.createdAt || now,
    status: booking.status || 'confirmed',
    syncedAt: now,
  });
  const existing = db.bookings.filter(function (b) {
    return b.id === record.id;
  })[0];
  if (existing) {
    if (existing.ownerUserId !== userId) return { conflict: true };
    return { booking: existing, created: false };
  }
  db.bookings.unshift(record);
  saveDb(db);
  return { booking: record, created: true };
}

export function updateBooking(userId, bookingId, patch) {
  const db = getDb();
  let found = null;
  db.bookings.forEach(function (b) {
    if (b.id === bookingId && b.ownerUserId === userId) found = b;
  });
  if (!found) return null;
  Object.assign(found, patch, { syncedAt: new Date().toISOString() });
  saveDb(db);
  return found;
}

export function bookingsForUser(userId) {
  const db = getDb();
  return db.bookings.filter(function (b) {
    return b.ownerUserId === userId;
  });
}

/* ------------------------------------------------------------------
   Voyagr production host — serves the API and the built website
   (dist/) from a single Node process. Zero dependencies.

     npm run build && npm start        →  http://localhost:4000
------------------------------------------------------------------- */

import http from 'http';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { handleApi } from './api.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.join(__dirname, '..');
const DIST = path.join(ROOT, 'dist');
const PORT = Number(process.env.PORT || 4000);

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
  '.xml': 'application/xml; charset=utf-8',
  '.woff2': 'font/woff2',
};

function serveStatic(req, res) {
  const urlPath = decodeURIComponent((req.url || '/').split('?')[0]);
  let filePath = path.normalize(path.join(DIST, urlPath));
  if (filePath.indexOf(DIST) !== 0) {
    res.statusCode = 403;
    res.end('Forbidden');
    return;
  }

  fs.stat(filePath, function (err, stat) {
    if (err || !stat.isFile()) {
      // SPA fallback — any unknown route renders the app (client router takes over)
      filePath = path.join(DIST, 'index.html');
    }
    const ext = path.extname(filePath).toLowerCase();
    const isHtml = ext === '.html';
    fs.readFile(filePath, function (readErr, data) {
      if (readErr) {
        res.statusCode = 404;
        res.end(
          'Build not found. Run "npm run build" first, or use "npm run dev" for development.'
        );
        return;
      }
      res.statusCode = 200;
      res.setHeader('Content-Type', MIME[ext] || 'application/octet-stream');
      res.setHeader(
        'Cache-Control',
        isHtml
          ? 'no-cache'
          : /-[A-Za-z0-9_]{8,}\./.test(path.basename(filePath))
          ? 'public, max-age=31536000, immutable'
          : 'public, max-age=3600'
      );
      res.end(data);
    });
  });
}

const server = http.createServer(function (req, res) {
  if (handleApi(req, res)) return;
  serveStatic(req, res);
});

server.listen(PORT, '0.0.0.0', function () {
  console.log('Voyagr running on http://localhost:' + PORT);
  console.log('  · API    →  /api/*');
  console.log('  · Web    →  dist/ (run "npm run build" if empty)');
});

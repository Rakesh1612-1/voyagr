/* ------------------------------------------------------------------
   Voyagr API — zero-dependency request handler.
   Works mounted in the Vite dev server AND in the standalone
   production host (server/index.js). All routes are under /api.
------------------------------------------------------------------- */

import crypto from 'crypto';
import {
  getDb,
  saveDb,
  hashPassword,
  publicUser,
  findUserByEmail,
  verifyPassword,
  createBooking,
  updateBooking,
  bookingsForUser,
} from './db.js';

const TOKEN_TTL_MS = 1000 * 60 * 60 * 24 * 30; // 30 days

/* ------------------------------ helpers ------------------------------ */

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function signToken(payload, secret) {
  const body = b64url(JSON.stringify(payload));
  const sig = crypto.createHmac('sha256', secret).update(body).digest('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  return 'v1.' + body + '.' + sig;
}

function verifyToken(token, secret) {
  const parts = String(token || '').split('.');
  if (parts.length !== 3 || parts[0] !== 'v1') return null;
  const expected = crypto.createHmac('sha256', secret).update(parts[1]).digest('base64')
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const a = Buffer.from(expected);
  const b = Buffer.from(parts[2]);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const payload = JSON.parse(Buffer.from(parts[1].replace(/-/g, '+').replace(/_/g, '/'), 'base64').toString('utf8'));
    if (!payload || !payload.uid || payload.exp < Date.now()) return null;
    return payload;
  } catch (e) {
    return null;
  }
}

function json(res, status, data) {
  const body = JSON.stringify(data);
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(body);
}

function readBody(req) {
  return new Promise(function (resolve) {
    let raw = '';
    let tooBig = false;
    req.on('data', function (chunk) {
      raw += chunk;
      if (raw.length > 1024 * 1024) {
        tooBig = true;
        req.destroy();
      }
    });
    req.on('end', function () {
      if (tooBig) return resolve({ error: 'Payload too large' });
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (e) {
        resolve({ error: 'Invalid JSON body' });
      }
    });
    req.on('error', function () {
      resolve({ error: 'Request failed' });
    });
  });
}

function authUser(req, secret) {
  const header = req.headers['authorization'] || req.headers['Authorization'] || '';
  const token = String(header).replace(/^Bearer\s+/i, '').trim();
  const payload = verifyToken(token, secret);
  if (!payload) return null;
  const db = getDb();
  for (let i = 0; i < db.users.length; i += 1) {
    if (db.users[i].id === payload.uid) return { user: db.users[i], token: token };
  }
  return null;
}

function validEmail(v) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v || '').trim());
}

function setCors(req, res) {
  res.setHeader('Access-Control-Allow-Origin', req.headers.origin || '*');
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  res.setHeader('Access-Control-Max-Age', '86400');
}

/* ------------------------------- router ------------------------------- */

/**
 * Handle an API request. Returns true when the request was handled.
 * @param {import('http').IncomingMessage} req
 * @param {import('http').ServerResponse} res
 */
export function handleApi(req, res) {
  const original = req.url || '';
  if (original.indexOf('/api') !== 0) return false;

  setCors(req, res);
  if (req.method === 'OPTIONS') {
    res.statusCode = 204;
    res.end();
    return true;
  }

  const pathname = original.slice('/api'.length).split('?')[0] || '/';
  const db = getDb();
  const secret = db.secret;

  /* --- health --- */
  if (pathname === '/health' && req.method === 'GET') {
    json(res, 200, { ok: true, service: 'voyagr-api', time: new Date().toISOString() });
    return true;
  }

  /* --- auth: signup --- */
  if (pathname === '/auth/signup' && req.method === 'POST') {
    readBody(req).then(function (body) {
      if (body.error) return json(res, 400, { error: body.error });
      const name = String(body.name || '').trim();
      const email = String(body.email || '').trim();
      const password = String(body.password || '');
      if (!name) return json(res, 400, { error: 'Name is required' });
      if (!validEmail(email)) return json(res, 400, { error: 'Enter a valid email' });
      if (password.length < 6) return json(res, 400, { error: 'Password must be at least 6 characters' });
      if (findUserByEmail(email)) return json(res, 409, { error: 'An account with that email already exists' });

      const salt = crypto.randomBytes(16).toString('hex');
      const user = {
        id: 'u-' + crypto.randomBytes(6).toString('hex'),
        name: name,
        email: email,
        phone: String(body.phone || ''),
        salt: salt,
        hash: hashPassword(password, salt),
        createdAt: new Date().toISOString(),
      };
      const fresh = getDb();
      fresh.users.push(user);
      saveDb(fresh);
      const token = signToken({ uid: user.id, exp: Date.now() + TOKEN_TTL_MS }, secret);
      json(res, 201, { token: token, user: publicUser(user), message: 'Account created' });
    });
    return true;
  }

  /* --- auth: login --- */
  if (pathname === '/auth/login' && req.method === 'POST') {
    readBody(req).then(function (body) {
      if (body.error) return json(res, 400, { error: body.error });
      const user = findUserByEmail(body.email);
      if (!user || !verifyPassword(user, body.password)) {
        return json(res, 401, { error: 'Invalid email or password' });
      }
      const token = signToken({ uid: user.id, exp: Date.now() + TOKEN_TTL_MS }, secret);
      json(res, 200, { token: token, user: publicUser(user), message: 'Welcome back' });
    });
    return true;
  }

  /* --- auth: me --- */
  if (pathname === '/auth/me' && req.method === 'GET') {
    const auth = authUser(req, secret);
    if (!auth) { json(res, 401, { error: 'Not signed in' }); return true; }
    json(res, 200, { user: publicUser(auth.user) });
    return true;
  }

  /* --- bookings: list --- */
  if (pathname === '/bookings' && req.method === 'GET') {
    const auth = authUser(req, secret);
    if (!auth) { json(res, 401, { error: 'Not signed in' }); return true; }
    json(res, 200, { bookings: bookingsForUser(auth.user.id) });
    return true;
  }

  /* --- bookings: create (idempotent by id — safe for retries/migration) --- */
  if (pathname === '/bookings' && req.method === 'POST') {
    const auth = authUser(req, secret);
    if (!auth) { json(res, 401, { error: 'Not signed in' }); return true; }
    readBody(req).then(function (body) {
      if (body.error) return json(res, 400, { error: body.error });
      if (!body.title || !body.service) return json(res, 400, { error: 'Booking needs a service and title' });
      const result = createBooking(auth.user.id, Object.assign({}, body, { ownerEmail: auth.user.email }));
      if (result.conflict) return json(res, 409, { error: 'Booking id already used' });
      json(res, result.created ? 201 : 200, { booking: result.booking });
    });
    return true;
  }

  /* --- bookings: patch (cancel / update) --- */
  const patchMatch = pathname.match(/^\/bookings\/([^/]+)$/);
  if (patchMatch && req.method === 'PATCH') {
    const auth = authUser(req, secret);
    if (!auth) { json(res, 401, { error: 'Not signed in' }); return true; }
    readBody(req).then(function (body) {
      if (body.error) return json(res, 400, { error: body.error });
      const patch = {};
      if (body.status === 'cancelled' || body.status === 'confirmed') patch.status = body.status;
      if (body.cancelledAt) patch.cancelledAt = body.cancelledAt;
      const updated = updateBooking(auth.user.id, decodeURIComponent(patchMatch[1]), patch);
      if (!updated) return json(res, 404, { error: 'Booking not found' });
      json(res, 200, { booking: updated });
    });
    return true;
  }

  json(res, 404, { error: 'Unknown API route: ' + pathname });
  return true;
}

# Voyagr — every journey, one app

A fully functional all-in-one travel super-app: search and book **hotels, flights, trains,
buses, café tables, car rentals, city rides and experiences** — one checkout, one trips
dashboard, one installable PWA that runs beautifully in **Google Chrome** and **Apple Safari**.

![Voyagr](public/img/hero.jpg)

## What works (end to end)

| Service | Search & filters | Booking flow | Extras |
|---|---|---|---|
| 🏨 Hotels | 42 hotels · 25 cities · stars/amenities/style filters | Room types, nights, guests | Cancellation policy per rate |
| ✈️ Flights | Deterministic GDS-style feed · stops/airlines/time filters | Fare classes (Economy/Premium/Business) | On-time %, CO₂, via routing |
| 🚆 Trains | Rail corridors · classes 1A/2A/3A/SL/CC | **Interactive seat maps** (berths & chairs) | Coach layouts, punctuality |
| 🚌 Buses | Intercity coaches · type filters | **Seat picker** (seater & sleeper) | Boarding/dropping points |
| ☕ Cafés | 22 cafés · price bands | Time slots, party size, **menu pre-order** | Signature dishes, reviews |
| 🚗 Car rentals | Fleet by category/transmission | Pick-up/drop dates, add-ons (GPS, child seat, driver) | Deposit, mileage, supplier |
| 🚕 Rides | Bike / auto / cab / SUV / premium with live fare quotes | Fixed upfront pricing, surge, driver notes | Landmark-based pickup/drop |
| 🎭 Experiences | 22 tours · category/duration filters | Slots & group size | Includes list, free cancellation |

Plus:

- 💳 **Test payments** — cards (Luhn-validated), UPI, wallet · promo codes with real rules
  (`VOYAGR10`, `FLY5`, `STAY15`, `RIDE2`, `RAIL10`, `FEAST20`, `ROADTRIP`, `WANDER25`)
- 🎫 **E-tickets** with booking references (VYG-XXXXXX), QR block, printable
- 🗂 **My Trips** — upcoming/cancelled, expandable details, cancel + refund, rebook
- 👤 **Accounts with cross-device sync** — a built-in Node backend stores accounts &
  bookings (server/data/db.json), so the same login sees the same trips on every device.
  Guest bookings migrate to your account on sign-up; everything also caches locally and the
  app keeps working offline or without the server.
- 🌍 **Currency switcher** — USD, INR, EUR, GBP, AED with locale-aware formatting
- 📱 **PWA** — manifest, service worker, install prompt, offline shell, iOS/Android/desktop install
- 🎨 Custom design system, responsive from 320px up, Safari-safe CSS/JS

## Quick start

```bash
npm install
npm run dev        # http://localhost:5173  (website + API together)
npm run build      # production build → dist/
npm start          # production: website + API on http://localhost:4000
```

## Demo account

```
email:    demo@voyagr.app
password: voyagr123
```

Test card: `4242 4242 4242 4242` (any Luhn-valid number works) · expiry `12/28` · cvv `123`.

## Tech

- **React 18 + Vite 5 + React Router 6** — no UI framework, hand-crafted CSS design system
- **Zero-dependency Node backend** (`server/`) — scrypt-hashed accounts, HMAC auth tokens,
  JSON database (`server/data/db.json`), mounted inside the Vite dev server and serving the
  built site + API from one process in production
- **Hybrid storage** — server is the source of truth for signed-in users; localStorage keeps
  an offline cache and holds guest bookings until they're migrated on sign-up
- Deterministic inventory engines (`src/data/*`) — same search always returns the same results
- Service worker (`public/sw.js`) caches the app shell; installable via `public/manifest.webmanifest`
- Conservative ES2018 JS + `-webkit-` fallbacks for Safari; `safe-area-inset` support for iOS

## Where data lives

| Data | Location |
|---|---|
| Source code, styles, pages | `src/` |
| Inventory (hotels, flights, routes…) | `src/data/*.js` (deterministic engines) |
| Accounts & bookings (server) | `server/data/db.json` |
| Per-browser cache (offline + guests) | browser `localStorage` (`voyagr.*` keys) |
| Photos, icons, PWA files | `public/` |
| Production build | `dist/` |

## Project structure

```
server/
  api.js                REST API: /api/auth/*, /api/bookings, /api/health
  db.js                 JSON database + password hashing + seeding
  index.js              production host: serves dist/ + API on one port
  data/db.json          created on first run — accounts & bookings
src/
  lib/format.js         money, dates, validation, seeded RNG, geo
  lib/api.js            frontend fetch client (/api)
  data/                 flights · hotels · trains · buses · cafes · cars · rides · experiences · promos
  store/store.jsx       global state: auth + server sync, currency, bookings, toasts
  components/           Icons, Chrome (header/footer/nav), SearchForm
  pages/                Home, Search, Book, Confirmation, Trips, Auth, Help, NotFound
  styles/               base.css (tokens/utilities) · ui.css (components/layout)
public/                 manifest · sw.js · icons · AI-generated photography
```

## Publishing

See **[PUBLISH.md](PUBLISH.md)** for a 10-minute guide to putting Voyagr online (Netlify /
Vercel / Cloudflare Pages), pointing a domain at it, and getting it indexed on Google.

## Testing

```bash
node smoke.mjs          # 18-step end-to-end suite (search, booking, payments, mobile…)
node smoke-extra.mjs    # 7 more: seat maps, pre-orders, add-ons, UPI/wallet, iOS install
node smoke-server.mjs   # 6 backend tests incl. cross-device sync & guest migration
node shots.mjs          # screenshot tour into ./shots
```

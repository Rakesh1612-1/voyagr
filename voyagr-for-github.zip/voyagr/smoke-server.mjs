/* ------------------------------------------------------------------
   Cross-device sync tests: API auth + bookings sync + guest migration.
   Proves a booking made in one browser appears in another.
------------------------------------------------------------------- */
import { chromium } from 'playwright';

const base = 'http://localhost:5173';
let passed = 0;
let failed = 0;

async function step(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('✓', name);
  } catch (e) {
    failed += 1;
    console.log('✗', name, '—', String(e.message).split('\n')[0]);
    process.exitCode = 1;
  }
}

const browser = await chromium.launch();

await step('API health + signup + login + booking roundtrip (raw fetch)', async () => {
  const health = await fetch(base + '/api/health').then((r) => r.json());
  if (!health.ok) throw new Error('health=' + JSON.stringify(health));

  const email = 'sync-' + Date.now() + '@test.dev';
  const signup = await fetch(base + '/api/auth/signup', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name: 'Sync Tester', email, password: 'secret99', phone: '+1 555 000 1' }),
  }).then((r) => r.json());
  if (!signup.token) throw new Error('no token: ' + JSON.stringify(signup));

  const login = await fetch(base + '/api/auth/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: 'secret99' }),
  }).then((r) => r.json());
  if (!login.token) throw new Error('login failed');

  const testId = 'VYG-API-' + Date.now();
  const created = await fetch(base + '/api/bookings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + login.token },
    body: JSON.stringify({
      id: testId,
      service: 'hotel',
      title: 'API Test Hotel',
      subtitle: 'Testville',
      pricing: { totalUSD: 123 },
      details: [],
    }),
  }).then((r) => r.json());
  if (!created.booking || created.booking.id !== testId) throw new Error('create failed: ' + JSON.stringify(created));

  const list = await fetch(base + '/api/bookings', {
    headers: { Authorization: 'Bearer ' + login.token },
  }).then((r) => r.json());
  if (!list.bookings.some((b) => b.id === testId)) throw new Error('booking not listed');

  // unauthenticated must fail
  const anon = await fetch(base + '/api/bookings');
  if (anon.status !== 401) throw new Error('anon status=' + anon.status);
});

const creds = {
  name: 'Cross Device',
  email: 'cross-' + Date.now() + '@test.dev',
  password: 'syncpass1',
};

await step('device A: sign up + book a hotel', async () => {
  const a = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p = await a.newPage();
  await p.goto(base + '/signup');
  await p.waitForSelector('.auth-form-inner');
  await p.fill('input[placeholder="Aarav Sharma"]', creds.name);
  await p.fill('input[placeholder="you@email.com"]', creds.email);
  await p.fill('input[placeholder="At least 6 characters"]', creds.password);
  await p.locator('button:has-text("Create account")').click();
  await p.waitForFunction(() => window.location.pathname === '/trips', { timeout: 10000 });

  await p.goto(base + '/search/hotel?city=rome&checkin=2026-12-01&checkout=2026-12-04&guests=2&rooms=1');
  await p.waitForSelector('.result-card');
  await p.locator('.result-card').first().getByText('View rooms').click();
  await p.waitForSelector('.booking-layout');
  await p.fill('input[placeholder="Aarav"]', 'Cross');
  await p.fill('input[placeholder="Sharma"]', 'Device');
  await p.fill('input[placeholder="you@email.com"]', creds.email);
  await p.fill('input[placeholder="+91 98765 43210"]', '+1 555 000 2');
  await p.locator('button:has-text("Continue to payment")').click();
  await p.waitForSelector('text=How would you like to pay?');
  await p.fill('input[placeholder="Cross Device"]', 'Cross Device');
  await p.getByTestId('pay-btn').click();
  await p.waitForSelector('.success-hero', { timeout: 10000 });
  // give the background sync POST a moment
  await p.waitForTimeout(700);
  await a.close();
});

await step('device B (fresh browser): same trip appears — sync works!', async () => {
  const b = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p = await b.newPage();
  await p.goto(base + '/login');
  await p.waitForSelector('.auth-form-inner');
  await p.fill('input[type="email"]', creds.email);
  await p.fill('input[type="password"]', creds.password);
  await p.locator('button:has-text("Sign in")').last().click();
  await p.waitForFunction(() => window.location.pathname === '/trips', { timeout: 10000 });
  await p.waitForSelector('.trip-card', { timeout: 10000 });
  const body = await p.textContent('body');
  if (!/Trastevere Oro|Rome/.test(body)) throw new Error('synced booking missing on device B');
  await b.close();
});

await step('cancel on device B syncs back to device A', async () => {
  const b = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p = await b.newPage();
  await p.goto(base + '/login');
  await p.fill('input[type="email"]', creds.email);
  await p.fill('input[type="password"]', creds.password);
  await p.locator('button:has-text("Sign in")').last().click();
  await p.waitForFunction(() => window.location.pathname === '/trips', { timeout: 10000 });
  await p.waitForSelector('.trip-card');
  await p.locator('.trip-card button:has-text("Cancel")').first().click();
  await p.locator('.modal button:has-text("Cancel booking")').click();
  await p.waitForTimeout(700);
  await b.close();

  const a = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p2 = await a.newPage();
  await p2.goto(base + '/login');
  await p2.fill('input[type="email"]', creds.email);
  await p2.fill('input[type="password"]', creds.password);
  await p2.locator('button:has-text("Sign in")').last().click();
  await p2.waitForFunction(() => window.location.pathname === '/trips', { timeout: 10000 });
  await p2.locator('.tab:has-text("Cancelled")').click();
  await p2.waitForSelector('.trip-card', { timeout: 10000 });
  const body = await p2.textContent('body');
  if (!/Cancelled/.test(body)) throw new Error('cancellation did not sync');
  await a.close();
});

await step('guest booking migrates to account on sign-up', async () => {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p = await ctx.newPage();
  // guest books a ride
  await p.goto(base + '/search/ride?city=paris&pickup=1&dropoff=3&when=now');
  await p.waitForSelector('.result-card');
  await p.locator('.result-card').first().getByText('Book ride').click();
  await p.waitForSelector('.booking-layout');
  await p.fill('input[placeholder="Aarav"]', 'Guest');
  await p.fill('input[placeholder="Sharma"]', 'Person');
  await p.fill('input[placeholder="you@email.com"]', 'guest@local.dev');
  await p.fill('input[placeholder="+91 98765 43210"]', '+1 555 000 3');
  await p.locator('button:has-text("Continue to payment")').click();
  await p.waitForSelector('text=How would you like to pay?');
  await p.fill('input[placeholder="Guest Person"]', 'Guest Person');
  await p.getByTestId('pay-btn').click();
  await p.waitForSelector('.success-hero', { timeout: 10000 });

  // now sign up — the guest booking should survive and sync
  await p.goto(base + '/signup');
  const email = 'migrate-' + Date.now() + '@test.dev';
  await p.fill('input[placeholder="Aarav Sharma"]', 'Migrate Test');
  await p.fill('input[placeholder="you@email.com"]', email);
  await p.fill('input[placeholder="At least 6 characters"]', 'migrate1');
  await p.locator('button:has-text("Create account")').click();
  await p.waitForFunction(() => window.location.pathname === '/trips', { timeout: 10000 });
  await p.waitForSelector('.trip-card', { timeout: 10000 });
  const body = await p.textContent('body');
  if (!/Eiffel Tower|Seine|Paris|Montmartre|Louvre|Champs|Le Marais|Charles de Gaulle/.test(body)) {
    throw new Error('guest booking lost after signup');
  }
  await ctx.close();

  // and it exists server-side: new device logs in and sees it
  const ctx2 = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const p2 = await ctx2.newPage();
  await p2.goto(base + '/login');
  await p2.fill('input[type="email"]', email);
  await p2.fill('input[type="password"]', 'migrate1');
  await p2.locator('button:has-text("Sign in")').last().click();
  await p2.waitForFunction(() => window.location.pathname === '/trips', { timeout: 10000 });
  await p2.waitForSelector('.trip-card', { timeout: 10000 });
  await ctx2.close();
});

await step('server persistence: db.json exists on disk', async () => {
  const fs = await import('fs');
  if (!fs.existsSync('server/data/db.json')) throw new Error('db.json missing');
  const db = JSON.parse(fs.readFileSync('server/data/db.json', 'utf8'));
  if (!db.users.length || !db.secret) throw new Error('db not seeded');
});

console.log('\n--- results:', passed, 'passed,', failed, 'failed');
await browser.close();

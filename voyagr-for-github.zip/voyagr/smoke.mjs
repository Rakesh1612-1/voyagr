/* Voyagr end-to-end smoke test (Playwright). */
import { chromium } from 'playwright';

const base = 'http://localhost:5173';
let passed = 0;
let failed = 0;
const errors = [];

async function step(name, fn) {
  try {
    await fn();
    passed += 1;
    console.log('✓', name);
  } catch (e) {
    failed += 1;
    console.log('✗', name, '—', String(e.message).split('\n')[0]);
    process.exitCode = 1;
  }
}

const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1320, height: 950 } });
page.on('console', (msg) => {
  if (msg.type() === 'error') errors.push(msg.text());
});
page.on('pageerror', (err) => errors.push('pageerror: ' + String(err)));

await step('home page loads', async () => {
  await page.goto(base + '/', { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('.search-card', { timeout: 8000 });
  const t = await page.title();
  if (!/Voyagr/.test(t)) throw new Error('title=' + t);
  await page.waitForSelector('.city-card', { timeout: 8000 });
});

await step('currency switcher works', async () => {
  await page.selectOption('.currency-select', 'INR');
  await page.waitForTimeout(300);
  await page.selectOption('.currency-select', 'USD');
});

await step('hotel search returns results', async () => {
  await page.goto(base + '/search/hotel?city=goa&checkin=2026-11-05&checkout=2026-11-08&guests=2&rooms=1');
  await page.waitForSelector('.result-card', { timeout: 8000 });
  const n = await page.locator('.result-card').count();
  if (n < 2) throw new Error('results=' + n);
});

await step('hotel filters narrow results', async () => {
  const before = await page.locator('.result-card').count();
  await page.locator('.filters .check input').first().check();
  await page.waitForTimeout(400);
  const after = await page.locator('.result-card').count();
  if (after > before) throw new Error('filter increased results');
  await page.locator('.filters button:has-text("Reset")').click();
});

await step('flight search returns results', async () => {
  await page.goto(base + '/search/flight?from=delhi&to=goa&date=2026-11-05&cabin=economy&pax=1');
  await page.waitForSelector('.result-card', { timeout: 8000 });
  const n = await page.locator('.result-card').count();
  if (n < 3) throw new Error('results=' + n);
});

await step('train search works', async () => {
  await page.goto(base + '/search/train?from=delhi&to=jaipur&date=2026-11-05');
  await page.waitForSelector('.result-card', { timeout: 8000 });
});

await step('bus search works', async () => {
  await page.goto(base + '/search/bus?from=mumbai&to=goa&date=2026-11-05');
  await page.waitForSelector('.result-card', { timeout: 8000 });
});

await step('cafe search works', async () => {
  await page.goto(base + '/search/cafe?city=paris&date=2026-11-05&party=2');
  await page.waitForSelector('.result-card', { timeout: 8000 });
});

await step('car search works', async () => {
  await page.goto(base + '/search/car?city=goa&pickup=2026-11-05&dropoff=2026-11-10');
  await page.waitForSelector('.result-card', { timeout: 8000 });
});

await step('ride quotes work', async () => {
  await page.goto(base + '/search/ride?city=delhi&pickup=0&dropoff=2&when=now');
  await page.waitForSelector('.result-card', { timeout: 8000 });
  const n = await page.locator('.result-card').count();
  if (n < 2) throw new Error('vehicles=' + n);
});

await step('experience search works', async () => {
  await page.goto(base + '/search/experience?city=bali&date=2026-11-05&guests=2');
  await page.waitForSelector('.result-card', { timeout: 8000 });
});

await step('book hotel end-to-end → ticket', async () => {
  await page.goto(base + '/search/hotel?city=goa&checkin=2026-11-05&checkout=2026-11-08&guests=2&rooms=1');
  await page.waitForSelector('.result-card', { timeout: 8000 });
  await page.locator('.result-card').first().getByText('View rooms').click();
  await page.waitForSelector('.booking-layout', { timeout: 8000 });
  await page.fill('input[placeholder="Aarav"]', 'Test');
  await page.fill('input[placeholder="Sharma"]', 'Traveller');
  await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
  await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
  await page.locator('button:has-text("Continue to payment")').click();
  await page.waitForSelector('text=How would you like to pay?', { timeout: 8000 });
  await page.fill('input[placeholder="Test Traveller"]', 'Test Traveller');
  // apply a promo first
  await page.fill('input[placeholder="VOYAGR10"]', 'VOYAGR10');
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(400);
  await page.getByTestId('pay-btn').click();
  await page.waitForSelector('.success-hero', { timeout: 10000 });
  const body = await page.textContent('body');
  if (!/VYG-/.test(body)) throw new Error('no booking ref');
});

await step('book flight with promo FLY5', async () => {
  await page.goto(base + '/search/flight?from=delhi&to=goa&date=2026-11-05&cabin=economy&pax=2');
  await page.waitForSelector('.result-card', { timeout: 8000 });
  await page.locator('.result-card').first().getByText('Select', { exact: true }).click();
  await page.waitForSelector('.booking-layout', { timeout: 8000 });
  await page.fill('input[placeholder="Aarav"]', 'Test');
  await page.fill('input[placeholder="Sharma"]', 'Traveller');
  await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
  await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
  await page.fill('input[placeholder="Full name"]', 'Second Traveller');
  await page.locator('button:has-text("Continue to payment")').click();
  await page.waitForSelector('text=How would you like to pay?', { timeout: 8000 });
  await page.fill('input[placeholder="Test Traveller"]', 'Test Traveller');
  await page.fill('input[placeholder="VOYAGR10"]', 'FLY5');
  await page.locator('button:has-text("Apply")').click();
  await page.waitForTimeout(400);
  await page.getByTestId('pay-btn').click();
  await page.waitForSelector('.success-hero', { timeout: 10000 });
});

await step('trips dashboard lists bookings + cancel works', async () => {
  await page.goto(base + '/trips');
  await page.waitForSelector('.trip-card', { timeout: 8000 });
  const n = await page.locator('.trip-card').count();
  if (n < 2) throw new Error('bookings=' + n);
  await page.locator('.trip-card button:has-text("Cancel")').first().click();
  await page.waitForSelector('.modal', { timeout: 5000 });
  await page.locator('.modal button:has-text("Cancel booking")').click();
  await page.waitForTimeout(500);
});

await step('login with demo account', async () => {
  await page.goto(base + '/login');
  await page.waitForSelector('.auth-form-inner', { timeout: 8000 });
  await page.fill('input[type="email"]', 'demo@voyagr.app');
  await page.fill('input[type="password"]', 'voyagr123');
  await page.locator('button:has-text("Sign in")').last().click();
  await page.waitForFunction(() => window.location.pathname === '/trips', { timeout: 8000 });
});

await step('help page + FAQ accordion', async () => {
  await page.goto(base + '/help');
  await page.waitForSelector('.card', { timeout: 8000 });
  await page.locator('button:has-text("Which payment methods")').click();
  await page.waitForTimeout(300);
});

await step('404 page', async () => {
  await page.goto(base + '/this-route-does-not-exist');
  await page.waitForSelector('text=wandered off the map', { timeout: 8000 });
});

await step('mobile layout (390px)', async () => {
  const m = await browser.newPage({ viewport: { width: 390, height: 844 } });
  m.on('pageerror', (err) => errors.push('mobile pageerror: ' + String(err)));
  await m.goto(base + '/');
  await m.waitForSelector('.search-card', { timeout: 8000 });
  const navVisible = await m.locator('.mobile-nav').isVisible();
  if (!navVisible) throw new Error('mobile nav hidden');
  await m.goto(base + '/search/hotel?city=goa&checkin=2026-11-05&checkout=2026-11-08&guests=2&rooms=1');
  await m.waitForSelector('.result-card', { timeout: 8000 });
  await m.close();
});

console.log('\n--- console/page errors:', errors.length ? errors.slice(0, 12) : 'none');
console.log('--- results:', passed, 'passed,', failed, 'failed');
await browser.close();

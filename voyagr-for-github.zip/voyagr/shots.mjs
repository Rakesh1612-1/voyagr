import { chromium } from 'playwright';

const base = 'http://localhost:5173';
const browser = await chromium.launch();
const page = await browser.newPage({ viewport: { width: 1360, height: 940 } });

async function shot(path, name, opts = {}) {
  await page.goto(base + path, { waitUntil: 'networkidle' });
  await page.waitForTimeout(700);
  await page.screenshot({ path: 'shots/' + name + '.png', fullPage: opts.full || false });
  console.log('shot', name);
}

await shot('/', 'home-hero');
await shot('/', 'home-full', { full: true });
await shot('/search/hotel?city=goa&checkin=2026-11-05&checkout=2026-11-08&guests=2&rooms=1', 'search-hotel');
await shot('/search/flight?from=delhi&to=goa&date=2026-11-05&cabin=economy&pax=1', 'search-flight');
await shot('/search/ride?city=delhi&pickup=0&dropoff=2&when=now', 'search-ride');

// booking page
await page.goto(base + '/search/hotel?city=goa&checkin=2026-11-05&checkout=2026-11-08&guests=2&rooms=1');
await page.waitForSelector('.result-card');
await page.locator('.result-card').first().getByText('View rooms').click();
await page.waitForSelector('.booking-layout');
await page.waitForTimeout(500);
await page.screenshot({ path: 'shots/book-hotel.png' });
console.log('shot book-hotel');

// train seat map
await page.goto(base + '/book/train/nb-2001?date=2026-11-05&class=3A&pax=2', { waitUntil: 'networkidle' });
await page.waitForTimeout(500);
await page.screenshot({ path: 'shots/book-train.png', fullPage: true });
console.log('shot book-train');

// confirmation via quick booking
await page.goto(base + '/search/cafe?city=paris&date=2026-11-05&party=2');
await page.waitForSelector('.result-card');
await page.locator('.result-card').first().getByText('Reserve table').click();
await page.waitForSelector('.booking-layout');
await page.fill('input[placeholder="Aarav"]', 'Test');
await page.fill('input[placeholder="Sharma"]', 'Traveller');
await page.fill('input[placeholder="you@email.com"]', 'test@voyagr.app');
await page.fill('input[placeholder="+91 98765 43210"]', '+91 90000 11111');
await page.locator('button:has-text("Continue to payment")').click();
await page.waitForSelector('text=How would you like to pay?');
await page.fill('input[placeholder="Test Traveller"]', 'Test Traveller');
await page.getByTestId('pay-btn').click();
await page.waitForSelector('.success-hero', { timeout: 10000 });
await page.waitForTimeout(400);
await page.screenshot({ path: 'shots/confirmation.png', fullPage: true });
console.log('shot confirmation');

await shot('/trips', 'trips');
await shot('/login', 'login');
await shot('/help', 'help');

// mobile
const m = await browser.newPage({ viewport: { width: 390, height: 844 } });
await m.goto(base + '/', { waitUntil: 'networkidle' });
await m.waitForTimeout(600);
await m.screenshot({ path: 'shots/mobile-home.png' });
await m.goto(base + '/search/flight?from=delhi&to=goa&date=2026-11-05&cabin=economy&pax=1', { waitUntil: 'networkidle' });
await m.waitForTimeout(600);
await m.screenshot({ path: 'shots/mobile-flight.png' });
console.log('shot mobile');

await browser.close();

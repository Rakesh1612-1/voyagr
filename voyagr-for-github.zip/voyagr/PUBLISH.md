# Publishing Voyagr — Chrome, Safari & getting it on Google

Voyagr is a standard static web app + PWA, so publishing takes about 10 minutes and needs
no app-store accounts. Once it's on a public HTTPS URL it works in Chrome and Safari, can be
installed to any home screen, and can be indexed by Google.

---

## 1. Build & run (production)

```bash
npm install
npm run build      # → dist/
npm start          # website + API on http://localhost:4000
```

One Node process serves everything: the website (`dist/`) **and** the sync API (`/api/*`).
User accounts and bookings persist to `server/data/db.json` (created on first run — back it
up, or point `PORT` at a persistent disk on your host).

## 2. Deploy

### Option A: Render / Railway / Fly.io (recommended — keeps sync)

Any Node host works; the app is a single service.

**Render example:**
1. New → Web Service → connect the repo (or upload)
2. Build command: `npm install && npm run build`
3. Start command: `npm start`
4. Add a **persistent disk** mounted at `server/data` so bookings survive deploys
5. Done — `https://<name>.onrender.com` serves the app and the API together

**Railway / Fly.io** are the same shape: build with `npm run build`, run `npm start`,
attach a volume at `server/data`.

### Option B: Netlify / Vercel / Cloudflare Pages (static only)

```bash
npm run build   # then drag dist/ onto Netlify, or `vercel --prod`
```

The site still works fully in **guest mode** (bookings in the browser) — accounts and
cross-device sync need the Node API (Option A), or a later migration to Supabase/Firebase.

### Custom domain

All hosts offer domain settings. Serve over **HTTPS** — required for the service worker
and installability.

## 3. Post it on Google

1. Verify your domain in [Google Search Console](https://search.google.com/search-console)
   (DNS record or HTML tag)
2. Submit `https://your-domain.com/sitemap.xml` in **Sitemaps**
3. Use **URL Inspection → Request Indexing** on the homepage
4. Keep `robots.txt` and `sitemap.xml` (already in `public/`) — they ship with the build

Within days the site appears in Google Search; the structured `og:`/`twitter:` meta tags in
`index.html` make shared links look great too.

## 4. “Post it on Apple Safari”

Safari isn't a store — it's a browser. Once the site is live it just works in Safari on
Mac/iPhone/iPad (the CSS and JS are written with Safari quirks in mind). To make it feel
native on iPhone:

1. Open the site in **Safari** → tap **Share** → **Add to Home Screen**
2. It launches full-screen with the Voyagr icon (apple-touch-icon + manifest already wired)
3. Android Chrome shows a one-tap **Install app** prompt automatically (beforeinstallprompt)

The PWA registers its service worker only in production builds, so the installed app
works offline (app shell, images and any page visited before).

## 5. Optional: real app stores later

If you want actual Google Play / App Store listings later, wrap `dist/` with
[Capacitor](https://capacitorjs.com):

```bash
npm i @capacitor/core @capacitor/cli
npx cap init Voyagr com.voyagr.app --web-dir dist
npm i @capacitor/android @capacitor/ios
npx cap add android && npx cap add ios
npx cap sync
```

Then open Android Studio / Xcode and publish with your own developer accounts.
Everything in the web app (routing, storage, payments UI) works unchanged inside the shell.

## 6. Smoke-test after going live

- Open the URL in Chrome (desktop + Android) and Safari (macOS + iPhone)
- Run a booking in each service; confirm the e-ticket in **My Trips**
- **Cross-device sync:** sign up on your laptop, book a trip, then sign in on your phone —
  the trip should be there (and cancellations sync both ways)
- Toggle currencies; reload — bookings and currency persist
- Chrome menu → “Install Voyagr”; iPhone → Add to Home Screen; launch from the icon
- Lighthouse (DevTools): aim for 95+ on Performance/PWA on a cold load

---

### Where data is stored

| Data | Location |
|---|---|
| Accounts, bookings (server, shared across devices) | `server/data/db.json` |
| Per-device cache & guest bookings | browser `localStorage` (`voyagr.*`) |
| Session tokens | browser `localStorage` (`voyagr.token`) |

Passwords are scrypt-hashed; sessions use signed HMAC tokens (30-day expiry).

### Useful links in the demo

| Item | Value |
|---|---|
| Demo account | `demo@voyagr.app` / `voyagr123` |
| Test card | `4242 4242 4242 4242`, exp `12/28`, cvv `123` |
| Promo codes | VOYAGR10 · FLY5 · STAY15 · RIDE2 · RAIL10 · FEAST20 · ROADTRIP · WANDER25 |
